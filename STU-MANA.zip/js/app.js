// js/app.js - The Router

// Define routes as strings to ensure they are looked up at runtime
// This avoids issues if scripts load in a different order
const routes = {
    '#/login': 'renderLogin',
    '#/dashboard': 'renderDashboard',
    '#/students': 'renderStudentsList',
    '#/scores': 'renderScoresList',
    '#/subjects': 'renderSubjectsList',
    '#/teachers': 'renderTeachersList',
    '#/add-teacher': 'renderAddTeacher',
    '#/edit-teacher': 'renderEditTeacher',
    '#/show-teacher': 'renderShowTeacher',
    '#/add-student': 'renderAddStudent',
    '#/edit-student': 'renderEditStudent',
    '#/show-student': 'renderShowStudent',
    '#/schools': 'renderSchoolsList',
    '#/add-school': 'renderAddSchool',
    '#/edit-school': 'renderEditSchool',
    '#/show-school': 'renderShowSchool',
    '#/users': 'renderUsersList',
    '#/messages': 'renderMessages',
    '#/reports': 'renderReportsList',
    '#/handwriting-report': 'renderHandwritingReportUI',
    '#/ranking-report': 'renderHandwritingReportUI',
    '#/honor-roll': 'renderHandwritingReportUI',
    '#/settings': 'renderSettings'
};

function navigateTo(path) {
    console.log('Navigating to:', path);
    // Set the hash directly
    window.location.hash = path;
    
    // Explicitly call handleRoute to ensure UI updates immediately
    handleRoute();
}

function handleRoute() {
    // Close any open modals when navigating
    if (typeof closeModal === 'function') closeModal();

    // Cleanup print iframes
    const printIframe = document.getElementById('print-iframe');
    if (printIframe) printIframe.remove();

    // Auth check
    if (typeof checkAuth === 'function' && !checkAuth()) {
        return;
    }

    const hash = window.location.hash || '#/dashboard';
    const baseRoute = hash.split('?')[0];
    
    // Permission check
    const currentUser = getCurrentUser();
    if (currentUser) {
        const pageKey = baseRoute.replace('#/', '');
        const permissions = currentUser.permissions || [];
        
        // Users role page is special
        const hasPermission = permissions.includes(pageKey) || baseRoute === '#/login' || (pageKey.includes('-') && permissions.includes(pageKey.split('-')[1] + 's'));
        
        // Simple mapping check
        const routeMapping = {
            'dashboard': 'dashboard',
            'students': 'students',
            'add-student': 'students',
            'edit-student': 'students',
            'show-student': 'students',
            'scores': 'scores',
            'subjects': 'subjects',
            'teachers': 'teachers',
            'add-teacher': 'teachers',
            'edit-teacher': 'teachers',
            'show-teacher': 'teachers',
            'schools': 'schools',
            'add-school': 'schools',
            'edit-school': 'schools',
            'show-school': 'schools',
            'users': 'users',
            'messages': 'messages',
            'reports': 'reports',
            'handwriting-report': 'reports',
            'ranking-report': 'reports',
            'honor-roll': 'reports',
            'settings': 'settings'
        };

        const requiredPermission = routeMapping[pageKey];
        const isTeacher = currentUser.role === 'Teacher';
        const hasAccess = permissions.includes(requiredPermission) || (isTeacher && requiredPermission === 'reports');

        if (requiredPermission && !hasAccess && currentUser.role !== 'Super Admin' && currentUser.role !== 'Admin') {
            console.warn('No permission for:', pageKey);
            window.location.hash = '#/dashboard';
            return;
        }
    }
    
    console.log('Handling route:', baseRoute);

    // Update active nav
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
        const href = item.getAttribute('href');
        if (href === baseRoute || (baseRoute === '#/handwriting-report' && href === '#/reports')) {
            item.classList.add('active');
        }
    });

    // Update Sidebar visibility and User Info
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');
    if (baseRoute === '#/login') {
        if (sidebar) sidebar.style.display = 'none';
        if (mainContent) {
            mainContent.style.marginLeft = '0';
            mainContent.style.maxWidth = '100%';
        }
    } else {
        if (sidebar) sidebar.style.display = 'flex';
        if (mainContent) {
            mainContent.style.marginLeft = 'var(--sidebar-width)';
            mainContent.style.maxWidth = 'calc(100% - var(--sidebar-width))';
        }
        updateUserDisplay();
        
        // Show theme toggle only on dashboard
        const themeToggle = document.getElementById('theme-toggle');
        if (themeToggle) {
            themeToggle.style.display = (baseRoute === '#/dashboard') ? 'flex' : 'none';
        }
    }

    const contentArea = document.getElementById('content-area');
    if (!contentArea) {
        console.error('Content area not found!');
        return;
    }

    // Render page
    const renderFnName = routes[baseRoute];
    const renderFn = window[renderFnName];

    try {
        if (typeof renderFn === 'function') {
            renderFn();
        } else {
            console.warn(`Render function ${renderFnName} not found for route ${baseRoute}, defaulting to dashboard`);
            if (typeof renderDashboard === 'function') {
                renderDashboard();
            } else {
                contentArea.innerHTML = '<div class="p-4">Error: Dashboard renderer not found.</div>';
            }
        }
    } catch (error) {
        console.error('Error rendering page:', error);
        contentArea.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">⚠️</div>
                <h3>Something went wrong</h3>
                <p>Failed to load the page: ${error.message}</p>
                <button class="btn btn-primary" onclick="navigateTo('#/dashboard')">Go to Dashboard</button>
            </div>
        `;
    }
}

window.applySettings = function() {
    const headerSize = localStorage.getItem('sms_header_size') || '28';
    const tableSize = localStorage.getItem('sms_table_size') || '14';
    const theme = localStorage.getItem('sms_theme') || 'light';
    const fontKhmer = localStorage.getItem('sms_font_khmer') || "'Khmer OS Siemreap'";
    const fontEng = localStorage.getItem('sms_font_eng') || "'Inter'";

    const fontFamily = `${fontEng}, ${fontKhmer}, sans-serif`;

    document.documentElement.style.setProperty('--header-font-size', headerSize + 'px');
    document.documentElement.style.setProperty('--table-font-size', tableSize + 'px');
    document.documentElement.style.setProperty('--font-family', fontFamily);
    document.documentElement.setAttribute('data-theme', theme);
};

window.toggleTheme = function() {
    const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('sms_theme', newTheme);
};

function updateUserDisplay() {
    if (typeof getCurrentUser !== 'function') return;
    const user = getCurrentUser();
    if (user) {
        const nameEl = document.getElementById('sidebar-user-name');
        const usernameEl = document.getElementById('sidebar-username');
        const roleEl = document.getElementById('sidebar-user-role');
        const avatarEl = document.getElementById('sidebar-user-avatar');
        
        if (nameEl) nameEl.textContent = user.name || user.username;
        if (usernameEl) usernameEl.textContent = '@' + user.username;
        if (roleEl) roleEl.textContent = user.role || 'User';
        if (avatarEl) {
            avatarEl.innerHTML = user.role === 'Super Admin' ? '⚡' : (user.role === 'Admin' ? '🛠️' : '👨‍🏫');
        }

        // Handle Sidebar Menu Visibility based on permissions
        const permissions = user.permissions || [];
        
        const navMapping = {
            'dashboard': 'dashboard',
            'students': 'students',
            'scores': 'scores',
            'subjects': 'subjects',
            'teachers': 'teachers',
            'schools': 'schools',
            'messages': 'messages',
            'users': 'users',
            'reports': 'reports',
            'settings': 'settings'
        };

        document.querySelectorAll('.nav-item').forEach(nav => {
            const page = nav.getAttribute('data-page');
            if (page && navMapping[page]) {
                const isSuperAdmin = user.role === 'Super Admin';
                const isAdmin = user.role === 'Admin';
                
                // Super Admin sees everything. Admin sees everything based on fixed permissions array.
                const hasRoleAccess = isSuperAdmin || isAdmin;
                
                if (hasRoleAccess || permissions.includes(navMapping[page])) {
                    nav.style.display = 'flex';
                } else {
                    nav.style.display = 'none';
                }
            }
        });
    }
}

// Event Listeners
document.addEventListener('DOMContentLoaded', function () {
    // Apply saved display settings
    applySettings();

    // Handle all nav clicks
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', function (e) {
            // Only prevent default if it's an internal hash link
            const href = this.getAttribute('href');
            if (href && href.startsWith('#')) {
                e.preventDefault();
                navigateTo(href);
            }
        });
    });

    // Handle browser back/forward and hash changes
    window.addEventListener('hashchange', handleRoute);

    // Handle theme toggle
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', toggleTheme);
    }

    // Initial route
    handleRoute();
});
