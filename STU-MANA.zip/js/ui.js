// js/ui.js
function renderStars(count) {
    let html = '';
    for (let i = 1; i <= 5; i++) {
        html += `<span class="star ${i <= count ? '' : 'empty'}">★</span>`;
    }
    return html;
}

function calculateStars(gpa) {
    if (!gpa) return 0;
    if (gpa >= 3.8) return 5;
    if (gpa >= 3.5) return 4;
    if (gpa >= 3.0) return 3;
    if (gpa >= 2.5) return 2;
    if (gpa >= 2.0) return 1;
    return 0;
}

function showAlert(message, type = 'success') {
    let container = document.querySelector('.alert-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'alert-container';
        document.body.appendChild(container);
    }

    const alert = document.createElement('div');
    alert.className = `alert alert-${type}`;
    
    let icon = '';
    if (type === 'success') {
        icon = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"></polyline></svg>';
    } else if (type === 'error') {
        icon = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>';
    } else {
        icon = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>';
    }

    alert.innerHTML = `
        <span class="alert-icon">${icon}</span>
        <span class="alert-message">${message}</span>
    `;

    container.appendChild(alert);

    // Auto remove
    setTimeout(() => {
        alert.style.opacity = '0';
        alert.style.transform = 'translateX(20px)';
        setTimeout(() => alert.remove(), 300);
    }, 4000);
}

function createEmptyState(message, actionText, actionHref) {
    return `
        <div class="empty-state">
            <div class="empty-state-icon">📚</div>
            <h3>No Students Found</h3>
            <p>${message}</p>
            ${actionText ? `<a href="${actionHref}" class="btn btn-primary" onclick="navigateTo('${actionHref}'); return false;">${actionText}</a>` : ''}
        </div>
    `;
}

let modalCloseTimeout = null;

function openModal(htmlContent, isPlain = false) {
    if (modalCloseTimeout) {
        clearTimeout(modalCloseTimeout);
        modalCloseTimeout = null;
    }

    let overlay = document.getElementById('modal-overlay');
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'modal-overlay';
        overlay.className = 'modal-overlay';
        overlay.innerHTML = `
            <div class="modal-content" id="modal-content">
                <div id="modal-body"></div>
            </div>
        `;
        document.body.appendChild(overlay);
    }
    
    const modalContent = document.getElementById('modal-content');
    if (isPlain) {
        modalContent.classList.add('modal-plain');
    } else {
        modalContent.classList.remove('modal-plain');
    }

    document.getElementById('modal-body').innerHTML = htmlContent;
    
    // Allow DOM to render before adding active class for transition
    setTimeout(() => {
        overlay.classList.add('active');
    }, 10);
}

function closeModal() {
    const overlay = document.getElementById('modal-overlay');
    if (overlay) {
        overlay.classList.remove('active');
        if (modalCloseTimeout) clearTimeout(modalCloseTimeout);
        modalCloseTimeout = setTimeout(() => {
            if (overlay.parentNode) {
                overlay.remove();
            }
        }, 300);
    }
}

function switchFormTab(tabElement, tabId) {
    // Update tab button styles
    const tabContainer = tabElement.closest('.form-tabs');
    if (tabContainer) {
        tabContainer.querySelectorAll('.form-tab').forEach(tab => tab.classList.remove('active'));
    }
    tabElement.classList.add('active');

    // Update tab content visibility
    const form = tabElement.closest('form') || tabElement.closest('.modal-content');
    if (form) {
        form.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
        const targetContent = form.querySelector(`#${tabId}`);
        if (targetContent) targetContent.classList.add('active');
    }
}

// Dropdown logic
function toggleDropdown(event, dropdownId) {
    event.stopPropagation();
    
    // Close all other dropdowns
    document.querySelectorAll('.dropdown-menu').forEach(menu => {
        if (menu.id !== dropdownId) {
            menu.classList.remove('show');
        }
    });

    // Toggle the clicked dropdown
    const dropdown = document.getElementById(dropdownId);
    if (dropdown) {
        dropdown.classList.toggle('show');
    }
}

// Close dropdowns when clicking outside
document.addEventListener('click', function() {
    document.querySelectorAll('.dropdown-menu').forEach(menu => {
        menu.classList.remove('show');
    });
});

// Image Upload Logic
function handleImageUpload(inputElement, hiddenInputId, previewId) {
    const file = inputElement.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function(e) {
        const base64Str = e.target.result;
        const hiddenInput = document.getElementById(hiddenInputId);
        if (hiddenInput) {
            hiddenInput.value = base64Str;
        }
        
        const previewEl = document.getElementById(previewId);
        if (previewEl) {
            previewEl.innerHTML = `<img src="${base64Str}" style="width: 100%; height: 100%; object-fit: cover; border-radius: inherit;">`;
        }
    };
    reader.readAsDataURL(file);
}

function renderAvatar(photoStr, fallbackEmoji = '🎓') {
    if (!photoStr) return fallbackEmoji;
    if (photoStr.startsWith('data:image') || photoStr.startsWith('http')) {
        return `<img src="${photoStr}" style="width: 100%; height: 100%; object-fit: cover; border-radius: inherit;">`;
    }
    return photoStr; // It's an emoji
}

// Sidebar Resizer Logic
document.addEventListener('DOMContentLoaded', () => {
    const resizer = document.getElementById('sidebar-resizer');
    const root = document.documentElement;
    
    // Load saved width
    const savedWidth = localStorage.getItem('sms_sidebar_width');
    if (savedWidth) {
        root.style.setProperty('--sidebar-width', savedWidth + 'px');
    }

    const sidebar = document.querySelector('.sidebar');
    const updateSidebarState = (width) => {
        if (sidebar) {
            if (width < 140) {
                sidebar.classList.add('collapsed');
            } else {
                sidebar.classList.remove('collapsed');
            }
        }
    };

    // Initial state
    const initialWidth = parseInt(getComputedStyle(root).getPropertyValue('--sidebar-width'), 10) || 240;
    updateSidebarState(initialWidth);

    if (resizer) {
        let isResizing = false;
        let startX;
        let startWidth;

        resizer.addEventListener('mousedown', (e) => {
            isResizing = true;
            resizer.classList.add('active');
            startX = e.clientX;
            // Get current width as a number
            const currentWidth = getComputedStyle(root).getPropertyValue('--sidebar-width').trim();
            startWidth = parseInt(currentWidth, 10) || 240;
            
            // Prevent text selection during drag
            document.body.style.userSelect = 'none';
        });

        document.addEventListener('mousemove', (e) => {
            if (!isResizing) return;
            
            const dx = e.clientX - startX;
            let newWidth = startWidth + dx;
            
            // Constraints
            if (newWidth < 70) newWidth = 70;
            if (newWidth > 400) newWidth = 400;
            
            root.style.setProperty('--sidebar-width', newWidth + 'px');
            updateSidebarState(newWidth);
        });

        document.addEventListener('mouseup', () => {
            if (isResizing) {
                isResizing = false;
                resizer.classList.remove('active');
                document.body.style.userSelect = '';
                
                // Save width
                const finalWidth = getComputedStyle(root).getPropertyValue('--sidebar-width').trim();
                localStorage.setItem('sms_sidebar_width', parseInt(finalWidth, 10));
            }
        });
    }
});
