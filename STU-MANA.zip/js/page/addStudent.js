// js/page/addStudent.js

function renderAddStudent() {
    const container = document.getElementById('content-area');

    const currentUser = getCurrentUser();
    const isTeacher = currentUser && currentUser.role === 'Teacher';
    const teachers = getTeachers();
    const myTeacherRecord = isTeacher ? teachers.find(t => (t.tengFirstName + ' ' + t.tengLastName) === currentUser.name) : null;

    const schools = getSchools();
    const schoolOptions = schools.map(s =>
        `<option value="${s.schoolName}" ${(isTeacher && myTeacherRecord && myTeacherRecord.school === s.schoolName) ? 'selected' : ''}>${s.schoolName}</option>`
    ).join('');

    const teacherOptions = isTeacher && myTeacherRecord ?
        `<option value="${myTeacherRecord.id}" data-classroom="${myTeacherRecord.classroom}" selected>${myTeacherRecord.tengFirstName} ${myTeacherRecord.tengLastName}</option>`
        : '<option value="">ជ្រើសរើសសាលារៀនជាមុន</option>';

    container.innerHTML = `
        <div class="page-header">
            <div style="display: flex; align-items: center; gap: 16px;">
                <button class="btn-minimal" onclick="navigateTo('#/students')" title="Back to List">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="19" y1="12" x2="5" y2="12"></line>
                        <polyline points="12 19 5 12 12 5"></polyline>
                    </svg>
                </button>
                <div>
                    <h1 style="margin: 0;">បន្ថែមសិស្សថ្មី</h1>
                    <p style="font-size: 14px; color: var(--text-secondary); margin: 4px 0 0;">បំពេញព័ត៌មានលម្អិតរបស់សិស្សខាងក្រោម</p>
                </div>
            </div>
            <div id="add-student-photo-preview" style="width: 60px; height: 60px; border-radius: 16px; background: var(--bg-card); display: flex; align-items: center; justify-content: center; font-size: 32px; overflow: hidden; border: 2px solid var(--primary); box-shadow: var(--shadow);">
                👨‍🎓
            </div>
        </div>

        <form id="add-student-form" onsubmit="handleAddSubmit(event)" style="padding-bottom: 40px;">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 24px;">
                
                <!-- Section 1: Personal Information -->
                <div class="form-section">
                    <div class="form-section-title">ព័ត៌មានផ្ទាល់ខ្លួន</div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="stuId">អត្តលេខសិស្ស *</label>
                            <input type="text" id="stuId" name="stuId" required placeholder="ឧទាហរណ៍: Stu001">
                        </div>
                        <div class="form-group">
                            <label for="gender">ភេទ *</label>
                            <select id="gender" name="gender" required>
                                <option value="">ជ្រើសរើសភេទ</option>
                                <option value="Male">ប្រុស</option>
                                <option value="Female">ស្រី</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="stuKhmerLastName">ត្រកូល (ខ្មែរ)</label>
                            <input type="text" id="stuKhmerLastName" name="stuKhmerLastName" placeholder="តាំង">
                        </div>
                        <div class="form-group">
                            <label for="stuKhmerFirstName">ឈ្មោះ (ខ្មែរ)</label>
                            <input type="text" id="stuKhmerFirstName" name="stuKhmerFirstName" placeholder="សុខា">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="stuEngLastName">ត្រកូល (ឡាតាំង) *</label>
                            <input type="text" id="stuEngLastName" name="stuEngLastName" required placeholder="Tang">
                        </div>
                        <div class="form-group">
                            <label for="stuEngFirstName">ឈ្មោះ (ឡាតាំង) *</label>
                            <input type="text" id="stuEngFirstName" name="stuEngFirstName" required placeholder="Sokha">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="dateOfBirth">ថ្ងៃខែឆ្នាំកំណើត (ថ្ងៃ/ខែ/ឆ្នាំ)</label>
                            <input type="text" id="dateOfBirth" name="dateOfBirth" placeholder="DD/MM/YYYY">
                        </div>
                        <div class="form-group">
                            <label>រូបថត</label>
                            <input type="file" id="photoFile" accept="image/jpeg, image/png" onchange="handleImageUpload(this, 'photoBase64', 'add-student-photo-preview')">
                            <input type="hidden" id="photoBase64" name="photo" value="">
                        </div>
                    </div>
                </div>

                <!-- Section 2: Academic Details -->
                <div class="form-section">
                    <div class="form-section-title">ការសិក្សា</div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="school">សាលារៀន</label>
                            <select id="school" name="school" onchange="handleSchoolSelect(this)" ${isTeacher ? 'style="pointer-events: none; background: var(--bg-card);"' : ''}>
                                ${isTeacher ? '' : '<option value="">ជ្រើសរើសសាលារៀន</option>'}
                                ${schoolOptions}
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="teacher">គ្រូបន្ទុកថ្នាក់ *</label>
                            <select id="teacher" name="teacher" required onchange="handleTeacherSelect(this)" ${isTeacher ? 'style="pointer-events: none; background: var(--bg-card);"' : ''}>
                                ${teacherOptions}
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="classroom">ថ្នាក់រៀន</label>
                            <input type="text" id="classroom" name="classroom" value="${isTeacher && myTeacherRecord ? myTeacherRecord.classroom || '' : ''}" readonly style="background: var(--bg-card); cursor: not-allowed;">
                        </div>
                        <div class="form-group">
                            <label for="status">ស្ថានភាព</label>
                            <select id="status" name="status">
                                <option value="Active">កំពុងរៀន</option>
                                <option value="Inactive">ឈប់រៀន</option>
                                <option value="Graduated">បញ្ចប់ការសិក្សា</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="stuPhoneNumber">លេខទូរស័ព្ទសិស្ស</label>
                        <input type="tel" id="stuPhoneNumber" name="stuPhoneNumber" placeholder="012 345 678">
                    </div>
                    <div class="form-group">
                        <label for="description">ការពិពណ៌នាបន្ថែម</label>
                        <textarea id="description" name="description" rows="2" style="resize: none;"></textarea>
                    </div>
                </div>

                <!-- Section 3: Address Information -->
                <div class="form-section" style="grid-column: 1 / -1;">
                    <div class="form-section-title">ព័ត៌មានអាសយដ្ឋាន</div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 40px;">
                        <div>
                            <div style="font-size: 12px; font-weight: 700; color: var(--primary); margin-bottom: 12px; text-transform: uppercase;">ទីកន្លែងកំណើត</div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="birthVillage">ភូមិ</label>
                                    <input type="text" id="birthVillage" name="birthVillage">
                                </div>
                                <div class="form-group">
                                    <label for="birthCommune">ឃុំ/សង្កាត់</label>
                                    <input type="text" id="birthCommune" name="birthCommune">
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="birthDistrict">ស្រុក/ខណ្ឌ</label>
                                    <input type="text" id="birthDistrict" name="birthDistrict">
                                </div>
                                <div class="form-group">
                                    <label for="birthProvince">ខេត្ត/ក្រុង</label>
                                    <input type="text" id="birthProvince" name="birthProvince">
                                </div>
                            </div>
                        </div>
                        <div>
                            <div style="font-size: 12px; font-weight: 700; color: var(--primary); margin-bottom: 12px; text-transform: uppercase;">អាសយដ្ឋានបច្ចុប្បន្ន</div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="currentVillage">ភូមិ</label>
                                    <input type="text" id="currentVillage" name="currentVillage">
                                </div>
                                <div class="form-group">
                                    <label for="currentCommmune">ឃុំ/សង្កាត់</label>
                                    <input type="text" id="currentCommmune" name="currentCommmune">
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="currentDistrict">ស្រុក/ខណ្ឌ</label>
                                    <input type="text" id="currentDistrict" name="currentDistrict">
                                </div>
                                <div class="form-group">
                                    <label for="currentProvince">ខេត្ត/ក្រុង</label>
                                    <input type="text" id="currentProvince" name="currentProvince">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Section 4: Family Information -->
                <div class="form-section" style="grid-column: 1 / -1;">
                    <div class="form-section-title">ព័ត៌មានគ្រួសារ</div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 40px;">
                        <div style="display: flex; flex-direction: column; gap: 8px;">
                            <div style="font-size: 12px; font-weight: 700; color: var(--primary); text-transform: uppercase; margin-bottom: 4px;">ព័ត៌មានឪពុក</div>
                            <div class="form-row" style="grid-template-columns: 1fr 1fr 1fr;">
                                <div class="form-group">
                                    <label for="fatherName">ឈ្មោះ</label>
                                    <input type="text" id="fatherName" name="fatherName">
                                </div>
                                <div class="form-group">
                                    <label for="fatherJob">មុខរបរ</label>
                                    <input type="text" id="fatherJob" name="fatherJob">
                                </div>
                                <div class="form-group">
                                    <label for="fatherPhone">ទូរស័ព្ទ</label>
                                    <input type="tel" id="fatherPhone" name="fatherPhone">
                                </div>
                            </div>
                        </div>
                        <div style="display: flex; flex-direction: column; gap: 8px;">
                            <div style="font-size: 12px; font-weight: 700; color: var(--primary); text-transform: uppercase; margin-bottom: 4px;">ព័ត៌មានម្តាយ</div>
                            <div class="form-row" style="grid-template-columns: 1fr 1fr 1fr;">
                                <div class="form-group">
                                    <label for="motherName">ឈ្មោះ</label>
                                    <input type="text" id="motherName" name="motherName">
                                </div>
                                <div class="form-group">
                                    <label for="motherJob">មុខរបរ</label>
                                    <input type="text" id="motherJob" name="motherJob">
                                </div>
                                <div class="form-group">
                                    <label for="motherPhone">ទូរស័ព្ទ</label>
                                    <input type="tel" id="motherPhone" name="motherPhone">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="form-actions" style="margin-top: 32px; justify-content: flex-end; position: sticky; bottom: 0; background: var(--bg-body); padding: 16px 0; z-index: 10;">
                <button type="button" class="btn btn-secondary" onclick="navigateTo('#/students')">បោះបង់</button>
                <button type="submit" class="btn btn-primary" style="padding: 12px 40px;">រក្សាទុកទិន្នន័យសិស្ស</button>
            </div>
        </form>
    `;
}

function handleTeacherSelect(selectElement) {
    const selectedOption = selectElement.options[selectElement.selectedIndex];
    const classroom = selectedOption.getAttribute('data-classroom');
    document.getElementById('classroom').value = classroom || '';
}

function handleSchoolSelect(selectElement) {
    const schoolName = selectElement.value;
    const teacherSelect = document.getElementById('teacher');
    const classroomInput = document.getElementById('classroom');

    teacherSelect.innerHTML = '<option value="">Select Teacher</option>';
    classroomInput.value = '';

    if (!schoolName) {
        teacherSelect.innerHTML = '<option value="">Select School First</option>';
        return;
    }

    const teachers = getTeachers();
    let filteredTeachers = teachers.filter(t => t.school === schoolName);

    const currentUser = getCurrentUser();
    if (currentUser && currentUser.role === 'Teacher') {
        filteredTeachers = filteredTeachers.filter(t => (t.tengFirstName + ' ' + t.tengLastName) === currentUser.name);
    }

    if (filteredTeachers.length === 0) {
        teacherSelect.innerHTML = '<option value="">មិនមានគ្រូក្នុងសាលានេះទេ</option>';
    } else {
        teacherSelect.innerHTML += filteredTeachers.map(t =>
            `<option value="${t.id}" data-classroom="${t.classroom}">${t.tengFirstName} ${t.tengLastName}</option>`
        ).join('');

        if (filteredTeachers.length === 1) {
            teacherSelect.value = filteredTeachers[0].id;
            handleTeacherSelect(teacherSelect);
        }
    }
}

function handleAddSubmit(event) {
    event.preventDefault();

    const form = event.target;
    const formData = new FormData(form);

    let stuId = formData.get('stuId').trim();
    if (stuId && !stuId.startsWith('Stu')) {
        stuId = 'Stu' + stuId;
    }

    const school = formData.get('school').trim();

    const students = getStudents();
    const isDuplicate = students.some(s => s.stuId === stuId && s.school === school);
    if (isDuplicate) {
        showAlert(`Error: Student ID "${stuId}" already exists in the selected school.`, 'error');
        return;
    }

    const student = {
        stuId: stuId,
        stuKhmerLastName: formData.get('stuKhmerLastName').trim(),
        stuKhmerFirstName: formData.get('stuKhmerFirstName').trim(),
        stuEngLastName: formData.get('stuEngLastName').trim(),
        stuEngFirstName: formData.get('stuEngFirstName').trim(),
        gender: formData.get('gender'),
        dateOfBirth: formData.get('dateOfBirth'),
        birthVillage: formData.get('birthVillage').trim(),
        birthCommune: formData.get('birthCommune').trim(),
        birthDistrict: formData.get('birthDistrict').trim(),
        birthProvince: formData.get('birthProvince').trim(),
        currentVillage: formData.get('currentVillage').trim(),
        currentCommmune: formData.get('currentCommmune').trim(),
        currentDistrict: formData.get('currentDistrict').trim(),
        currentProvince: formData.get('currentProvince').trim(),
        stuPhoneNumber: formData.get('stuPhoneNumber').trim(),
        fatherName: formData.get('fatherName').trim(),
        fatherJob: formData.get('fatherJob').trim(),
        fatherPhone: formData.get('fatherPhone').trim(),
        motherName: formData.get('motherName').trim(),
        motherJob: formData.get('motherJob').trim(),
        motherPhone: formData.get('motherPhone').trim(),
        school: formData.get('school').trim(),
        teacher: formData.get('teacher'),
        classroom: document.getElementById('classroom').value,
        status: formData.get('status'),
        description: formData.get('description').trim(),
        photo: formData.get('photo') || (formData.get('gender') === 'Female' ? '👩‍🎓' : '👨‍🎓')
    };

    addStudent(student);
    showAlert('Student added successfully!');
    navigateTo('#/students');
}
