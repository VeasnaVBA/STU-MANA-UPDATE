// js/page/scores.js

function renderScoresList() {
    const container = document.getElementById('content-area');
    const currentUser = getCurrentUser();
    const settings = getSettings();
    const today = new Date().getDate();

    // Check if entry is allowed (Admins can always enter, Teachers are restricted)
    const isOutsideWindow = (today < settings.scoreEntryStartDay || today > settings.scoreEntryEndDay);
    const isLocked = currentUser && currentUser.role === 'Teacher' && isOutsideWindow;

    const periods = [
        "First Test", "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December",
        "Semester 1 Exam", "Semester 2 Exam",
        "Semester 1", "Semester 2", "Annual"
    ];

    const periodOptions = periods.map((p, i) => {
        // Add visual separator before Semester 1 Exam group and Semester results group
        let prefix = '';
        if (p === 'Semester 1 Exam') prefix = '<option disabled>──────────────</option>';
        if (p === 'Semester 1') prefix = '<option disabled>──────────────</option>';
        return prefix + `<option value="${p}">${getPeriodName(p)}</option>`;
    }).join('');

    // Show a popup message if it's locked and user is a teacher
    if (isLocked) {
        setTimeout(() => {
            showAlert(`Note: Score entry is only allowed from day ${settings.scoreEntryStartDay} to ${settings.scoreEntryEndDay}. Entry is currently locked.`, 'warning');
        }, 100);
    }

    container.innerHTML = `
        <div class="page-header">
            <div class="header-title">
                <h1>បញ្ជីពិន្ទុសិស្ស</h1>
                <p>គ្រប់គ្រង និងតាមដានលទ្ធផលសិក្សារបស់សិស្សតាមកម្រិតថ្នាក់ មុខវិជ្ជា និងខែ</p>
            </div>
        </div>

        <div style="background: ${isOutsideWindow ? '#fff3e0' : '#e8f5e9'}; padding: 12px 20px; border-radius: var(--radius-md); margin-bottom: 20px; border-left: 5px solid ${isOutsideWindow ? '#ff9800' : '#4caf50'}; display: flex; align-items: center; gap: 12px;">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                ${isOutsideWindow ? '<rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path>' : '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline>'}
            </svg>
            <div style="font-size: 14px; color: ${isOutsideWindow ? '#e65100' : '#2e7d32'};">
                <strong>Score Entry Window:</strong> Day ${settings.scoreEntryStartDay} to ${settings.scoreEntryEndDay} of every month. 
                (Today is day <b>${today}</b> - ${isOutsideWindow ? '<span style="font-weight:bold;">Entry Closed</span>' : '<span style="font-weight:bold;">Entry Open</span>'})
            </div>
        </div>

        <div class="table-controls" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; padding: 20px; background: var(--bg-card); border-radius: var(--radius-md); box-shadow: var(--shadow-sm); margin-bottom: 24px;">
            <div style="display: flex; flex-direction: column; gap: 8px;">
                <label style="font-weight: 700; color: var(--primary); font-size: 14px; display: flex; align-items: center; gap: 6px;">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                    </svg>
                    Grade
                </label>
                <select id="score-grade" class="filter-select" onchange="handleGradeChange()" 
                        style="width: 100%; padding: 10px; font-size: 15px; border: 2px solid var(--border); border-radius: var(--radius-sm); cursor: pointer; background: white; font-weight: 500;">
                    <option value="">-- ជ្រើសរើសថ្នាក់ --</option>
                    ${[7, 8, 9, 10, 11, 12].map(g => `<option value="${g}">ថ្នាក់ទី ${g}</option>`).join('')}
                </select>
            </div>

            <div style="display: flex; flex-direction: column; gap: 8px;">
                <label style="font-weight: 700; color: var(--primary); font-size: 14px; display: flex; align-items: center; gap: 6px;">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path>
                        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path>
                    </svg>
                    មុខវិជ្ជា
                </label>
                <select id="score-subject" class="filter-select" onchange="handleScoreFilterChange()" 
                        style="width: 100%; padding: 10px; font-size: 15px; border: 2px solid var(--border); border-radius: var(--radius-sm); cursor: pointer; background: white; font-weight: 500;" disabled>
                    <option value="">-- ជ្រើសរើសថ្នាក់ជាមុន --</option>
                </select>
            </div>

            <div style="display: flex; flex-direction: column; gap: 8px;">
                <label style="font-weight: 700; color: var(--primary); font-size: 14px; display: flex; align-items: center; gap: 6px;">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                        <line x1="3" y1="10" x2="21" y2="10"></line>
                    </svg>
                    ជ្រើសរើសខែ
                </label>
                <div style="display: flex; gap: 8px;">
                    <select id="score-period" class="filter-select" onchange="handleScoreFilterChange()" 
                            style="flex: 1; padding: 10px; font-size: 15px; border: 2px solid var(--border); border-radius: var(--radius-sm); cursor: pointer; background: white; font-weight: 500;">
                        <option value="">-- Choose Month --</option>
                        ${periodOptions}
                    </select>
                    <button class="btn btn-secondary" onclick="showInputProgress()" title="Check My Progress"
                            style="padding: 0 15px; display: flex; align-items: center; justify-content: center; background: #f8f9fa; border: 2px solid var(--border); color: var(--text-primary); border-radius: var(--radius-sm);">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                            <polyline points="22 4 12 14.01 9 11.01"></polyline>
                        </svg>
                    </button>
                    <button class="btn btn-success" onclick="showExportOptions()" title="Export Scores to Excel"
                            style="padding: 0 15px; display: flex; align-items: center; justify-content: center; background: #2e7d32; border: none; color: white; border-radius: var(--radius-sm);">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                            <polyline points="7 10 12 15 17 10"></polyline>
                            <line x1="12" y1="15" x2="12" y2="3"></line>
                        </svg>
                    </button>
                    <button class="btn btn-primary" onclick="showCoefficientSettings()" title="Settings Coefficient"
                            style="padding: 0 15px; display: flex; align-items: center; justify-content: center; background: #673ab7; border: none; color: white; border-radius: var(--radius-sm); min-width: 45px;">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="3"></circle>
                            <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
                        </svg>
                    </button>
                    <button class="btn btn-info" onclick="showResultsCalculation()" title="Calculate Totals & Averages"
                            style="padding: 0 15px; display: flex; align-items: center; justify-content: center; background: #004ad9; border: none; color: white; border-radius: var(--radius-sm);">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path>
                            <rect x="8" y="2" width="8" height="4" rx="1" ry="1"></rect>
                            <path d="M9 12h6"></path>
                            <path d="M9 16h6"></path>
                            <path d="M12 8h.01"></path>
                        </svg>
                    </button>
                </div>
            </div>
        </div>

        <div id="grade-scale-legend" style="display: none; margin-bottom: 16px; padding: 12px 20px; background: #f8f9fa; border: 1px solid var(--border); border-radius: var(--radius-md); font-size: 13px;">
            <div style="display: flex; align-items: center; gap: 15px; flex-wrap: wrap;">
                <strong style="color: var(--text-main); min-width: 100px;">Grade Scale:</strong>
                <div id="scale-ranges" style="display: flex; gap: 20px; flex-wrap: wrap; flex: 1;">
                    <!-- Filled by JS -->
                </div>
            </div>
        </div>

        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th style="width: 50px; text-align: center;">ល.រ</th>
                        <th style="width: 100px;">អត្តលេខ</th>
                        <th style="width: 180px;">នាមត្រកូល</th>
                        <th style="width: 150px;">នាមខ្លួន</th>
                        <th style="width: 70px; text-align: center;">ភេទ</th>
                        <th style="width: 110px; text-align: center;">ថ្ងៃខែឆ្នាំកំណើត</th>
                        <th style="width: 90px; text-align: center;">ថ្នាក់រៀន</th>
                        <th style="width: 130px; text-align: center;" id="score-header-label">ពិន្ទុ</th>
                        <th style="width: 70px; text-align: center;">កម្រិត</th>
                    </tr>
                </thead>
                <tbody id="scores-table-body">
                    <tr><td colspan="9" style="text-align: center; padding: 40px; color: var(--text-secondary);">សូមជ្រើសរើស ថ្នាក់ មុខវិជ្ជា និងខែ ដើម្បីមើលបញ្ជីឈ្មោះសិស្ស។</td></tr>
                </tbody>
            </table>
        </div>

        <div id="scores-footer" style="display: none; margin-top: 24px; padding: 16px; background: var(--bg-card); border-radius: var(--radius-md); box-shadow: var(--shadow-sm); justify-content: flex-end;">
            <button class="btn btn-primary" onclick="handleSaveAllScores()" style="padding: 12px 32px; font-weight: 600; font-size: 15px;">
                រក្សាទុកពិន្ទុទាំងអស់
            </button>
        </div>
    `;

    // Auto-select grade for Teachers
    if (currentUser && currentUser.role === 'Teacher') {
        const teachers = getTeachers();
        const myTeacherRecord = teachers.find(t => (t.tengFirstName + ' ' + t.tengLastName) === currentUser.name);
        if (myTeacherRecord && myTeacherRecord.classroom) {
            const gradeMatch = myTeacherRecord.classroom.match(/^\d+/);
            if (gradeMatch) {
                const grade = gradeMatch[0];
                const gradeSelect = document.getElementById('score-grade');
                if (gradeSelect) {
                    gradeSelect.value = grade;
                    gradeSelect.disabled = true;
                    handleGradeChange();
                }
            }
        }
    }
}

function handleGradeChange() {
    const gradeSelect = document.getElementById('score-grade');
    const subjectSelect = document.getElementById('score-subject');
    if (!gradeSelect || !subjectSelect) return;

    const grade = gradeSelect.value;
    if (!grade) {
        subjectSelect.innerHTML = '<option value="">-- Choose Grade First --</option>';
        subjectSelect.disabled = true;
    } else {
        const allSubjects = getSubjects();
        subjectSelect.innerHTML = '<option value="">-- Select Subject --</option>' +
            allSubjects.map(s => `<option value="${s.id}">${s.subjectName}</option>`).join('');
        subjectSelect.disabled = false;
    }
    refreshScoresTable();
}

function refreshScoresTable() {
    const tbody = document.getElementById('scores-table-body');
    const footer = document.getElementById('scores-footer');
    const legend = document.getElementById('grade-scale-legend');
    const scaleContainer = document.getElementById('scale-ranges');

    const gradeSelect = document.getElementById('score-grade');
    const periodSelect = document.getElementById('score-period');
    const subjectSelect = document.getElementById('score-subject');

    if (!tbody || !gradeSelect || !periodSelect || !subjectSelect) return;

    const grade = gradeSelect.value;
    const period = periodSelect.value;
    const subjectId = subjectSelect.value;

    const currentUser = getCurrentUser();
    const settings = getSettings();
    const today = new Date().getDate();
    const isLocked = currentUser && currentUser.role === 'Teacher' && (today < settings.scoreEntryStartDay || today > settings.scoreEntryEndDay);

    if (!grade || !period || !subjectId) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; padding: 40px; color: var(--text-secondary);">Please select grade, subject, and month to view students.</td></tr>`;
        if (footer) footer.style.display = 'none';
        if (legend) legend.style.display = 'none';
        return;
    }

    const subjects = getSubjects();
    const currentSubject = subjects.find(s => s.id === subjectId);
    const maxScore = (currentSubject && currentSubject.maxScores) ? (currentSubject.maxScores[grade] || 100) : 100;

    if (legend && scaleContainer) {
        legend.style.display = 'block';
        const ranges = [
            { g: 'A', min: 90 }, { g: 'B', min: 80 }, { g: 'C', min: 70 },
            { g: 'D', min: 60 }, { g: 'E', min: 50 }, { g: 'F', min: 0 }
        ];

        scaleContainer.innerHTML = ranges.map(r => {
            const minScore = (r.min / 100) * maxScore;
            const label = r.g === 'F' ? `< ${minScore.toFixed(1)}` : `≥ ${minScore.toFixed(1)}`;
            return `
                <div style="display: flex; align-items: center; gap: 6px;">
                    ${renderGradeBadge(r.g)}
                    <span style="font-weight: 600;">${label}</span>
                </div>
            `;
        }).join('');
    }

    const headerLabel = document.getElementById('score-header-label');
    if (headerLabel) headerLabel.innerHTML = `Score (Max: ${maxScore})`;

    const monthMap = {
        "January": 1, "February": 2, "March": 3, "April": 4, "May": 5, "June": 6,
        "July": 7, "August": 8, "September": 9, "October": 10, "November": 11, "December": 12,
        "Semester 1": 6, "Semester 2": 12, "First Test": 3
    };

    let students = getFilteredStudents();
    students = students.filter(s => {
        // Basic grade check
        if (!s.classroom || !s.classroom.startsWith(grade)) return false;

        // Inactive logic: Show if Active, or if Inactive but period is before/during inactive date
        if (s.status === 'Inactive') {
            if (!s.inactiveDate) return false; // Hide old inactive students without dates

            const [iYear, iMonth] = s.inactiveDate.split('-').map(Number);
            const selectedMonth = monthMap[period] || 0;
            const currentYear = new Date().getFullYear();

            // If selected month is in the past compared to inactive date, show them
            if (currentYear < iYear) return true;
            if (currentYear === iYear && selectedMonth <= iMonth) return true;

            return false;
        }

        return true; // Active or Graduated students usually visible
    });

    if (students.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; padding: 40px;">No students found in Grade ${grade}.</td></tr>`;
        if (footer) footer.style.display = 'none';
        return;
    }

    const existingScores = getScoresByPeriodAndSubject(period, subjectId);
    const scoreMap = {};
    existingScores.forEach(s => scoreMap[s.studentId] = s.score);

    tbody.innerHTML = students.map((s, index) => {
        const scoreValue = scoreMap[s.id] || '';
        return `
            <tr data-student-id="${s.id}">
                <td style="text-align: center;">${index + 1}</td>
                <td style="font-weight: 500;">${s.stuId || '-'}</td>
                <td>${s.stuKhmerLastName || '-'}</td>
                <td>${s.stuKhmerFirstName || '-'}</td>
                <td style="text-align: center;">${s.gender || '-'}</td>
                <td style="text-align: center; font-size: 13px;">${(() => {
                    const dobValue = s.dateOfBirth || s.dob;
                    if (!dobValue) return '-';
                    const dob = String(dobValue);
                    const parts = dob.split(/[-/]/);
                    if (parts.length === 3) {
                        if (parts[0].length === 4) return `${parts[2]}/${parts[1]}/${parts[0]}`;
                        return `${parts[0]}/${parts[1]}/${parts[2]}`;
                    }
                    return dob;
                })()}</td>
                <td style="text-align: center; font-size: 13px;">${s.classroom || '-'}</td>
                <td style="text-align: center;">
                    <div style="display: flex; align-items: center; justify-content: center; gap: 4px;">
                        <input type="number" step="0.01" min="0" max="${maxScore}" class="score-input" value="${scoreValue}" 
                               data-max="${maxScore}"
                               ${isLocked ? 'disabled' : ''}
                               style="width: 80px; padding: 6px; text-align: center; border: 1px solid var(--border); border-radius: 4px; font-weight: 600; ${isLocked ? 'background: #f1f1f1; cursor: not-allowed;' : ''}"
                               onkeydown="handleScoreInputKey(event)"
                               oninput="validateScoreInput(this)">
                    </div>
                </td>
                <td style="text-align: center;" class="grade-cell">
                    ${renderGradeBadge(calculateGrade(scoreValue, maxScore))}
                </td>
            </tr>
        `;
    }).join('');

    if (footer) {
        footer.style.display = 'flex';
        const submitBtn = footer.querySelector('button');
        if (submitBtn) {
            submitBtn.disabled = isLocked;
            if (isLocked) {
                submitBtn.style.opacity = '0.5';
                submitBtn.style.cursor = 'not-allowed';
            } else {
                submitBtn.style.opacity = '1';
                submitBtn.style.cursor = 'pointer';
            }
        }
    }
}

function validateScoreInput(input) {
    const val = parseFloat(input.value);
    const max = parseFloat(input.getAttribute('data-max'));
    const tr = input.closest('tr');
    const gradeCell = tr.querySelector('.grade-cell');

    if (val > max) {
        input.style.borderColor = 'red';
        input.style.color = 'red';
        if (gradeCell) gradeCell.innerHTML = '<span class="grade-badge" style="background: #FFEbee; color: #C62828;">Error</span>';
    } else {
        input.style.borderColor = 'var(--border)';
        input.style.color = 'inherit';
        if (gradeCell) {
            const grade = calculateGrade(input.value, max);
            gradeCell.innerHTML = renderGradeBadge(grade);
        }
    }
}



function handleScoreInputKey(event) {
    if (event.key === 'Enter') {
        const tr = event.target.closest('tr');
        const nextTr = tr.nextElementSibling;
        if (nextTr) {
            const nextInput = nextTr.querySelector('.score-input');
            if (nextInput) nextInput.focus();
        }
    }
}

function handleScoreFilterChange() {
    refreshScoresTable();
}

function handleSaveAllScores() {
    const currentUser = getCurrentUser();
    const settings = getSettings();
    const today = new Date().getDate();
    const isLocked = currentUser && currentUser.role === 'Teacher' && (today < settings.scoreEntryStartDay || today > settings.scoreEntryEndDay);

    if (isLocked) {
        showAlert('Score entry window is closed. You cannot save scores at this time.', 'error');
        return;
    }

    const periodSelect = document.getElementById('score-period');
    const subjectSelect = document.getElementById('score-subject');
    if (!periodSelect || !subjectSelect) return;

    const period = periodSelect.value;
    const subjectId = subjectSelect.value;
    const rows = document.querySelectorAll('#scores-table-body tr');

    let count = 0;
    let hasError = false;

    rows.forEach(row => {
        const studentId = row.getAttribute('data-student-id');
        const input = row.querySelector('.score-input');
        if (studentId && input) {
            const val = parseFloat(input.value);
            const max = parseFloat(input.getAttribute('data-max'));
            if (val > max) {
                hasError = true;
            } else if (input.value !== '') {
                saveScore(studentId, period, subjectId, input.value);
                count++;
            }
        }
    });

    if (hasError) {
        showAlert('Some scores were higher than the maximum allowed. Please check the red boxes.', 'error');
    } else {
        showAlert(`Successfully saved ${count} scores for ${period}!`);
    }
}

function showInputProgress() {
    const grade = document.getElementById('score-grade').value;
    const period = document.getElementById('score-period').value;

    if (!grade || !period) {
        showAlert('Please select both a Grade and an Assessment Period first.', 'info');
        return;
    }

    const subjects = getSubjects();
    const students = getFilteredStudents().filter(s => s.classroom && s.classroom.startsWith(grade));

    if (students.length === 0) {
        showAlert(`No students found for Grade ${grade}.`, 'error');
        return;
    }

    const progressData = subjects.map(subject => {
        const scores = getScoresByPeriodAndSubject(period, subject.id);
        const gradeStudentIds = students.map(s => s.id);
        const scoresInGrade = scores.filter(s => gradeStudentIds.includes(s.studentId) && s.score !== '');

        return {
            name: subject.subjectName,
            id: subject.subjectId,
            count: scoresInGrade.length,
            total: students.length,
            isComplete: scoresInGrade.length === students.length && students.length > 0
        };
    });

    const completedCount = progressData.filter(p => p.isComplete).length;
    const totalSubjects = subjects.length;
    const progressPercent = Math.round((completedCount / totalSubjects) * 100);

    const html = `
        <div style="padding: 24px; width: 800px; max-width: 95vw; margin: 0 auto;">
            <div style="background: var(--bg-card); border-radius: 32px; box-shadow: 0 10px 40px rgba(0,0,0,0.15); overflow: hidden; font-family: var(--font-family); border: 1px solid var(--border);">
                
                <!-- Header -->
                <div style="padding: 24px; display: flex; gap: 20px; align-items: flex-start;">
                    <div style="width: 80px; height: 80px; border-radius: 20px; background: #EEF2FF; border: 1px solid #E0E7FF; flex-shrink: 0; display: flex; align-items: center; justify-content: center; color: #4F46E5;">
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M12 20v-6M6 20V10M18 20V4"></path>
                        </svg>
                    </div>

                    <div style="flex: 1;">
                        <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 8px;">
                            <span style="width: 8px; height: 8px; border-radius: 50%; background: ${progressPercent === 100 ? '#4ADE80' : '#FBBF24'}; display: inline-block;"></span>
                            <span style="font-size: 12px; font-weight: 600; color: var(--text-secondary);">${progressPercent === 100 ? 'រួចរាល់' : 'កំពុងបញ្ចូល'}</span>
                        </div>
                        
                        <h2 style="margin: 0; font-size: 20px; font-weight: 800; color: var(--text-primary); line-height: 1.2;">វឌ្ឍនភាពការងារ</h2>
                        <div style="font-size: 14px; color: var(--text-secondary); margin-top: 2px;">
                            ថ្នាក់ទី: ${grade} | ${getPeriodName(period)}
                        </div>
                    </div>
                </div>

                <!-- Summary Stats -->
                <div style="padding: 0 24px 24px; display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px;">
                    <div style="padding: 15px 10px; border: 1px solid var(--border); border-radius: 20px; text-align: center; background: var(--bg-body);">
                        <div style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; font-weight: 700; margin-bottom: 4px;">មុខវិជ្ជា</div>
                        <div style="font-size: 16px; font-weight: 800; color: var(--text-primary);">${completedCount}/${totalSubjects}</div>
                    </div>
                    <div style="padding: 15px 10px; border: 1px solid var(--border); border-radius: 20px; text-align: center; background: var(--bg-body);">
                        <div style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; font-weight: 700; margin-bottom: 4px;">សិស្សសរុប</div>
                        <div style="font-size: 16px; font-weight: 800; color: var(--text-primary);">${students.length} នាក់</div>
                    </div>
                    <div style="padding: 15px 10px; border: 1px solid var(--border); border-radius: 20px; text-align: center; background: ${progressPercent === 100 ? '#ECFDF5' : '#FFFBEB'}; border-color: ${progressPercent === 100 ? '#A7F3D0' : '#FEF3C7'};">
                        <div style="font-size: 10px; color: ${progressPercent === 100 ? '#059669' : '#D97706'}; text-transform: uppercase; font-weight: 700; margin-bottom: 4px;">ភាគរយ</div>
                        <div style="font-size: 16px; font-weight: 800; color: ${progressPercent === 100 ? '#059669' : '#D97706'};">${progressPercent}%</div>
                    </div>
                </div>

                <!-- Subject List Header -->
                <div style="padding: 0 24px 10px;">
                    <div style="font-size: 11px; font-weight: 800; text-transform: uppercase; color: #4F46E5; display: flex; align-items: center; gap: 8px;">
                        <span>បញ្ជីមុខវិជ្ជា</span>
                        <div style="flex: 1; height: 1px; background: var(--border);"></div>
                    </div>
                </div>

                <!-- Scrollable List -->
                <div style="padding: 0 24px 24px; max-height: 350px; overflow-y: auto;">
                    <div style="display: flex; flex-direction: column; gap: 8px;">
                        ${progressData.map(p => `
                            <div style="display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; background: ${p.isComplete ? '#F0FDF4' : 'var(--bg-body)'}; border: 1px solid ${p.isComplete ? '#DCFCE7' : 'var(--border)'}; border-radius: 16px;">
                                <div style="display: flex; align-items: center; gap: 12px;">
                                    <div style="width: 24px; height: 24px; border-radius: 50%; background: ${p.isComplete ? '#4ADE80' : '#E2E8F0'}; display: flex; align-items: center; justify-content: center; color: white;">
                                        ${p.isComplete ? `
                                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="4">
                                                <polyline points="20 6 9 17 4 12"></polyline>
                                            </svg>
                                        ` : `
                                            <div style="width: 6px; height: 6px; border-radius: 50%; background: #94A3B8;"></div>
                                        `}
                                    </div>
                                    <div>
                                        <div style="font-weight: 700; font-size: 13px; color: var(--text-primary);">${p.name}</div>
                                        <div style="font-size: 11px; color: var(--text-secondary);">${p.id}</div>
                                    </div>
                                </div>
                                <div style="text-align: right;">
                                    <div style="font-size: 13px; font-weight: 800; color: ${p.isComplete ? '#059669' : 'var(--text-primary)'};">
                                        ${p.count} / ${p.total}
                                    </div>
                                    <div style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; font-weight: 600;">សិស្ស</div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <!-- Footer Actions -->
                <div style="padding: 12px 24px; background: var(--bg-body); border-top: 1px solid var(--border); display: flex; justify-content: flex-end;">
                    <button onclick="closeModal()" style="border: none; background: #FEE2E2; color: #EF4444; padding: 8px 20px; border-radius: 10px; font-size: 12px; font-weight: 800; cursor: pointer; transition: all 0.2s;">បិទ</button>
                </div>

            </div>
        </div>
    `;
    openModal(html, true);
}

function showExportOptions() {
    const grade = document.getElementById('score-grade').value;
    const period = document.getElementById('score-period').value;

    if (!grade || !period) {
        showAlert('Please select Grade and Period first.', 'info');
        return;
    }

    const html = `
        <div style="padding: 24px; max-width: 520px; margin: 0 auto;">
            <div style="background: var(--bg-card); border-radius: 32px; box-shadow: 0 10px 40px rgba(0,0,0,0.15); overflow: hidden; font-family: var(--font-family); border: 1px solid var(--border);">
                
                <!-- Header -->
                <div style="padding: 24px; display: flex; gap: 20px; align-items: flex-start;">
                    <div style="width: 80px; height: 80px; border-radius: 20px; background: #ECFDF5; border: 1px solid #D1FAE5; flex-shrink: 0; display: flex; align-items: center; justify-content: center; color: #10B981;">
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                            <polyline points="7 10 12 15 17 10"></polyline>
                            <line x1="12" y1="15" x2="12" y2="3"></line>
                        </svg>
                    </div>

                    <div style="flex: 1;">
                        <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 8px;">
                            <span style="width: 8px; height: 8px; border-radius: 50%; background: #10B981; display: inline-block;"></span>
                            <span style="font-size: 12px; font-weight: 600; color: var(--text-secondary);">ត្រៀមរួចរាល់</span>
                        </div>
                        
                        <h2 style="margin: 0; font-size: 20px; font-weight: 800; color: var(--text-primary); line-height: 1.2;">ទាញយកទិន្នន័យ (Excel)</h2>
                        <div style="font-size: 14px; color: var(--text-secondary); margin-top: 2px;">
                            ថ្នាក់ទី: ${grade} | ${getPeriodName(period)}
                        </div>
                    </div>
                </div>

                <!-- Content Area -->
                <div style="padding: 0 24px 24px;">
                    <div style="font-size: 11px; font-weight: 800; text-transform: uppercase; color: #10B981; margin-bottom: 12px; display: flex; align-items: center; gap: 8px;">
                        <span>ជម្រើសនៃការទាញយក</span>
                        <div style="flex: 1; height: 1px; background: var(--border);"></div>
                    </div>
                    
                    <div style="display: flex; flex-direction: column; gap: 12px;">
                        <button onclick="handleExportClick('current')" style="width: 100%; padding: 16px; background: white; border: 1px solid var(--border); border-radius: 16px; display: flex; align-items: center; gap: 15px; cursor: pointer; transition: all 0.2s; text-align: left; outline: none;">
                            <div style="width: 40px; height: 40px; border-radius: 12px; background: #F0FDF4; color: #16A34A; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                                    <polyline points="14 2 14 8 20 8"></polyline>
                                </svg>
                            </div>
                            <div>
                                <div style="font-weight: 700; font-size: 14px; color: var(--text-primary);">ទាញយកមុខវិជ្ជាបច្ចុប្បន្ន</div>
                                <div style="font-size: 11px; color: var(--text-secondary);">Export only the selected subject</div>
                            </div>
                        </button>

                        <button onclick="handleExportClick('all')" style="width: 100%; padding: 16px; background: white; border: 1px solid var(--border); border-radius: 16px; display: flex; align-items: center; gap: 15px; cursor: pointer; transition: all 0.2s; text-align: left; outline: none;">
                            <div style="width: 40px; height: 40px; border-radius: 12px; background: #EEF2FF; color: #4F46E5; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                                    <line x1="3" y1="9" x2="21" y2="9"></line>
                                    <line x1="9" y1="21" x2="9" y2="9"></line>
                                </svg>
                            </div>
                            <div>
                                <div style="font-weight: 700; font-size: 14px; color: var(--text-primary);">ទាញយកគ្រប់មុខវិជ្ជាទាំងអស់</div>
                                <div style="font-size: 11px; color: var(--text-secondary);">Export a combined sheet with all subjects</div>
                            </div>
                        </button>
                    </div>
                </div>

                <!-- Footer Actions -->
                <div style="padding: 12px 24px; background: var(--bg-body); border-top: 1px solid var(--border); display: flex; justify-content: flex-end;">
                    <button onclick="closeModal()" style="border: none; background: #FEE2E2; color: #EF4444; padding: 8px 20px; border-radius: 10px; font-size: 12px; font-weight: 800; cursor: pointer; transition: all 0.2s;">បោះបង់</button>
                </div>

            </div>
        </div>
    `;
    openModal(html, true);
}

function handleExportClick(type) {
    closeModal();
    if (type === 'current') {
        exportCurrentSubject();
    } else {
        exportAllSubjects();
    }
}

function exportCurrentSubject() {
    const grade = document.getElementById('score-grade').value;
    const period = document.getElementById('score-period').value;
    const subjectId = document.getElementById('score-subject').value;

    if (!subjectId) {
        showAlert('Please select a subject first.', 'info');
        return;
    }

    const subjects = getSubjects();
    const subject = subjects.find(s => s.id === subjectId);
    const students = getFilteredStudents().filter(s => s.classroom && s.classroom.startsWith(grade));
    const scores = getScoresByPeriodAndSubject(period, subjectId);
    const maxScore = subject.maxScores[grade] || 100;

    const data = students.map((s, i) => {
        const scoreObj = scores.find(sc => sc.studentId === s.id);
        const score = scoreObj ? scoreObj.score : '';
        return {
            'No': i + 1,
            'Student ID': s.stuId,
            'Last Name (KH)': s.stuKhmerLastName,
            'First Name (KH)': s.stuKhmerFirstName,
            'Gender': s.gender,
            'Score': score,
            'Grade': calculateGrade(score, maxScore)
        };
    });

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Scores");
    XLSX.writeFile(wb, `Scores_Grade${grade}_${subject.subjectName}_${period}.xlsx`);
    showAlert('Exporting current subject...');
}

function exportAllSubjects() {
    const grade = document.getElementById('score-grade').value;
    const period = document.getElementById('score-period').value;
    const subjects = getSubjects();
    const students = getFilteredStudents().filter(s => s.classroom && s.classroom.startsWith(grade));

    const data = students.map((s, i) => {
        const row = {
            'No': i + 1,
            'Student ID': s.stuId,
            'Name': `${s.stuKhmerLastName} ${s.stuKhmerFirstName}`,
            'Gender': s.gender
        };

        subjects.forEach(sub => {
            const scores = getScoresByPeriodAndSubject(period, sub.id);
            const scoreObj = scores.find(sc => sc.studentId === s.id);
            row[sub.subjectName] = scoreObj ? scoreObj.score : '';
        });

        return row;
    });

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Class Summary");
    XLSX.writeFile(wb, `Class_Scores_Grade${grade}_${period}_All_Subjects.xlsx`);
    showAlert('Exporting all subjects summary...');
}

function showResultsCalculation() {
    const grade = document.getElementById('score-grade').value;
    const period = document.getElementById('score-period').value;

    if (!grade || !period) {
        showAlert('Please select Grade and Period first.', 'info');
        return;
    }

    if (!window.currentCalculatedResults || window.currentCalculatedResults.grade !== grade || window.currentCalculatedResults.period !== period) {
        const savedData = localStorage.getItem(`calc_${grade}_${period}`);
        if (savedData) {
            try {
                const parsed = JSON.parse(savedData);
                window.currentCalculatedResults = {
                    grade,
                    period,
                    coeff: parsed.coeff,
                    selectedMonthNames: parsed.selectedMonthNames,
                    data: null
                };
            } catch (e) { }
        }
    }

    let selectionUI = '';
    const isSpecialPeriod = ['Semester 1', 'Semester 2'].includes(period);
    const isAnnual = period === 'Annual';

    if (isSpecialPeriod) {
        const monthList = [
            "First Test", "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ];
        let savedMonths = [];
        if (window.currentCalculatedResults && window.currentCalculatedResults.grade === grade && window.currentCalculatedResults.period === period && window.currentCalculatedResults.selectedMonthNames) {
            savedMonths = window.currentCalculatedResults.selectedMonthNames;
        }

        selectionUI = `
            <div style="margin-bottom: 20px; padding: 15px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                    <label style="font-weight: 700; color: #475569;">Select Months to include in ${getPeriodName(period)} Average (Max 6):</label>
                    <span id="selection-count" style="font-size: 12px; font-weight: 700; color: var(--primary);">${savedMonths.length} Selected</span>
                </div>
                <div style="display: flex; flex-wrap: wrap; gap: 10px;">
                    ${monthList.map(m => {
            const isChecked = savedMonths.includes(m);
            const bg = isChecked ? '#eef2ff' : 'white';
            const border = isChecked ? 'var(--primary)' : '#cbd5e1';
            return `
                        <label class="month-checkbox-label" style="display: flex; align-items: center; gap: 8px; cursor: pointer; background: ${bg}; padding: 8px 16px; border-radius: 8px; border: 1px solid ${border}; font-size: 13px; transition: all 0.2s;">
                            <input type="checkbox" name="selected-months" value="${m}" onchange="handleMonthSelectionChange(this)" style="width: 16px; height: 16px;" ${isChecked ? 'checked' : ''}>
                            ${getPeriodName(m)}
                        </label>
                        `;
        }).join('')}
                </div>
            </div>
        `;
    }

    const html = `
        <div style="padding: 24px; width: 95vw; max-width: 1400px; margin: 0 auto;">
            <div style="background: var(--bg-card); border-radius: 32px; box-shadow: 0 10px 40px rgba(0,0,0,0.15); overflow: hidden; font-family: var(--font-family); border: 1px solid var(--border); display: flex; flex-direction: column; max-height: 90vh;">
                
                <!-- Header Section -->
                <div style="padding: 24px; display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid var(--border);">
                    <div style="display: flex; align-items: center; gap: 20px;">
                        <div style="width: 60px; height: 60px; border-radius: 16px; background: #EEF2FF; border: 1px solid #E0E7FF; flex-shrink: 0; display: flex; align-items: center; justify-content: center; color: #4F46E5;">
                            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path>
                                <rect x="8" y="2" width="8" height="4" rx="1" ry="1"></rect>
                            </svg>
                        </div>
                        <div>
                            <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
                                <span style="width: 8px; height: 8px; border-radius: 50%; background: #4ADE80; display: inline-block;"></span>
                                <span style="font-size: 11px; font-weight: 700; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.5px;">ការបូកសរុបពិន្ទុ</span>
                            </div>
                            <h2 style="margin: 0; font-size: 22px; font-weight: 800; color: var(--text-primary); line-height: 1.2;">តារាងលទ្ធផល និងចំណាត់ថ្នាក់</h2>
                            <div style="font-size: 14px; color: var(--text-secondary); margin-top: 2px;">
                                ថ្នាក់ទី: ${grade} | ${getPeriodName(period)}
                            </div>
                        </div>
                    </div>

                    <!-- Actions Bar -->
                    <div style="display: flex; align-items: center; gap: 12px;">
                        ${(!isSpecialPeriod && !isAnnual) ? `
                            <div style="display: flex; align-items: center; gap: 10px; background: var(--bg-body); padding: 6px 12px; border-radius: 12px; border: 1px solid var(--border);">
                                <label style="font-size: 11px; font-weight: 800; color: var(--text-secondary); text-transform: uppercase;">មេគុណ:</label>
                                <input type="number" id="result-coefficient" value="${window.currentCalculatedResults && window.currentCalculatedResults.coeff ? window.currentCalculatedResults.coeff : getPeriodCoefficient(period)}" step="0.1" min="1" 
                                       style="width: 70px; border: none; background: transparent; font-weight: 800; font-size: 15px; color: #4F46E5; outline: none; text-align: center;">
                            </div>
                        ` : ''}
                        <button onclick="clearResultsCalculation()" style="background: white; border: 1px solid var(--border); padding: 10px 16px; border-radius: 12px; font-size: 13px; font-weight: 700; color: #64748b; cursor: pointer;">សម្អាត</button>
                        <button onclick="calculateAndShowResultsTable()" style="background: #4F46E5; border: none; padding: 10px 24px; border-radius: 12px; font-size: 13px; font-weight: 700; color: white; cursor: pointer; box-shadow: 0 4px 12px rgba(79,70,229,0.2);">គណនា</button>
                    </div>
                </div>

                <!-- Scrollable Content Section -->
                <div style="flex: 1; overflow-y: auto; padding: 24px;">
                    ${selectionUI}
                    <div id="results-table-container" style="border: 1px solid var(--border); border-radius: 16px; background: white; overflow: auto; min-height: 400px;">
                        <div style="text-align: center; padding: 100px 40px; color: var(--text-secondary);">
                            <div style="margin-bottom: 20px; opacity: 0.5;">
                                <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1">
                                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                                    <polyline points="14 2 14 8 20 8"></polyline>
                                </svg>
                            </div>
                            <p style="margin: 0; font-size: 16px; font-weight: 600;">សូមចុចប៊ូតុង "គណនា" ដើម្បីទាញយកទិន្នន័យ</p>
                            <p style="margin: 5px 0 0; font-size: 13px;">Click "Calculate" to generate the full results matrix.</p>
                        </div>
                    </div>
                </div>

                <!-- Footer Section -->
                <div style="padding: 16px 24px; background: var(--bg-body); border-top: 1px solid var(--border); display: flex; justify-content: flex-end; align-items: center; gap: 12px;">
                    <button onclick="closeModal()" style="border: none; background: #FEE2E2; color: #EF4444; padding: 10px 24px; border-radius: 12px; font-size: 13px; font-weight: 800; cursor: pointer;">បិទ</button>
                    <button id="export-results-btn" style="display: none; border: none; background: #10B981; color: white; padding: 10px 24px; border-radius: 12px; font-size: 13px; font-weight: 800; cursor: pointer; box-shadow: 0 4px 12px rgba(16,185,129,0.2);" onclick="exportResultsSummary()">ទាញយក Excel</button>
                </div>

            </div>
        </div>
    `;
    openModal(html, true);

    if (window.currentCalculatedResults && window.currentCalculatedResults.grade === grade && window.currentCalculatedResults.period === period) {
        setTimeout(calculateAndShowResultsTable, 50);
    }
}

function clearResultsCalculation() {
    const grade = document.getElementById('score-grade').value;
    const period = document.getElementById('score-period').value;
    window.currentCalculatedResults = null;
    localStorage.removeItem(`calc_${grade}_${period}`);

    document.querySelectorAll('input[name="selected-months"]').forEach(cb => {
        cb.checked = false;
        const label = cb.closest('.month-checkbox-label');
        if (label) {
            label.style.borderColor = '#cbd5e1';
            label.style.background = 'white';
        }
    });

    const countEl = document.getElementById('selection-count');
    if (countEl) countEl.textContent = '0 Selected';

    document.getElementById('results-table-container').innerHTML = `
        <div style="text-align: center; padding: 100px 40px; color: var(--text-secondary);">
            <p style="margin: 0; font-size: 16px; font-weight: 500;">Click "Calculate" to generate the full results matrix.</p>
        </div>
    `;

    const exportBtn = document.getElementById('export-results-btn');
    if (exportBtn) exportBtn.style.display = 'none';
}

function handleMonthSelectionChange(checkbox) {
    const checked = document.querySelectorAll('input[name="selected-months"]:checked');
    const countEl = document.getElementById('selection-count');

    if (checked.length > 6) {
        checkbox.checked = false;
        showAlert('You can only select up to 6 months per calculation.', 'warning');
        return;
    }

    if (countEl) countEl.textContent = `${checked.length} Selected`;

    // Update style
    const label = checkbox.closest('.month-checkbox-label');
    if (checkbox.checked) {
        label.style.borderColor = 'var(--primary)';
        label.style.background = '#eef2ff';
    } else {
        label.style.borderColor = '#cbd5e1';
        label.style.background = 'white';
    }
}

function calculateAndShowResultsTable() {
    const grade = document.getElementById('score-grade').value;
    const period = document.getElementById('score-period').value;
    const coeffInput = document.getElementById('result-coefficient');
    const coeffValue = coeffInput ? (parseFloat(coeffInput.value) || getPeriodCoefficient(period)) : getPeriodCoefficient(period);

    const isSemester = ['Semester 1', 'Semester 2'].includes(period);
    const isAnnual = period === 'Annual';
    const selectedMonthNames = Array.from(document.querySelectorAll('input[name="selected-months"]:checked')).map(cb => cb.value);

    // Check if we can use cached results
    const cached = window.currentCalculatedResults;
    if (cached && cached.data && cached.grade === grade && cached.period === period && cached.coeff === coeffValue) {
        const sameMonths = (!cached.selectedMonthNames && selectedMonthNames.length === 0) ||
            (cached.selectedMonthNames && cached.selectedMonthNames.length === selectedMonthNames.length &&
                cached.selectedMonthNames.every((v, i) => v === selectedMonthNames[i]));

        if (!isSemester || sameMonths) {
            renderResultsTableHTML(cached.data, isAnnual, isSemester, selectedMonthNames, getSubjects(), period, coeffValue);
            showAlert('Showing existing results (no changes detected).', 'info');
            return;
        }
    }

    if (isSemester && selectedMonthNames.length === 0) {
        showAlert('Please select at least one month for this calculation.', 'error');
        return;
    }

    const subjects = getSubjects();
    const students = getFilteredStudents().filter(s => s.classroom && s.classroom.startsWith(grade));

    // Helper to get total score and coefficient for a specific period
    const getPeriodTotals = (studentId, pName) => {
        let total = 0;
        const subScores = {};
        subjects.forEach(sub => {
            const scores = getScoresByPeriodAndSubject(pName, sub.id);
            const scoreObj = scores.find(sc => sc.studentId === studentId);
            const scoreVal = (scoreObj && scoreObj.score !== '' && scoreObj.score !== null) ? parseFloat(scoreObj.score) : 0;
            total += scoreVal;
            subScores[sub.id] = scoreVal;
        });
        const coeff = getPeriodCoefficient(pName);
        return { total, coeff, average: coeff > 0 ? total / coeff : 0, subScores };
    };

    const results = students.map(s => {
        let finalAverage = 0;
        let finalTotal = 0;
        let finalCoeff = 0;
        const subScores = {};

        if (isAnnual) {
            // Annual = (Semester 1 Average + Semester 2 Average) / 2
            // For Annual, we use standard month blocks as defaults
            const s1Months = ["First Test", "January", "February", "March", "April", "May", "June"];
            const s2Months = ["July", "August", "September", "October", "November", "December"];

            const calcSemesterAvg = (months, examP) => {
                let mSum = 0;
                let mCount = 0;
                months.forEach(m => {
                    const res = getPeriodTotals(s.id, m);
                    if (res.total > 0) { // Only count months with data
                        mSum += res.average;
                        mCount++;
                    }
                });
                const mAvg = mCount > 0 ? mSum / mCount : 0;
                const eAvg = getPeriodTotals(s.id, examP).average;
                return (mAvg + eAvg) / 2;
            };

            const s1Avg = calcSemesterAvg(s1Months, 'Semester 1 Exam');
            const s2Avg = calcSemesterAvg(s2Months, 'Semester 2 Exam');

            finalAverage = (s1Avg + s2Avg) / 2;
            finalTotal = finalAverage;
            finalCoeff = 1;

            // Store S1 and S2 for display in columns
            subScores['s1_avg'] = s1Avg.toFixed(2);
            subScores['s2_avg'] = s2Avg.toFixed(2);
        } else if (isSemester) {
            // Store each month's average individually for column display
            let monthsSum = 0;
            selectedMonthNames.forEach(m => {
                const res = getPeriodTotals(s.id, m);
                subScores['month_' + m] = res.average.toFixed(2);
                monthsSum += res.average;
            });
            const monthsAvg = selectedMonthNames.length > 0 ? monthsSum / selectedMonthNames.length : 0;
            subScores['months_avg'] = monthsAvg.toFixed(2);

            // Exam Average
            const examPeriod = period === 'Semester 1' ? 'Semester 1 Exam' : 'Semester 2 Exam';
            const examRes = getPeriodTotals(s.id, examPeriod);
            const examAvg = examRes.average;
            subScores['exam_avg'] = examAvg.toFixed(2);

            // Result is (MonthsAvg + ExamAvg) / 2
            finalAverage = (monthsAvg + examAvg) / 2;
            finalTotal = finalAverage; // For display
            finalCoeff = 1;
        } else {
            // Normal Month or Exam
            const c = coeffValue || 10;
            const res = getPeriodTotals(s.id, period);
            finalTotal = res.total;
            finalAverage = res.total / c;
            finalCoeff = c;
            Object.assign(subScores, res.subScores);
        }

        return {
            id: s.stuId,
            dbId: s.id,
            name: `${s.stuKhmerLastName} ${s.stuKhmerFirstName}`,
            gender: s.gender,
            total: finalTotal.toFixed(2),
            average: finalAverage.toFixed(2),
            avgNum: finalAverage,
            subScores: subScores
        };
    });

    results.sort((a, b) => b.avgNum - a.avgNum);
    results.forEach((r, i) => r.rank = i + 1);

    renderResultsTableHTML(results, isAnnual, isSemester, selectedMonthNames, subjects, period, coeffValue);
    showAlert(`Calculated results for ${students.length} students.`);
}

function renderResultsTableHTML(results, isAnnual, isSemester, selectedMonthNames, subjects, period, coeffValue) {
    const container = document.getElementById('results-table-container');

    container.innerHTML = `
        <table class="data-table" style="width: 100%; border-collapse: collapse; min-width: 1200px;">
            <thead>
                <tr style="background: #f8f9fa; position: sticky; top: 0; z-index: 10; border-bottom: 2px solid var(--border);">
                    <th style="width: 50px; text-align: center; padding: 12px; background: #f8f9fa;">ល.រ</th>
                    <th style="width: 70px; text-align: center; padding: 12px; background: #f8f9fa;">ចំណាត់ថ្នាក់</th>
                    <th style="width: 100px; text-align: left; padding: 12px; background: #f8f9fa;">អត្តលេខ</th>
                    <th style="width: 200px; padding: 12px; text-align: left; background: #f8f9fa;">ឈ្មោះសិស្ស</th>
                    <th style="width: 70px; text-align: center; padding: 12px; background: #f8f9fa;">ភេទ</th>
                    ${isAnnual ? `
                        <th style="text-align: center; padding: 12px; background: #fff1f2; color: #be123c; min-width: 100px; font-weight: 700;">${getPeriodName('Semester 1')}</th>
                        <th style="text-align: center; padding: 12px; background: #fff1f2; color: #be123c; min-width: 100px; font-weight: 700;">${getPeriodName('Semester 2')}</th>
                    ` : ''}
                    ${isSemester ? `
                        ${selectedMonthNames.map(m => `
                            <th style="text-align: center; padding: 10px; font-size: 11px; min-width: 80px; background: #f0f9ff; color: #0369a1;">${getPeriodName(m)}</th>
                        `).join('')}
                        <th style="text-align: center; padding: 12px; background: #e0f2fe; color: #0369a1; min-width: 90px; font-weight: 700;">មធ្យមភាគខែ</th>
                        <th style="text-align: center; padding: 12px; background: #fef9c3; color: #854d0e; min-width: 90px; font-weight: 700;">${getPeriodName(period === 'Semester 1' ? 'Semester 1 Exam' : 'Semester 2 Exam')}</th>
                    ` : ''}
                    ${!isAnnual && !isSemester ? subjects.map(sub => `
                        <th style="text-align: center; padding: 12px; font-size: 11px; min-width: 90px; background: #f8f9fa;">${sub.subjectName}</th>
                    `).join('') : ''}
                    <th style="width: 90px; text-align: center; padding: 12px; background: #eef2ff;">សរុប</th>
                    <th style="width: 90px; text-align: center; padding: 12px; background: #e0f2fe;">មធ្យមភាគ</th>
                    <th style="width: 70px; text-align: center; padding: 12px; background: #e8f5e9;">និទ្ទេស</th>
                    <th style="width: 70px; text-align: center; padding: 12px; background: #fff8e1;">ចំណាត់ថ្នាក់</th>
                </tr>
            </thead>
            <tbody>
                ${results.map((r, index) => {
        const letterGrade = calculateGrade(r.average, 50);
        return `
                    <tr style="border-bottom: 1px solid var(--border);">
                        <td style="text-align: center; padding: 10px; color: var(--text-secondary); font-size: 13px;">${index + 1}</td>
                        <td style="text-align: center; padding: 10px;">
                            <div style="display: inline-block; width: 32px; height: 32px; line-height: 30px; background: ${r.rank <= 3 ? (r.rank === 1 ? '#ffd700' : (r.rank === 2 ? '#c0c0c0' : '#cd7f32')) : '#f1f5f9'}; border-radius: 50%; font-weight: 800; color: ${r.rank <= 3 ? 'white' : '#64748b'}; font-size: 14px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                                ${r.rank}
                            </div>
                        </td>
                        <td style="padding: 10px; font-family: 'Inter', sans-serif; font-size: 13px; color: var(--primary); font-weight: 700;">${r.id}</td>
                        <td style="font-weight: 600; color: var(--text-primary); padding: 10px;">${r.name}</td>
                        <td style="text-align: center; padding: 10px; color: var(--text-secondary);">${r.gender}</td>
                        ${isAnnual ? `
                            <td style="text-align: center; padding: 10px; font-weight: 800; color: #be123c; background: #fff1f2;">${r.subScores['s1_avg']}</td>
                            <td style="text-align: center; padding: 10px; font-weight: 800; color: #be123c; background: #fff1f2;">${r.subScores['s2_avg']}</td>
                        ` : ''}
                        ${isSemester ? `
                            ${selectedMonthNames.map(m => `
                                <td style="text-align: center; padding: 10px; font-size: 13px; background: #f0f9ff; color: #0369a1;">${r.subScores['month_' + m]}</td>
                            `).join('')}
                            <td style="text-align: center; padding: 10px; font-weight: 800; color: #0369a1; background: #e0f2fe;">${r.subScores['months_avg']}</td>
                            <td style="text-align: center; padding: 10px; font-weight: 800; color: #854d0e; background: #fef9c3;">${r.subScores['exam_avg']}</td>
                        ` : ''}
                        ${!isAnnual && !isSemester ? subjects.map(sub => `
                            <td style="text-align: center; padding: 10px; font-size: 13px;">${r.subScores[sub.id] !== undefined ? r.subScores[sub.id] : '-'}</td>
                        `).join('') : ''}
                        <td style="text-align: center; font-weight: 700; color: var(--primary); padding: 10px; background: #f5f8ff;">${r.total}</td>
                        <td style="text-align: center; padding: 10px; background: #f0f9ff;">
                            <span style="font-weight: 800; color: #0369a1;">${r.average}</span>
                        </td>
                        <td style="text-align: center; padding: 10px; background: #f1fcf1;">
                            ${renderGradeBadge(letterGrade)}
                        </td>
                        <td style="text-align: center; padding: 10px; background: #fffde7;">
                            <strong style="font-size: 15px; color: ${r.rank <= 3 ? '#f57f17' : '#666'};">${r.rank}</strong>
                        </td>
                    </tr>
                `;
    }).join('')}
            </tbody>
        </table>
    `;

    document.getElementById('export-results-btn').style.display = 'block';
    const grade = document.getElementById('score-grade').value;
    window.currentCalculatedResults = { grade, period, coeff: coeffValue, data: results, selectedMonthNames };
    localStorage.setItem(`calc_${grade}_${period}`, JSON.stringify({
        coeff: coeffValue,
        selectedMonthNames: selectedMonthNames
    }));
}

function exportResultsSummary() {
    const res = window.currentCalculatedResults;
    if (!res) return;

    const subjects = getSubjects();

    const exportData = res.data.map((r, i) => {
        const studentRow = {
            'ល.រ': i + 1,
            'អត្តលេខ': r.id,
            'ឈ្មោះសិស្ស': r.name,
            'ភេទ': r.gender
        };

        // Add specific columns based on the selected period
        if (['Semester 1', 'Semester 2'].includes(res.period)) {
            if (res.selectedMonthNames) {
                res.selectedMonthNames.forEach(m => {
                    studentRow[getPeriodName(m)] = r.subScores['month_' + m] || '';
                });
            }
            studentRow['Month Avg'] = r.subScores['months_avg'] || '';
            const examPeriodName = getPeriodName(res.period === 'Semester 1' ? 'Semester 1 Exam' : 'Semester 2 Exam');
            studentRow[examPeriodName] = r.subScores['exam_avg'] || '';
        } else if (res.period === 'Annual') {
            studentRow[getPeriodName('Semester 1')] = r.subScores['s1_avg'] || '';
            studentRow[getPeriodName('Semester 2')] = r.subScores['s2_avg'] || '';
        } else {
            // For normal months, add subject columns
            subjects.forEach(sub => {
                studentRow[sub.subjectName] = r.subScores[sub.id] !== undefined ? r.subScores[sub.id] : '';
            });
        }

        // Add final calculation columns
        studentRow['ពិន្ទុសរុប'] = r.total;
        studentRow['មធ្យមភាគ'] = r.average;
        studentRow['និទ្ទេស'] = calculateGrade(r.average, 50);
        studentRow['ចំណាត់ថ្នាក់'] = r.rank;

        return studentRow;
    });

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Monthly Results");
    XLSX.writeFile(wb, `Final_Results_Grade${res.grade}_${res.period}.xlsx`);
    showAlert('Downloading detailed results report...');
}
function showCoefficientSettings() {
    const settings = getSettings();
    const coeffs = settings.periodCoefficients || {};
    const periods = [
        "First Test", "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December",
        "Semester 1 Exam", "Semester 2 Exam"
    ];

    const html = `
        <div style="padding: 24px; max-width: 700px; margin: 0 auto;">
            <div style="background: var(--bg-card); border-radius: 32px; box-shadow: 0 10px 40px rgba(0,0,0,0.15); overflow: hidden; font-family: var(--font-family); border: 1px solid var(--border);">
                
                <!-- Header -->
                <div style="padding: 24px; display: flex; gap: 20px; align-items: flex-start;">
                    <div style="width: 80px; height: 80px; border-radius: 20px; background: #FFF7ED; border: 1px solid #FFEDD5; flex-shrink: 0; display: flex; align-items: center; justify-content: center; color: #F97316;">
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="3"></circle>
                            <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
                        </svg>
                    </div>

                    <div style="flex: 1;">
                        <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 8px;">
                            <span style="width: 8px; height: 8px; border-radius: 50%; background: #F97316; display: inline-block;"></span>
                            <span style="font-size: 12px; font-weight: 600; color: var(--text-secondary);">ការកំណត់មេគុណ</span>
                        </div>
                        
                        <h2 style="margin: 0; font-size: 20px; font-weight: 800; color: var(--text-primary); line-height: 1.2;">កំណត់មេគុណពិន្ទុ</h2>
                        <div style="font-size: 14px; color: var(--text-secondary); margin-top: 2px;">
                            កំណត់មេគុណសម្រាប់គ្រានីមួយៗនៃការវាយតម្លៃ
                        </div>
                    </div>
                </div>

                <!-- Form Section -->
                <div style="padding: 0 24px 24px;">
                    <form id="coeff-settings-form" style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px;">
                        ${periods.map(p => `
                            <div style="text-align: center; background: var(--bg-body); padding: 12px 8px; border-radius: 16px; border: 1px solid var(--border);">
                                <label style="font-weight: 700; font-size: 11px; margin-bottom: 6px; display: block; color: var(--text-secondary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${getPeriodName(p)}">
                                    ${getPeriodName(p)}
                                </label>
                                <input type="number" name="coeff-${p}" value="${coeffs[p] || 10}" step="0.1" min="1" 
                                       style="width: 100%; border: none; background: transparent; font-weight: 800; text-align: center; font-size: 16px; color: #4F46E5; outline: none;">
                            </div>
                        `).join('')}
                    </form>
                </div>

                <!-- Footer Actions -->
                <div style="padding: 16px 24px; background: var(--bg-body); border-top: 1px solid var(--border); display: flex; justify-content: flex-end; gap: 12px;">
                    <button onclick="closeModal()" style="border: none; background: #FEE2E2; color: #EF4444; padding: 10px 24px; border-radius: 12px; font-size: 13px; font-weight: 800; cursor: pointer; transition: all 0.2s;">បោះបង់</button>
                    <button onclick="saveCoefficientSettings()" style="border: none; background: #4F46E5; color: white; padding: 10px 32px; border-radius: 12px; font-size: 13px; font-weight: 800; cursor: pointer; box-shadow: 0 4px 12px rgba(79,70,229,0.2);">រក្សាទុក</button>
                </div>

            </div>
        </div>
    `;
    openModal(html, true);
}

function saveCoefficientSettings() {
    const form = document.getElementById('coeff-settings-form');
    if (!form) return;

    const settings = getSettings();
    const periods = [
        "First Test", "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December",
        "Semester 1 Exam", "Semester 2 Exam"
    ];

    periods.forEach(p => {
        const input = form.querySelector(`[name="coeff-${p}"]`);
        if (input) {
            settings.periodCoefficients[p] = parseFloat(input.value) || 10;
        }
    });

    saveSettings(settings);
    showAlert('All coefficients have been saved successfully!', 'success');
    closeModal();
}
