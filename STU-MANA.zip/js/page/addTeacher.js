// js/page/addTeacher.js

function renderAddTeacher() {
    const container = document.getElementById('content-area');

    const schools = getSchools();
    const schoolOptions = schools.map(s => `<option value="${s.schoolName}">${s.schoolName}</option>`).join('');

    container.innerHTML = `
        <div class="page-header">
            <div style="display: flex; align-items: center; gap: 16px;">
                <button class="btn-minimal" onclick="navigateTo('#/teachers')" title="Back to List">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="19" y1="12" x2="5" y2="12"></line>
                        <polyline points="12 19 5 12 12 5"></polyline>
                    </svg>
                </button>
                <div>
                    <h1 style="margin: 0;">បន្ថែមគ្រូបន្ទុកថ្នាក់ថ្មី</h1>
                    <p style="font-size: 14px; color: var(--text-secondary); margin: 4px 0 0;">បំពេញព័ត៌មានគ្រូខាងក្រោម</p>
                </div>
            </div>
            <div id="add-teacher-photo-preview" style="width: 60px; height: 60px; border-radius: 16px; background: var(--bg-card); display: flex; align-items: center; justify-content: center; font-size: 32px; overflow: hidden; border: 2px solid var(--primary); box-shadow: var(--shadow);">
                👨‍🏫
            </div>
        </div>

        <form id="add-teacher-form" onsubmit="handleAddTeacherSubmit(event)" style="padding-bottom: 40px;">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 24px;">
                
                <!-- Section 1: Personal Information -->
                <div class="form-section">
                    <div class="form-section-title">ព័ត៌មានផ្ទាល់ខ្លួន</div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="teacherId">អត្តលេខគ្រូ *</label>
                            <input type="text" id="teacherId" name="teacherId" required placeholder="ឧទាហរណ៍: T001">
                        </div>
                        <div class="form-group">
                            <label for="gender">ភេទ *</label>
                            <select id="gender" name="gender" required>
                                <option value="">ជ្រើសរើសភេទ</option>
                                <option value="Male">ប្រុស</option>
                                <option value="Female">ស្រី</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="tkhLastName">ត្រកូល (ខ្មែរ) *</label>
                            <input type="text" id="tkhLastName" name="tkhLastName" required>
                        </div>
                        <div class="form-group">
                            <label for="tkhFirstName">ឈ្មោះ (ខ្មែរ) *</label>
                            <input type="text" id="tkhFirstName" name="tkhFirstName" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="tengLastName">ត្រកូល (ឡាតាំង) *</label>
                            <input type="text" id="tengLastName" name="tengLastName" required>
                        </div>
                        <div class="form-group">
                            <label for="tengFirstName">ឈ្មោះ (ឡាតាំង) *</label>
                            <input type="text" id="tengFirstName" name="tengFirstName" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="dateOfBirth">ថ្ងៃខែឆ្នាំកំណើត (ថ្ងៃ/ខែ/ឆ្នាំ)</label>
                            <input type="text" id="dateOfBirth" name="dateOfBirth" placeholder="DD/MM/YYYY">
                        </div>
                        <div class="form-group">
                            <label>រូបថត</label>
                            <input type="file" id="photoFile" accept="image/jpeg, image/png" onchange="handleImageUpload(this, 'photoBase64', 'add-teacher-photo-preview')">
                            <input type="hidden" id="photoBase64" name="photo" value="">
                        </div>
                    </div>
                </div>

                <!-- Section 2: Work & Contact -->
                <div class="form-section">
                    <div class="form-section-title">ការងារ & ទំនាក់ទំនង</div>
                    <div class="form-group">
                        <label for="phoneNumber">លេខទូរស័ព្ទ</label>
                        <input type="tel" id="phoneNumber" name="phoneNumber" placeholder="012 345 678">
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="school">សាលារៀន *</label>
                            <select id="school" name="school" required>
                                <option value="">ជ្រើសរើសសាលារៀន</option>
                                ${schoolOptions}
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="classroom">ថ្នាក់រៀនដែលទទួលបន្ទុក</label>
                            <input type="text" id="classroom" name="classroom" placeholder="ឧទាហរណ៍: 10A">
                        </div>
                    </div>
                </div>

            </div>

            <div class="form-actions" style="margin-top: 32px; justify-content: flex-end; position: sticky; bottom: 0; background: var(--bg-body); padding: 16px 0; z-index: 10;">
                <button type="button" class="btn btn-secondary" onclick="navigateTo('#/teachers')">បោះបង់</button>
                <button type="submit" class="btn btn-primary" style="padding: 12px 40px;">រក្សាទុកគ្រូថ្មី</button>
            </div>
        </form>
    `;
}

function calculateAge(dateOfBirth) {
    if (!dateOfBirth) return '';
    
    let birthDate;
    const parts = String(dateOfBirth).split(/[-/]/);
    if (parts.length === 3) {
        // Expecting dd/mm/yyyy
        const d = parseInt(parts[0], 10);
        const m = parseInt(parts[1], 10) - 1;
        const y = parseInt(parts[2], 10);
        birthDate = new Date(y, m, d);
    } else {
        birthDate = new Date(dateOfBirth);
    }

    if (isNaN(birthDate.getTime())) return '';
    
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    return age;
}

function handleAddTeacherSubmit(event) {
    event.preventDefault();

    const form = event.target;
    const formData = new FormData(form);
    const dob = formData.get('dateOfBirth');

    let teacherId = formData.get('teacherId').trim();
    if (teacherId && !teacherId.startsWith('T')) {
        teacherId = 'T' + teacherId;
    }

    const teacher = {
        teacherId: teacherId,
        tkhLastName: formData.get('tkhLastName').trim(),
        tkhFirstName: formData.get('tkhFirstName').trim(),
        tengLastName: formData.get('tengLastName').trim(),
        tengFirstName: formData.get('tengFirstName').trim(),
        gender: formData.get('gender'),
        dateOfBirth: dob,
        age: calculateAge(dob),
        phoneNumber: formData.get('phoneNumber').trim(),
        classroom: formData.get('classroom').trim(),
        school: formData.get('school'),
        photo: formData.get('photo') || (formData.get('gender') === 'Female' ? '👩‍🏫' : '👨‍🏫')
    };

    addTeacher(teacher);
    showAlert('Teacher added successfully!');
    navigateTo('#/teachers');
}
