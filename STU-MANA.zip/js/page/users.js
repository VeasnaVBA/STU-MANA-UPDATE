// js/page/users.js
function renderUsersList() {
    const container = document.getElementById('content-area');
    
    const currentUser = getCurrentUser();
    if (!currentUser) {
        container.innerHTML = `<div class="empty-state"><h3>Access Denied</h3><p>Please log in.</p></div>`;
        return;
    }

    container.innerHTML = `
        <div class="page-header">
            <h1>User Roles Management</h1>
            ${currentUser.role === 'Super Admin' || currentUser.role === 'Admin' ? `
            <button class="btn btn-primary" onclick="handleAddUser()">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
                    <line x1="12" y1="5" x2="12" y2="19"></line>
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
                Create User
            </button>
            ` : ''}
        </div>

        <div class="search-box">
            <input type="text" id="user-search" placeholder="Search by name or username..." oninput="handleUserSearch(this.value)">
            <button class="btn btn-success" onclick="exportUsersToExcel()" style="display: flex; align-items: center; gap: 8px;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                    <polyline points="7 10 12 15 17 10"></polyline>
                    <line x1="12" y1="15" x2="12" y2="3"></line>
                </svg>
                Export Excel
            </button>
        </div>

        <div class="data-table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>UserID</th>
                        <th>Username</th>
                        <th>Full Name</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Description</th>
                        <th style="text-align: right;">Actions</th>
                    </tr>
                </thead>
                <tbody id="users-table-body">
                    <!-- Rendered by JS -->
                </tbody>
            </table>
        </div>
    `;

    refreshUsersTable();
}

function refreshUsersTable() {
    let users = getUsers();
    const currentUser = getCurrentUser();
    
    if (currentUser) {
        if (currentUser.role === 'Admin') {
            users = users.filter(u => u.id === currentUser.id || u.role === 'Teacher');
        } else if (currentUser.role !== 'Super Admin') {
            // Teachers and others only see themselves
            users = users.filter(u => u.id === currentUser.id);
        }
    }
    
    renderUserTableData(users);
}

function renderUserTableData(users) {
    const tbody = document.getElementById('users-table-body');
    if (!tbody) return;

    const currentUser = getCurrentUser();
    if (!currentUser) return;

    if (users.length === 0) {
        tbody.innerHTML = `<tr><td colspan="8" style="text-align: center; padding: 40px; color: var(--text-secondary);">No users found.</td></tr>`;
        return;
    }

    tbody.innerHTML = users.map((user, index) => {
        const isSuperAdmin = user.role === 'Super Admin';
        let canManage = false;
        
        if (currentUser.role === 'Super Admin') {
            canManage = true;
        } else if (currentUser.role === 'Admin') {
            canManage = !isSuperAdmin && (user.role === 'Teacher' || user.id === currentUser.id);
        } else {
            // Teachers can only edit themselves
            canManage = user.id === currentUser.id;
        }
        
        return `
        <tr>
            <td>${index + 1}</td>
            <td style="font-family: monospace; font-weight: 600;">${user.userId || user.id}</td>
            <td>${user.username}</td>
            <td>${user.name}</td>
            <td>
                <span class="grade-badge" style="background: ${user.role === 'Super Admin' ? '#EDE7F6' : (user.role === 'Admin' ? '#F3E5F5' : '#E3F2FD')}; color: ${user.role === 'Super Admin' ? '#5E35B1' : (user.role === 'Admin' ? '#7B1FA2' : '#1976D2')};">
                    ${user.role}
                </span>
            </td>
            <td>
                <span class="grade-badge" style="background: ${user.status === 'Active' ? '#E8F5E9' : '#FFEBEE'}; color: ${user.status === 'Active' ? '#2E7D32' : '#C62828'};">
                    ${user.status}
                </span>
            </td>
            <td style="max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${user.description || '-'}</td>
            <td style="text-align: right;">
                <div class="actions" style="display: flex; justify-content: flex-end; gap: 8px;">
                    ${canManage ? `
                    <button class="btn-sm btn-edit" onclick="handleEditUser('${user.id}')">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                        </svg>
                    </button>
                    ${user.username !== 'super' && user.id !== currentUser.id ? `
                    <button class="btn-sm btn-delete" onclick="handleDeleteUser('${user.id}')">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="3 6 5 6 21 6"></polyline>
                            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                        </svg>
                    </button>
                    ` : ''}
                    ` : '<span style="font-size: 11px; color: var(--text-secondary);">Protected</span>'}
                </div>
            </td>
        </tr>
    `}).join('');
}

function handleUserSearch(query) {
    const lower = query.toLowerCase();
    const currentUser = getCurrentUser();
    
    let filtered = getUsers().filter(u => 
        u.username.toLowerCase().includes(lower) || 
        u.name.toLowerCase().includes(lower) ||
        u.userId.toLowerCase().includes(lower)
    );

    if (currentUser) {
        if (currentUser.role === 'Admin') {
            filtered = filtered.filter(u => u.id === currentUser.id || u.role === 'Teacher');
        } else if (currentUser.role !== 'Super Admin') {
            filtered = filtered.filter(u => u.id === currentUser.id);
        }
    }

    renderUserTableData(filtered);
}

function getPermissionCheckboxes(selectedPermissions = []) {
    const allPermissions = [
        { id: 'dashboard', label: 'Dashboard' },
        { id: 'students', label: 'Students' },
        { id: 'scores', label: 'Scores' },
        { id: 'teachers', label: 'Teachers' },
        { id: 'schools', label: 'Schools' },
        { id: 'messages', label: 'Messages' },
        { id: 'users', label: 'Users' },
        { id: 'reports', label: 'Reports' },
        { id: 'settings', label: 'Settings' }
    ];

    return `
        <div style="margin-top: 12px;">
            <label style="font-size: 11px; font-weight: 700; text-transform: uppercase; color: var(--text-primary); margin-bottom: 6px; display: block;">Menu Permissions</label>
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; background: #f8f9fa; padding: 10px; border-radius: 8px; border: 1px solid var(--border);">
                ${allPermissions.map(p => `
                    <div style="display: flex; align-items: center; gap: 6px;">
                        <input type="checkbox" name="permissions" value="${p.id}" id="perm-${p.id}" ${selectedPermissions.includes(p.id) ? 'checked' : ''}>
                        <label for="perm-${p.id}" style="margin: 0; font-size: 12px; cursor: pointer; white-space: nowrap;">${p.label}</label>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

function handleAddUser() {
    const currentUser = getCurrentUser();
    if (!currentUser || (currentUser.role !== 'Super Admin' && currentUser.role !== 'Admin')) {
        showAlert('You do not have permission to create users.', 'error');
        return;
    }

    const teachers = getTeachers();
    const teacherOptions = teachers.map(t => `<option value="${t.tengFirstName} ${t.tengLastName}">${t.tengFirstName} ${t.tengLastName}</option>`).join('');

    const html = `
        <div style="padding: 16px;">
            <h2 style="margin-bottom: 16px; font-size: 18px; font-weight: 700;">Create New User</h2>
            <form id="add-user-form" onsubmit="saveNewUser(event)">
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px;">
                    <div class="form-group">
                        <label>User ID</label>
                        <input type="text" name="userId" required placeholder="U003">
                    </div>
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="username" required>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" required>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 2fr 1fr 1fr; gap: 12px; margin-top: 8px;">
                    <div class="form-group">
                        <label>Full Name (Link to Teacher)</label>
                        <select name="name" required>
                            <option value="">Select Teacher Name</option>
                            <option value="Super Admin">Super Admin</option>
                            <option value="Admin User">Admin User</option>
                            ${teacherOptions}
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Role</label>
                        <select name="role" required onchange="handleRoleChange(this)">
                            <option value="Teacher">Teacher</option>
                            <option value="Admin">Admin</option>
                            ${currentUser.role === 'Super Admin' ? '<option value="Super Admin">Super Admin</option>' : ''}
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status">
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                
                ${getPermissionCheckboxes(['dashboard', 'students', 'scores', 'reports'])}

                <div class="form-group" style="margin-top: 12px;">
                    <label>Description (Optional)</label>
                    <input type="text" name="description" placeholder="Short description..." style="padding: 6px 10px;">
                </div>

                <div class="form-actions" style="margin-top: 16px; padding-top: 12px; border-top: 1px solid var(--border); justify-content: flex-end;">
                    <button type="button" class="btn btn-secondary" style="padding: 8px 20px;" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary" style="padding: 8px 20px;">Save User</button>
                </div>
            </form>
        </div>
    `;
    openModal(html);
}

function handleRoleChange(select) {
    const form = select.closest('form');
    const checkboxes = form.querySelectorAll('input[name="permissions"]');
    if (select.value === 'Super Admin' || select.value === 'Admin') {
        checkboxes.forEach(cb => cb.checked = true);
    } else {
        checkboxes.forEach(cb => cb.checked = false);
        // Default for teacher
        form.querySelector('#perm-dashboard').checked = true;
        form.querySelector('#perm-students').checked = true;
        form.querySelector('#perm-scores').checked = true;
        form.querySelector('#perm-reports').checked = true;
    }
}

function saveNewUser(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    
    const permissions = [];
    form.querySelectorAll('input[name="permissions"]:checked').forEach(cb => {
        permissions.push(cb.value);
    });

    const user = {
        userId: formData.get('userId'),
        username: formData.get('username'),
        password: formData.get('password'),
        name: formData.get('name'),
        role: formData.get('role'),
        status: formData.get('status'),
        description: formData.get('description'),
        permissions: permissions
    };
    
    addUser(user);
    closeModal();
    showAlert('User created successfully');
    refreshUsersTable();
}

function handleEditUser(id) {
    const user = getUserById(id);
    const currentUser = getCurrentUser();
    if (!user || !currentUser) return;

    const teachers = getTeachers();
    const teacherOptions = teachers.map(t => 
        `<option value="${t.tengFirstName} ${t.tengLastName}" ${user.name === (t.tengFirstName + ' ' + t.tengLastName) ? 'selected' : ''}>${t.tengFirstName} ${t.tengLastName}</option>`
    ).join('');
    
    const isTeacher = currentUser.role === 'Teacher';
    const disableSensitive = user.username === 'super' || isTeacher;

    const html = `
        <div style="padding: 16px;">
            <h2 style="margin-bottom: 16px; font-size: 18px; font-weight: 700;">Edit User</h2>
            <form id="edit-user-form" onsubmit="saveEditUser(event, '${id}')">
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px;">
                    <div class="form-group">
                        <label>User ID</label>
                        <input type="text" name="userId" value="${user.userId}" required>
                    </div>
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="username" value="${user.username}" required ${(user.username === 'super' || isTeacher) ? 'readonly' : ''}>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" value="${user.password}" required>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 2fr 1fr 1fr; gap: 12px; margin-top: 8px;">
                    <div class="form-group">
                        <label>Full Name</label>
                        <select name="name" required>
                            <option value="Super Admin" ${user.name === 'Super Admin' ? 'selected' : ''}>Super Admin</option>
                            <option value="Admin User" ${user.name === 'Admin User' ? 'selected' : ''}>Admin User</option>
                            ${teacherOptions}
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Role</label>
                        <select name="role" required onchange="handleRoleChange(this)" ${disableSensitive ? 'disabled' : ''}>
                            <option value="Teacher" ${user.role === 'Teacher' ? 'selected' : ''}>Teacher</option>
                            <option value="Admin" ${user.role === 'Admin' ? 'selected' : ''}>Admin</option>
                            ${(currentUser.role === 'Super Admin' || user.role === 'Super Admin') ? `<option value="Super Admin" ${user.role === 'Super Admin' ? 'selected' : ''}>Super Admin</option>` : ''}
                        </select>
                        ${disableSensitive ? `<input type="hidden" name="role" value="${user.role}">` : ''}
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status" ${disableSensitive ? 'disabled' : ''}>
                            <option value="Active" ${user.status === 'Active' ? 'selected' : ''}>Active</option>
                            <option value="Inactive" ${user.status === 'Inactive' ? 'selected' : ''}>Inactive</option>
                        </select>
                        ${disableSensitive ? `<input type="hidden" name="status" value="${user.status}">` : ''}
                    </div>
                </div>

                ${isTeacher ? `<div style="display:none;">${getPermissionCheckboxes(user.permissions || [])}</div>` : getPermissionCheckboxes(user.permissions || [])}

                <div class="form-group" style="margin-top: 12px;">
                    <label>Description (Optional)</label>
                    <input type="text" name="description" value="${user.description || ''}" placeholder="Short description..." style="padding: 6px 10px;">
                </div>

                <div class="form-actions" style="margin-top: 16px; padding-top: 12px; border-top: 1px solid var(--border); justify-content: flex-end;">
                    <button type="button" class="btn btn-secondary" style="padding: 8px 20px;" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary" style="padding: 8px 20px;">Update User</button>
                </div>
            </form>
        </div>
    `;
    openModal(html);
}

function saveEditUser(event, id) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    
    const permissions = [];
    form.querySelectorAll('input[name="permissions"]:checked').forEach(cb => {
        permissions.push(cb.value);
    });

    const updatedData = {
        userId: formData.get('userId'),
        username: formData.get('username'),
        password: formData.get('password'),
        name: formData.get('name'),
        role: formData.get('role'),
        status: formData.get('status'),
        description: formData.get('description'),
        permissions: permissions
    };
    
    updateUser(id, updatedData);
    closeModal();
    showAlert('User updated successfully');
    refreshUsersTable();
}

function handleDeleteUser(id) {
    const userToDelete = getUserById(id);
    const currentUser = getCurrentUser();

    if (!userToDelete) return;

    // Prevent deleting the main 'super' account
    if (userToDelete.username === 'super') {
        showAlert('The primary Super Admin account cannot be deleted.', 'error');
        return;
    }

    // Prevent deleting yourself
    if (userToDelete.id === currentUser.id) {
        showAlert('You cannot delete your own account.', 'error');
        return;
    }

    if (confirm(`Are you sure you want to delete user "${userToDelete.username}"?`)) {
        deleteUser(id);
        showAlert('User deleted successfully');
        refreshUsersTable();
    }
}

function exportUsersToExcel() {
    let users = getUsers();
    const currentUser = getCurrentUser();
    if (currentUser) {
        if (currentUser.role === 'Admin') {
            users = users.filter(u => u.id === currentUser.id || u.role === 'Teacher');
        } else if (currentUser.role !== 'Super Admin') {
            users = users.filter(u => u.id === currentUser.id);
        }
    }

    if (!window.confirm(`Export ${users.length} user records to Excel?`)) return;

    const data = users.map((u, index) => ({
        'No': index + 1,
        'User ID': u.userId,
        'Username': u.username,
        'Password': u.password,
        'Full Name': u.name,
        'Role': u.role,
        'Status': u.status,
        'Description': u.description || ''
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Users");
    
    worksheet['!cols'] = [{wch: 25}, {wch: 15}, {wch: 15}, {wch: 15}, {wch: 20}, {wch: 15}, {wch: 12}, {wch: 30}];
    XLSX.writeFile(workbook, "User_Roles_List.xlsx");
}
