// js/page/showSchool.js

function renderShowSchool() {
    renderSchoolsList(); // Render background

    const params = getUrlParams();
    const schoolId = params.id;

    if (!schoolId) {
        openModal('<div style="padding:24px;text-align:center;">No school selected.</div>');
        return;
    }

    const school = getSchoolById(schoolId);
    if (!school) {
        openModal('<div style="padding:24px;text-align:center;">School not found.</div>');
        return;
    }

    const html = `
        <div style="padding: 20px; max-width: 650px; margin: 0 auto; display: flex; flex-direction: column; gap: 16px;">
            <div style="display: flex; align-items: center; gap: 16px; border-bottom: 1px solid var(--border); padding-bottom: 12px;">
                <div style="width: 56px; height: 56px; border-radius: 50%; background: var(--bg-body); display: flex; align-items: center; justify-content: center; font-size: 28px; overflow: hidden; flex-shrink: 0;">
                    🏫
                </div>
                <div style="flex: 1;">
                    <h2 style="margin: 0; font-size: 18px;">${school.schoolName || '-'}</h2>
                    <p style="margin: 2px 0 0; color: var(--text-secondary); font-size: 13px;">ID: #${school.schoolId || school.id}</p>
                </div>
            </div>

            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; font-size: 13px;">
                <!-- General Info -->
                <div style="grid-column: span 2; color: var(--primary); font-size: 11px; font-weight: bold; text-transform: uppercase; border-bottom: 1px solid var(--border); margin-top: 4px; padding-bottom: 2px;">School Information</div>
                
                <div style="display: flex; flex-direction: column;">
                    <span style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; font-weight: bold;">School Name</span>
                    <span>${school.schoolName || '-'}</span>
                </div>
                <div style="display: flex; flex-direction: column;">
                    <span style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; font-weight: bold;">School ID</span>
                    <span>${school.schoolId || school.id}</span>
                </div>
                
                <div style="display: flex; flex-direction: column;">
                    <span style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; font-weight: bold;">Director Name</span>
                    <span>${school.directorName || '-'}</span>
                </div>
                <div style="display: flex; flex-direction: column;">
                    <span style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; font-weight: bold;">Phone Number</span>
                    <span>${school.phoneNumber || '-'}</span>
                </div>

                <!-- Location Info -->
                <div style="grid-column: span 2; color: var(--primary); font-size: 11px; font-weight: bold; text-transform: uppercase; border-bottom: 1px solid var(--border); margin-top: 10px; padding-bottom: 2px;">Location</div>
                
                <div style="display: flex; flex-direction: column;">
                    <span style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; font-weight: bold;">Village</span>
                    <span>${school.village || '-'}</span>
                </div>
                <div style="display: flex; flex-direction: column;">
                    <span style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; font-weight: bold;">Commune</span>
                    <span>${school.commune || '-'}</span>
                </div>
                <div style="display: flex; flex-direction: column;">
                    <span style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; font-weight: bold;">District</span>
                    <span>${school.district || '-'}</span>
                </div>
                <div style="display: flex; flex-direction: column;">
                    <span style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; font-weight: bold;">Province</span>
                    <span>${school.province || '-'}</span>
                </div>

                <div style="grid-column: span 2; display: flex; flex-direction: column; margin-top: 10px;">
                    <span style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; font-weight: bold;">Description</span>
                    <span>${school.description || '-'}</span>
                </div>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 12px; margin-top: 12px; border-top: 1px solid var(--border); padding-top: 12px;">
                <button type="button" class="btn btn-secondary" onclick="navigateTo('#/schools')" style="padding: 6px 14px; font-size: 13px;">Close</button>
                <button type="button" class="btn btn-primary" onclick="navigateTo('#/edit-school?id=${schoolId}')" style="padding: 6px 14px; font-size: 13px;">Edit School</button>
            </div>
        </div>
    `;
    openModal(html);
}
