// js/page/subjects.js

function renderSubjectsList() {
    const container = document.getElementById('content-area');
    const currentUser = getCurrentUser();
    
    container.innerHTML = `
        <div class="page-header">
            <div class="header-title">
                <h1>Subjects Management</h1>
                <p>Add and manage school subjects for student scores</p>
            </div>
            ${(currentUser.role === 'Super Admin' || currentUser.role === 'Admin') ? `
                <button class="btn btn-primary" onclick="handleAddSubject()">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="12" y1="5" x2="12" y2="19"></line>
                        <line x1="5" y1="12" x2="19" y2="12"></line>
                    </svg>
                    Add New Subject
                </button>
            ` : ''}
        </div>

        <div class="data-table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th style="width: 60px; text-align: center;">No</th>
                        <th style="width: 140px;">Subject ID</th>
                        <th style="width: 220px;">Subject Name</th>
                        <th style="width: 350px;">Max Scores (Grade 7 - 12)</th>
                        <th>Description</th>
                        <th style="width: 100px; text-align: center;">Actions</th>
                    </tr>
                </thead>
                <tbody id="subjects-table-body">
                    <!-- Rendered by JS -->
                </tbody>
            </table>
        </div>
    `;

    refreshSubjectsTable();
}

function refreshSubjectsTable() {
    const tbody = document.getElementById('subjects-table-body');
    const subjects = getSubjects();
    const currentUser = getCurrentUser();

    if (subjects.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; padding: 40px; color: var(--text-secondary);">No subjects found in the system.</td></tr>`;
        return;
    }

    tbody.innerHTML = subjects.map((s, index) => `
        <tr>
            <td style="text-align: center;">${index + 1}</td>
            <td style="font-weight: 700; color: var(--primary); font-family: 'Inter', sans-serif;">${s.subjectId}</td>
            <td style="font-weight: 600; color: var(--text-primary);">${s.subjectName}</td>
            <td>
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; font-size: 11px;">
                    ${Object.entries(s.maxScores || {}).sort((a,b) => a[0]-b[0]).map(([g, v]) => `
                        <div style="background: #f8f9fa; padding: 2px 6px; border-radius: 4px; border: 1px solid #eee;">
                            <span style="color: #666;">G${g}:</span> <b style="color: var(--primary);">${v}</b>
                        </div>
                    `).join('')}
                </div>
            </td>
            <td style="color: var(--text-secondary); font-size: 13px;">${s.description || '-'}</td>
            <td style="text-align: center;">
                <div class="actions" style="display: flex; justify-content: center; gap: 8px;">
                    <button class="btn-edit" onclick="handleEditSubject('${s.id}')" title="Edit Subject" 
                            style="padding: 6px; border-radius: 6px; color: #004ad9; background: #eef2ff; border: none; cursor: pointer; transition: all 0.2s;">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                        </svg>
                    </button>
                    ${(currentUser.role === 'Super Admin' || currentUser.role === 'Admin') ? `
                        <button class="btn-delete" onclick="handleDeleteSubject('${s.id}')" title="Delete Subject"
                                style="padding: 6px; border-radius: 6px; color: #dc2626; background: #fef2f2; border: none; cursor: pointer; transition: all 0.2s;">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="3 6 5 6 21 6"></polyline>
                                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                <line x1="10" y1="11" x2="10" y2="17"></line>
                                <line x1="14" y1="11" x2="14" y2="17"></line>
                            </svg>
                        </button>
                    ` : ''}
                </div>
            </td>
        </tr>
    `).join('');
}

function handleAddSubject() {
    const html = `
        <div style="padding: 16px;">
            <h2 style="margin-bottom: 20px; font-size: 18px;">Add New Subject</h2>
            <form id="add-subject-form" onsubmit="saveNewSubject(event)" style="display: flex; flex-direction: column; gap: 16px;">
                <div class="form-group">
                    <label>Subject ID *</label>
                    <input type="text" name="subjectId" required placeholder="e.g. SUB001">
                </div>
                <div class="form-group">
                    <label>Subject Name *</label>
                    <input type="text" name="subjectName" required placeholder="e.g. Mathematics">
                </div>
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 8px; font-weight: 600;">Max Scores per Grade</label>
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px;">
                        ${[7, 8, 9, 10, 11, 12].map(g => `
                            <div>
                                <label style="font-size: 12px; color: var(--text-secondary);">Grade ${g}</label>
                                <input type="number" name="max_score_${g}" value="100" min="1" style="width: 100%; padding: 6px; border: 1px solid var(--border); border-radius: 4px;">
                            </div>
                        `).join('')}
                    </div>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" placeholder="Optional details..." style="width: 100%; min-height: 80px; padding: 8px; border: 1px solid var(--border); border-radius: 4px;"></textarea>
                </div>
                <div class="form-actions" style="justify-content: flex-end; margin-top: 8px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Subject</button>
                </div>
            </form>
        </div>
    `;
    openModal(html);
}

function saveNewSubject(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    
    let subjectId = formData.get('subjectId').trim();
    if (subjectId && !subjectId.toUpperCase().startsWith('SUB')) {
        subjectId = 'Sub' + subjectId;
    }
    
    const maxScores = {};
    [7, 8, 9, 10, 11, 12].forEach(g => {
        maxScores[g] = parseInt(formData.get(`max_score_${g}`)) || 100;
    });

    const subject = {
        subjectId: subjectId,
        subjectName: formData.get('subjectName').trim(),
        maxScores: maxScores,
        description: formData.get('description').trim()
    };
    
    addSubject(subject);
    closeModal();
    showAlert('Subject added successfully!');
    refreshSubjectsTable();
}

function handleEditSubject(id) {
    const subjects = getSubjects();
    const subject = subjects.find(s => s.id === id);
    if (!subject) return;

    const html = `
        <div style="padding: 16px;">
            <h2 style="margin-bottom: 20px; font-size: 18px;">Edit Subject</h2>
            <form id="edit-subject-form" onsubmit="saveEditSubject(event, '${id}')" style="display: flex; flex-direction: column; gap: 16px;">
                <div class="form-group">
                    <label>Subject ID *</label>
                    <input type="text" name="subjectId" value="${subject.subjectId}" required>
                </div>
                <div class="form-group">
                    <label>Subject Name *</label>
                    <input type="text" name="subjectName" value="${subject.subjectName}" required>
                </div>
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 8px; font-weight: 600;">Max Scores per Grade</label>
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px;">
                        ${[7, 8, 9, 10, 11, 12].map(g => `
                            <div>
                                <label style="font-size: 12px; color: var(--text-secondary);">Grade ${g}</label>
                                <input type="number" name="max_score_${g}" value="${(subject.maxScores && subject.maxScores[g]) || 100}" min="1" style="width: 100%; padding: 6px; border: 1px solid var(--border); border-radius: 4px;">
                            </div>
                        `).join('')}
                    </div>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" style="width: 100%; min-height: 80px; padding: 8px; border: 1px solid var(--border); border-radius: 4px;">${subject.description || ''}</textarea>
                </div>
                <div class="form-actions" style="justify-content: flex-end; margin-top: 8px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Subject</button>
                </div>
            </form>
        </div>
    `;
    openModal(html);
}

function saveEditSubject(event, id) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    
    let subjectId = formData.get('subjectId').trim();
    if (subjectId && !subjectId.toUpperCase().startsWith('SUB')) {
        subjectId = 'Sub' + subjectId;
    }
    
    const maxScores = {};
    [7, 8, 9, 10, 11, 12].forEach(g => {
        maxScores[g] = parseInt(formData.get(`max_score_${g}`)) || 100;
    });

    const updatedData = {
        subjectId: subjectId,
        subjectName: formData.get('subjectName').trim(),
        maxScores: maxScores,
        description: formData.get('description').trim()
    };
    
    updateSubject(id, updatedData);
    closeModal();
    showAlert('Subject updated successfully!');
    refreshSubjectsTable();
}

function handleDeleteSubject(id) {
    if (confirm('Are you sure you want to delete this subject?')) {
        if (deleteSubject(id)) {
            showAlert('Subject deleted successfully');
            refreshSubjectsTable();
        }
    }
}
