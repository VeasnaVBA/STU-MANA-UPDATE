// js/page/schools.js
function renderSchoolsList() {
    const container = document.getElementById('content-area');

    container.innerHTML = `
        <div class="page-header">
            <h1>All Schools</h1>
            <button class="btn btn-primary" onclick="navigateTo('#/add-school')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
                    <line x1="12" y1="5" x2="12" y2="19"></line>
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
                Add School
            </button>
        </div>

        <div class="search-box">
            <input type="text" id="school-search-input" placeholder="Search by name, ID, or province..." 
                   oninput="handleSchoolSearch(this.value)">
            <select id="school-sort-select" onchange="handleSchoolSort(this.value)" style="padding: 12px 16px; border: 2px solid var(--border); border-radius: var(--radius-sm); font-size: 14px;">
                <option value="schoolName-asc">Name: A-Z</option>
                <option value="schoolName-desc">Name: Z-A</option>
                <option value="schoolId-asc">ID: Low to High</option>
                <option value="schoolId-desc">ID: High to Low</option>
            </select>
            <button class="btn btn-success" onclick="exportSchoolsToExcel()" style="display: flex; align-items: center; gap: 8px;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                    <polyline points="7 10 12 15 17 10"></polyline>
                    <line x1="12" y1="15" x2="12" y2="3"></line>
                </svg>
                Export Excel
            </button>
        </div>

        <div class="data-table-container" style="overflow-x: auto;">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>SchoolID</th>
                        <th>SchoolName</th>
                        <th>Village</th>
                        <th>Commune</th>
                        <th>District</th>
                        <th>Province</th>
                        <th>Director Name</th>
                        <th>PhoneNumber</th>
                        <th>Description</th>
                        <th style="position: sticky; right: 0; background: #F8F9FA; border-left: 1px solid var(--border);">Actions</th>
                    </tr>
                </thead>
                <tbody id="schools-table-body">
                    <!-- Rendered by JS -->
                </tbody>
            </table>
        </div>
    `;

    refreshSchoolsTable();
}

function refreshSchoolsTable() {
    const tbody = document.getElementById('schools-table-body');
    if (!tbody) return;

    const schools = getSchools();
    renderSchoolTableData(schools);
}

function renderSchoolTableData(schools) {
    const tbody = document.getElementById('schools-table-body');
    if (!tbody) return;

    if (schools.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="11" style="text-align: center; padding: 40px;">
                    No schools found.
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = schools.map((school, index) => `
        <tr>
            <td>${index + 1}</td>
            <td style="font-family: monospace; font-weight: 600;">${school.schoolId || school.id}</td>
            <td style="font-weight: 500;">${school.schoolName || '-'}</td>
            <td>${school.village || '-'}</td>
            <td>${school.commune || '-'}</td>
            <td>${school.district || '-'}</td>
            <td>${school.province || '-'}</td>
            <td>${school.directorName || '-'}</td>
            <td>${school.phoneNumber || '-'}</td>
            <td style="max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${school.description || ''}">${school.description || '-'}</td>
            <td style="position: sticky; right: 0; background: var(--bg-card); border-left: 1px solid var(--border);">
                <div class="actions" style="display: flex; align-items: center; gap: 4px;">
                    <button class="btn-sm btn-show" onclick="navigateTo('#/show-school?id=${school.id}')" title="View Details">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                            <circle cx="12" cy="12" r="3"></circle>
                        </svg>
                    </button>
                    <button class="btn-sm btn-edit" onclick="navigateTo('#/edit-school?id=${school.id}')" title="Edit">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                        </svg>
                    </button>
                    <button class="btn-sm btn-delete" onclick="handleDeleteSchool('${school.id}')" title="Delete">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="3 6 5 6 21 6"></polyline>
                            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                        </svg>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');
}

function handleSchoolSearch(query) {
    if (!query) {
        renderSchoolTableData(getSchools());
        return;
    }
    const lower = query.toLowerCase();
    const filtered = getSchools().filter(s => 
        (s.schoolName && s.schoolName.toLowerCase().includes(lower)) ||
        (s.schoolId && s.schoolId.toLowerCase().includes(lower)) ||
        (s.province && s.province.toLowerCase().includes(lower)) ||
        (s.directorName && s.directorName.toLowerCase().includes(lower))
    );
    renderSchoolTableData(filtered);
}

function handleSchoolSort(value) {
    const [field, direction] = value.split('-');
    const sorted = [...getSchools()].sort((a, b) => {
        let valA = a[field] || '';
        let valB = b[field] || '';

        if (typeof valA === 'string') {
            valA = valA.toLowerCase();
            valB = valB.toLowerCase();
        }

        if (direction === 'asc') {
            return valA > valB ? 1 : -1;
        }
        return valA < valB ? 1 : -1;
    });
    renderSchoolTableData(sorted);
}

function handleDeleteSchool(id) {
    if (confirm('Are you sure you want to delete this school?')) {
        if (deleteSchool(id)) {
            if (typeof showAlert === 'function') showAlert('School deleted successfully');
            refreshSchoolsTable();
        }
    }
}

function exportSchoolsToExcel() {
    const schools = getSchools();
    if (schools.length === 0) {
        if (typeof showAlert === 'function') showAlert('No schools to export', 'error');
        return;
    }

    if (!window.confirm(`Are you sure you want to export ${schools.length} school records to Excel?`)) {
        return;
    }

    const data = schools.map((s, index) => ({
        'No': index + 1,
        'School ID': s.schoolId || s.id,
        'School Name': s.schoolName || '',
        'Director Name': s.directorName || '',
        'Phone': s.phoneNumber || '',
        'Village': s.village || '',
        'Commune': s.commune || '',
        'District': s.district || '',
        'Province': s.province || '',
        'Description': s.description || ''
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Schools");

    const wscols = [
        {wch: 25}, // No (A)
        {wch: 15}, // ID
        {wch: 25}, // Name
        {wch: 20}, // Director
        {wch: 18}, // Phone
        {wch: 15}, // Village
        {wch: 15}, // Commune
        {wch: 15}, // District
        {wch: 15}, // Province
        {wch: 40}  // Description
    ];
    worksheet['!cols'] = wscols;

    const wsrows = [
        {hpx: 30}, // Header
    ];
    for(let i = 0; i < data.length; i++) {
        wsrows.push({hpx: 25});
    }
    worksheet['!rows'] = wsrows;

    XLSX.writeFile(workbook, "Schools_List.xlsx");
}
