// js/page/editTeacher.js

function renderEditTeacher() {
    const container = document.getElementById('content-area');

    const params = getUrlParams();
    const teacherId = params.id;

    if (!teacherId) {
        navigateTo('#/teachers');
        return;
    }

    const teacher = getTeacherById(teacherId);

    if (!teacher) {
        container.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">🔍</div>
                <h3>Teacher Not Found</h3>
                <p>The teacher you're looking for doesn't exist.</p>
                <button class="btn btn-primary" onclick="navigateTo('#/teachers')">View All Teachers</button>
            </div>
        `;
        return;
    }

    const schools = getSchools();
    const schoolOptions = schools.map(s =>
        `<option value="${s.schoolName}" ${teacher.school === s.schoolName ? 'selected' : ''}>${s.schoolName}</option>`
    ).join('');

    container.innerHTML = `
        <div class="page-header">
            <div style="display: flex; align-items: center; gap: 16px;">
                <button class="btn-minimal" onclick="navigateTo('#/teachers')" title="Back to List">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="19" y1="12" x2="5" y2="12"></line>
                        <polyline points="12 19 5 12 12 5"></polyline>
                    </svg>
                </button>
                <div>
                    <h1 style="margin: 0;">កែប្រែព័ត៌មានគ្រូ</h1>
                    <p style="font-size: 14px; color: var(--text-secondary); margin: 4px 0 0;">${teacher.tkhLastName} ${teacher.tkhFirstName} (${teacher.tengFirstName} ${teacher.tengLastName})</p>
                </div>
            </div>
            <div id="edit-teacher-photo-preview" style="width: 60px; height: 60px; border-radius: 16px; background: var(--bg-card); display: flex; align-items: center; justify-content: center; font-size: 32px; overflow: hidden; border: 2px solid var(--primary); box-shadow: var(--shadow);">
                ${renderAvatar(teacher.photo, '👨‍🏫')}
            </div>
        </div>

        <form id="edit-teacher-form" onsubmit="handleEditTeacherSubmit(event, '${teacherId}')" style="padding-bottom: 40px;">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 24px;">
                
                <!-- Section 1: Personal Information -->
                <div class="form-section">
                    <div class="form-section-title">ព័ត៌មានផ្ទាល់ខ្លួន</div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="teacherId">អត្តលេខគ្រូ *</label>
                            <input type="text" id="teacherId" name="teacherId" value="${teacher.teacherId || teacher.id || ''}" required placeholder="ឧទាហរណ៍: T001">
                        </div>
                        <div class="form-group">
                            <label for="gender">ភេទ *</label>
                            <select id="gender" name="gender" required>
                                <option value="">ជ្រើសរើសភេទ</option>
                                <option value="Male" ${['Male', 'male', 'ប្រុស', 'ប', 'M', 'm'].includes(teacher.gender) ? 'selected' : ''}>ប្រុស</option>
                                <option value="Female" ${['Female', 'female', 'ស្រី', 'ស', 'F', 'f'].includes(teacher.gender) ? 'selected' : ''}>ស្រី</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="tkhLastName">ត្រកូល (ខ្មែរ) *</label>
                            <input type="text" id="tkhLastName" name="tkhLastName" value="${teacher.tkhLastName || ''}" required>
                        </div>
                        <div class="form-group">
                            <label for="tkhFirstName">ឈ្មោះ (ខ្មែរ) *</label>
                            <input type="text" id="tkhFirstName" name="tkhFirstName" value="${teacher.tkhFirstName || ''}" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="tengLastName">ត្រកូល (ឡាតាំង) *</label>
                            <input type="text" id="tengLastName" name="tengLastName" value="${teacher.tengLastName || ''}" required>
                        </div>
                        <div class="form-group">
                            <label for="tengFirstName">ឈ្មោះ (ឡាតាំង) *</label>
                            <input type="text" id="tengFirstName" name="tengFirstName" value="${teacher.tengFirstName || ''}" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="dateOfBirth">ថ្ងៃខែឆ្នាំកំណើត (ថ្ងៃ/ខែ/ឆ្នាំ)</label>
                            <input type="text" id="dateOfBirth" name="dateOfBirth" value="${teacher.dateOfBirth || ''}" placeholder="DD/MM/YYYY">
                        </div>
                        <div class="form-group">
                            <label>រូបថត</label>
                            <input type="file" id="photoFile" accept="image/jpeg, image/png" onchange="handleImageUpload(this, 'photoBase64', 'edit-teacher-photo-preview')">
                            <input type="hidden" id="photoBase64" name="photo" value="${teacher.photo || ''}">
                        </div>
                    </div>
                </div>

                <!-- Section 2: Work & Contact -->
                <div class="form-section">
                    <div class="form-section-title">ការងារ & ទំនាក់ទំនង</div>
                    <div class="form-group">
                        <label for="phoneNumber">លេខទូរស័ព្ទ</label>
                        <input type="tel" id="phoneNumber" name="phoneNumber" value="${teacher.phoneNumber || ''}" placeholder="012 345 678">
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="school">សាលារៀន *</label>
                            <select id="school" name="school" required>
                                <option value="">ជ្រើសរើសសាលារៀន</option>
                                ${schoolOptions}
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="classroom">ថ្នាក់រៀនដែលទទួលបន្ទុក</label>
                            <input type="text" id="classroom" name="classroom" value="${teacher.classroom || ''}" placeholder="ឧទាហរណ៍: 10A">
                        </div>
                    </div>
                </div>

            </div>

            <div class="form-actions" style="margin-top: 32px; justify-content: flex-end; position: sticky; bottom: 0; background: var(--bg-body); padding: 16px 0; z-index: 10;">
                <button type="button" class="btn btn-delete" style="margin-right: auto; background: #FFEBEE; color: #C62828; padding: 10px 20px; border-radius: 12px; font-weight: 600;" onclick="handleDeleteTeacherAndRedirect('${teacherId}')">លុបគ្រូ</button>
                <button type="button" class="btn btn-secondary" onclick="navigateTo('#/teachers')">បោះបង់</button>
                <button type="submit" class="btn btn-primary" style="padding: 12px 40px;">រក្សាទុកការកែប្រែ</button>
            </div>
        </form>
    `;
}

function calculateAge(dateOfBirth) {
    if (!dateOfBirth) return '';
    
    let birthDate;
    const parts = String(dateOfBirth).split(/[-/]/);
    if (parts.length === 3) {
        // Expecting dd/mm/yyyy
        const d = parseInt(parts[0], 10);
        const m = parseInt(parts[1], 10) - 1;
        const y = parseInt(parts[2], 10);
        birthDate = new Date(y, m, d);
    } else {
        birthDate = new Date(dateOfBirth);
    }

    if (isNaN(birthDate.getTime())) return '';
    
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    return age;
}

function handleEditTeacherSubmit(event, uniqueId) {
    event.preventDefault();

    const form = event.target;
    const formData = new FormData(form);
    const dob = formData.get('dateOfBirth');

    let displayId = formData.get('teacherId').trim();
    if (displayId && !displayId.startsWith('T')) {
        displayId = 'T' + displayId;
    }

    const updatedData = {
        teacherId: displayId,
        tkhLastName: formData.get('tkhLastName').trim(),
        tkhFirstName: formData.get('tkhFirstName').trim(),
        tengLastName: formData.get('tengLastName').trim(),
        tengFirstName: formData.get('tengFirstName').trim(),
        gender: formData.get('gender'),
        dateOfBirth: dob,
        age: calculateAge(dob),
        phoneNumber: formData.get('phoneNumber').trim(),
        classroom: formData.get('classroom').trim(),
        school: formData.get('school'),
        photo: formData.get('photo') || (formData.get('gender') === 'Female' ? '👩‍🏫' : '👨‍🏫')
    };

    updateTeacher(uniqueId, updatedData);
    showAlert('Teacher updated successfully!');
    navigateTo('#/teachers');
}

function handleDeleteTeacherAndRedirect(id) {
    if (confirm('Are you sure you want to delete this teacher? This cannot be undone.')) {
        if (deleteTeacher(id)) {
            showAlert('Teacher deleted successfully');
            navigateTo('#/teachers');
        }
    }
}
