// js/page/editStudent.js

function renderEditStudent() {
    const container = document.getElementById('content-area');

    const params = getUrlParams();
    const studentId = params.id;

    if (!studentId) {
        navigateTo('#/students');
        return;
    }

    const student = getStudentById(studentId);

    if (!student) {
        container.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">🔍</div>
                <h3>Student Not Found</h3>
                <p>The student you're looking for doesn't exist.</p>
                <button class="btn btn-primary" onclick="navigateTo('#/students')">View All Students</button>
            </div>
        `;
        return;
    }

    const currentUser = getCurrentUser();
    const isTeacher = currentUser && currentUser.role === 'Teacher';
    const teachers = getTeachers();

    let filteredTeachers = teachers.filter(t => t.school === student.school);
    if (isTeacher) {
        filteredTeachers = filteredTeachers.filter(t => (t.tengFirstName + ' ' + t.tengLastName) === currentUser.name);
    }

    const teacherOptions = filteredTeachers.map(t =>
        `<option value="${t.id}" data-classroom="${t.classroom}" ${student.teacher === t.id ? 'selected' : ''}>${t.tengFirstName} ${t.tengLastName}</option>`
    ).join('');

    const schools = getSchools();
    const schoolOptions = schools.map(s =>
        `<option value="${s.schoolName}" ${student.school === s.schoolName ? 'selected' : ''}>${s.schoolName}</option>`
    ).join('');

    container.innerHTML = `
        <div class="page-header">
            <div style="display: flex; align-items: center; gap: 16px;">
                <button class="btn-minimal" onclick="navigateTo('#/students')" title="Back to List">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="19" y1="12" x2="5" y2="12"></line>
                        <polyline points="12 19 5 12 12 5"></polyline>
                    </svg>
                </button>
                <div>
                    <h1 style="margin: 0; font-size: 28px; font-weight: 800; color: var(--primary);">កែប្រែព័ត៌មានសិស្ស</h1>
                    <p style="font-size: 18px; font-weight: 600; color: var(--text-primary); margin: 6px 0 0;">${student.stuKhmerLastName || ''} ${student.stuKhmerFirstName || student.stuEngFirstName || ''}</p>
                </div>
            </div>
            <div id="edit-student-photo-preview" style="width: 120px; height: 160px; border-radius: 12px; background: var(--bg-card); display: flex; align-items: center; justify-content: center; font-size: 48px; overflow: hidden; border: 3px solid var(--primary); box-shadow: var(--shadow-lg);">
                ${renderAvatar(student.photo, '👨‍🎓')}
            </div>
        </div>

        <form id="edit-student-form" onsubmit="handleEditSubmit(event, '${studentId}')" style="padding-bottom: 40px;">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 24px;">
                
                <!-- Section 1: Personal Information -->
                <div class="form-section">
                    <div class="form-section-title">ព័ត៌មានផ្ទាល់ខ្លួន</div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="stuId">អត្តលេខសិស្ស (មិនអាចប្តូរបាន)</label>
                            <input type="text" id="stuId" name="stuId" value="${student.stuId || student.id || ''}" readonly style="background: var(--bg-body); cursor: not-allowed; font-weight: 600;">
                        </div>
                        <div class="form-group">
                            <label for="gender">ភេទ *</label>
                            <select id="gender" name="gender" required>
                                <option value="">ជ្រើសរើសភេទ</option>
                                <option value="Male" ${['Male', 'male', 'ប្រុស', 'ប', 'M', 'm'].includes(student.gender) ? 'selected' : ''}>ប្រុស</option>
                                <option value="Female" ${['Female', 'female', 'ស្រី', 'ស', 'F', 'f'].includes(student.gender) ? 'selected' : ''}>ស្រី</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="stuKhmerLastName">ត្រកូល (ខ្មែរ)</label>
                            <input type="text" id="stuKhmerLastName" name="stuKhmerLastName" value="${student.stuKhmerLastName || ''}">
                        </div>
                        <div class="form-group">
                            <label for="stuKhmerFirstName">ឈ្មោះ (ខ្មែរ)</label>
                            <input type="text" id="stuKhmerFirstName" name="stuKhmerFirstName" value="${student.stuKhmerFirstName || ''}">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="stuEngLastName">ត្រកូល (ឡាតាំង) *</label>
                            <input type="text" id="stuEngLastName" name="stuEngLastName" value="${student.stuEngLastName || ''}" required>
                        </div>
                        <div class="form-group">
                            <label for="stuEngFirstName">ឈ្មោះ (ឡាតាំង) *</label>
                            <input type="text" id="stuEngFirstName" name="stuEngFirstName" value="${student.stuEngFirstName || ''}" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="dateOfBirth">ថ្ងៃខែឆ្នាំកំណើត (ថ្ងៃ/ខែ/ឆ្នាំ)</label>
                            <input type="text" id="dateOfBirth" name="dateOfBirth" value="${student.dateOfBirth || ''}" placeholder="DD/MM/YYYY">
                        </div>
                        <div class="form-group">
                            <label>រូបថត</label>
                            <input type="file" id="photoFile" accept="image/jpeg, image/png" onchange="handleImageUpload(this, 'photoBase64', 'edit-student-photo-preview')">
                            <input type="hidden" id="photoBase64" name="photo" value="${student.photo || ''}">
                        </div>
                    </div>
                </div>

                <!-- Section 2: Academic Details -->
                <div class="form-section">
                    <div class="form-section-title">ការសិក្សា</div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="school">សាលារៀន</label>
                            <select id="school" name="school" onchange="handleSchoolSelect(this)" ${isTeacher ? 'style="pointer-events: none; background: var(--bg-card);"' : ''}>
                                ${isTeacher ? '' : '<option value="">ជ្រើសរើសសាលារៀន</option>'}
                                ${schoolOptions}
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="teacher">គ្រូបន្ទុកថ្នាក់ *</label>
                            <select id="teacher" name="teacher" required onchange="handleTeacherSelect(this)" ${isTeacher ? 'style="pointer-events: none; background: var(--bg-card);"' : ''}>
                                ${teacherOptions}
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="classroom">ថ្នាក់រៀន</label>
                            <input type="text" id="classroom" name="classroom" value="${student.classroom || ''}" readonly style="background: var(--bg-card); cursor: not-allowed;">
                        </div>
                        <div class="form-group">
                            <label for="status">ស្ថានភាព</label>
                            <select id="status" name="status">
                                <option value="Active" ${student.status === 'Active' ? 'selected' : ''}>កំពុងរៀន</option>
                                <option value="Inactive" ${student.status === 'Inactive' ? 'selected' : ''}>ឈប់រៀន</option>
                                <option value="Graduated" ${student.status === 'Graduated' ? 'selected' : ''}>បញ្ចប់ការសិក្សា</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="stuPhoneNumber">លេខទូរស័ព្ទសិស្ស</label>
                        <input type="tel" id="stuPhoneNumber" name="stuPhoneNumber" value="${student.stuPhoneNumber || ''}">
                    </div>
                    <div class="form-group">
                        <label for="description">ការពិពណ៌នាបន្ថែម</label>
                        <textarea id="description" name="description" rows="2" style="resize: none;">${student.description || ''}</textarea>
                    </div>
                </div>

                <!-- Section 3: Address Information -->
                <div class="form-section" style="grid-column: 1 / -1;">
                    <div class="form-section-title">ព័ត៌មានអាសយដ្ឋាន</div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 40px;">
                        <div>
                            <div style="font-size: 12px; font-weight: 700; color: var(--primary); margin-bottom: 12px; text-transform: uppercase;">ទីកន្លែងកំណើត</div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="birthVillage">ភូមិ</label>
                                    <input type="text" id="birthVillage" name="birthVillage" value="${student.birthVillage || ''}">
                                </div>
                                <div class="form-group">
                                    <label for="birthCommune">ឃុំ/សង្កាត់</label>
                                    <input type="text" id="birthCommune" name="birthCommune" value="${student.birthCommune || ''}">
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="birthDistrict">ស្រុក/ខណ្ឌ</label>
                                    <input type="text" id="birthDistrict" name="birthDistrict" value="${student.birthDistrict || ''}">
                                </div>
                                <div class="form-group">
                                    <label for="birthProvince">ខេត្ត/ក្រុង</label>
                                    <input type="text" id="birthProvince" name="birthProvince" value="${student.birthProvince || ''}">
                                </div>
                            </div>
                        </div>
                        <div>
                            <div style="font-size: 12px; font-weight: 700; color: var(--primary); margin-bottom: 12px; text-transform: uppercase;">អាសយដ្ឋានបច្ចុប្បន្ន</div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="currentVillage">ភូមិ</label>
                                    <input type="text" id="currentVillage" name="currentVillage" value="${student.currentVillage || ''}">
                                </div>
                                <div class="form-group">
                                    <label for="currentCommmune">ឃុំ/សង្កាត់</label>
                                    <input type="text" id="currentCommmune" name="currentCommmune" value="${student.currentCommmune || ''}">
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="currentDistrict">ស្រុក/ខណ្ឌ</label>
                                    <input type="text" id="currentDistrict" name="currentDistrict" value="${student.currentDistrict || ''}">
                                </div>
                                <div class="form-group">
                                    <label for="currentProvince">ខេត្ត/ក្រុង</label>
                                    <input type="text" id="currentProvince" name="currentProvince" value="${student.currentProvince || ''}">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Section 4: Family Information -->
                <div class="form-section" style="grid-column: 1 / -1;">
                    <div class="form-section-title">ព័ត៌មានគ្រួសារ</div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 40px;">
                        <div style="display: flex; flex-direction: column; gap: 8px;">
                            <div style="font-size: 12px; font-weight: 700; color: var(--primary); text-transform: uppercase; margin-bottom: 4px;">ព័ត៌មានឪពុក</div>
                            <div class="form-row" style="grid-template-columns: 1fr 1fr 1fr;">
                                <div class="form-group">
                                    <label for="fatherName">ឈ្មោះ</label>
                                    <input type="text" id="fatherName" name="fatherName" value="${student.fatherName || ''}">
                                </div>
                                <div class="form-group">
                                    <label for="fatherJob">មុខរបរ</label>
                                    <input type="text" id="fatherJob" name="fatherJob" value="${student.fatherJob || ''}">
                                </div>
                                <div class="form-group">
                                    <label for="fatherPhone">ទូរស័ព្ទ</label>
                                    <input type="tel" id="fatherPhone" name="fatherPhone" value="${student.fatherPhone || ''}">
                                </div>
                            </div>
                        </div>
                        <div style="display: flex; flex-direction: column; gap: 8px;">
                            <div style="font-size: 12px; font-weight: 700; color: var(--primary); text-transform: uppercase; margin-bottom: 4px;">ព័ត៌មានម្តាយ</div>
                            <div class="form-row" style="grid-template-columns: 1fr 1fr 1fr;">
                                <div class="form-group">
                                    <label for="motherName">ឈ្មោះ</label>
                                    <input type="text" id="motherName" name="motherName" value="${student.motherName || ''}">
                                </div>
                                <div class="form-group">
                                    <label for="motherJob">មុខរបរ</label>
                                    <input type="text" id="motherJob" name="motherJob" value="${student.motherJob || ''}">
                                </div>
                                <div class="form-group">
                                    <label for="motherPhone">ទូរស័ព្ទ</label>
                                    <input type="tel" id="motherPhone" name="motherPhone" value="${student.motherPhone || ''}">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="form-actions" style="margin-top: 32px; justify-content: flex-end; position: sticky; bottom: 0; background: var(--bg-body); padding: 16px 0; z-index: 10;">
                <button type="button" class="btn btn-delete" style="margin-right: auto; background: #FFEBEE; color: #C62828; padding: 10px 20px; border-radius: 12px; font-weight: 600;" onclick="handleDeleteStudentAndRedirect('${studentId}')">លុបសិស្ស</button>
                <button type="button" class="btn btn-secondary" onclick="navigateTo('#/students')">បោះបង់</button>
                <button type="submit" class="btn btn-primary" style="padding: 12px 40px;">រក្សាទុកការកែប្រែ</button>
            </div>
        </form>
    `;
}

function handleEditSubmit(event, studentId) {
    event.preventDefault();

    const form = event.target;
    const formData = new FormData(form);

    let stuId = formData.get('stuId').trim();
    if (stuId && !stuId.startsWith('Stu')) {
        stuId = 'Stu' + stuId;
    }

    const school = formData.get('school').trim();

    const students = getStudents();
    const isDuplicate = students.some(s => s.stuId === stuId && s.school === school && s.id !== studentId);
    if (isDuplicate) {
        showAlert(`Error: Student ID "${stuId}" already exists in the selected school.`, 'error');
        return;
    }

    const oldStudent = getStudentById(studentId);
    let newStatus = formData.get('status');
    let description = formData.get('description').trim();
    let inactiveDate = oldStudent ? oldStudent.inactiveDate : null;

    if (newStatus === 'Inactive' && (!oldStudent || oldStudent.status !== 'Inactive')) {
        const now = new Date();
        const todayStr = now.toLocaleDateString('en-GB');
        inactiveDate = now.toISOString().split('T')[0];

        const name = `${formData.get('stuKhmerLastName')} ${formData.get('stuKhmerFirstName')}`;
        const logMsg = `That student ${name} is Inactive on ${todayStr}`;

        if (description) {
            description += ` | ${logMsg}`;
        } else {
            description = logMsg;
        }
    } else if (newStatus === 'Active') {
        inactiveDate = null;
    }

    const updatedData = {
        stuId: stuId,
        stuKhmerLastName: formData.get('stuKhmerLastName').trim(),
        stuKhmerFirstName: formData.get('stuKhmerFirstName').trim(),
        stuEngLastName: formData.get('stuEngLastName').trim(),
        stuEngFirstName: formData.get('stuEngFirstName').trim(),
        gender: formData.get('gender'),
        dateOfBirth: formData.get('dateOfBirth'),
        birthVillage: formData.get('birthVillage').trim(),
        birthCommune: formData.get('birthCommune').trim(),
        birthDistrict: formData.get('birthDistrict').trim(),
        birthProvince: formData.get('birthProvince').trim(),
        currentVillage: formData.get('currentVillage').trim(),
        currentCommmune: formData.get('currentCommmune').trim(),
        currentDistrict: formData.get('currentDistrict').trim(),
        currentProvince: formData.get('currentProvince').trim(),
        stuPhoneNumber: formData.get('stuPhoneNumber').trim(),
        fatherName: formData.get('fatherName').trim(),
        fatherJob: formData.get('fatherJob').trim(),
        fatherPhone: formData.get('fatherPhone').trim(),
        motherName: formData.get('motherName').trim(),
        motherJob: formData.get('motherJob').trim(),
        motherPhone: formData.get('motherPhone').trim(),
        school: formData.get('school').trim(),
        teacher: formData.get('teacher'),
        classroom: document.getElementById('classroom').value,
        status: newStatus,
        inactiveDate: inactiveDate,
        description: description,
        photo: formData.get('photo') || (formData.get('gender') === 'Female' ? '👩‍🎓' : '👨‍🎓')
    };

    updateStudent(studentId, updatedData);
    showAlert('Student updated successfully!');
    navigateTo('#/students');
}

function handleDeleteStudentAndRedirect(id) {
    if (confirm('Are you sure you want to delete this student? This cannot be undone.')) {
        if (deleteStudent(id)) {
            showAlert('Student deleted successfully');
            navigateTo('#/students');
        }
    }
}

function handleTeacherSelect(selectElement) {
    const selectedOption = selectElement.options[selectElement.selectedIndex];
    const classroom = selectedOption.getAttribute('data-classroom');
    document.getElementById('classroom').value = classroom || '';
}

function handleSchoolSelect(selectElement) {
    const schoolName = selectElement.value;
    const teacherSelect = document.getElementById('teacher');
    const classroomInput = document.getElementById('classroom');

    teacherSelect.innerHTML = '<option value="">Select Teacher</option>';
    classroomInput.value = '';

    if (!schoolName) {
        teacherSelect.innerHTML = '<option value="">Select School First</option>';
        return;
    }

    const teachers = getTeachers();
    let filteredTeachers = teachers.filter(t => t.school === schoolName);

    const currentUser = getCurrentUser();
    if (currentUser && currentUser.role === 'Teacher') {
        filteredTeachers = filteredTeachers.filter(t => (t.tengFirstName + ' ' + t.tengLastName) === currentUser.name);
    }

    if (filteredTeachers.length === 0) {
        teacherSelect.innerHTML = '<option value="">មិនមានគ្រូក្នុងសាលានេះទេ</option>';
    } else {
        teacherSelect.innerHTML += filteredTeachers.map(t =>
            `<option value="${t.id}" data-classroom="${t.classroom}">${t.tengFirstName} Sokha</option>`
        ).join('');

        if (filteredTeachers.length === 1) {
            teacherSelect.value = filteredTeachers[0].id;
            handleTeacherSelect(teacherSelect);
        }
    }
}
