// js/page/editSchool.js
function renderEditSchool() {
    const container = document.getElementById('content-area');

    const params = getUrlParams();
    const id = params.id;

    if (!id) {
        navigateTo('#/schools');
        return;
    }

    const school = getSchoolById(id);

    if (!school) {
        container.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">🔍</div>
                <h3>School Not Found</h3>
                <p>The school you're looking for doesn't exist.</p>
                <button class="btn btn-primary" onclick="navigateTo('#/schools')">View All Schools</button>
            </div>
        `;
        return;
    }

    container.innerHTML = `
        <div class="page-header">
            <div style="display: flex; align-items: center; gap: 16px;">
                <button class="btn-minimal" onclick="navigateTo('#/schools')" title="Back to List">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="19" y1="12" x2="5" y2="12"></line>
                        <polyline points="12 19 5 12 12 5"></polyline>
                    </svg>
                </button>
                <div>
                    <h1 style="margin: 0;">កែប្រែព័ត៌មានសាលារៀន</h1>
                    <p style="font-size: 14px; color: var(--text-secondary); margin: 4px 0 0;">${school.schoolName}</p>
                </div>
            </div>
        </div>

        <form id="edit-school-form" onsubmit="handleEditSchoolSubmit(event, '${id}')" style="padding-bottom: 40px;">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 24px;">
                
                <!-- Section 1: General Info -->
                <div class="form-section">
                    <div class="form-section-title">ព័ត៌មានទូទៅ</div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="schoolId">អត្តលេខសាលា *</label>
                            <input type="text" id="schoolId" name="schoolId" value="${school.schoolId || ''}" required placeholder="ឧទាហរណ៍: Sch001">
                        </div>
                        <div class="form-group">
                            <label for="phoneNumber">លេខទូរស័ព្ទ</label>
                            <input type="tel" id="phoneNumber" name="phoneNumber" value="${school.phoneNumber || ''}" placeholder="012 345 678">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="schoolName">ឈ្មោះសាលារៀន *</label>
                        <input type="text" id="schoolName" name="schoolName" value="${school.schoolName || ''}" required>
                    </div>
                    <div class="form-group">
                        <label for="directorName">ឈ្មោះនាយកសាលា</label>
                        <input type="text" id="directorName" name="directorName" value="${school.directorName || ''}">
                    </div>
                </div>

                <!-- Section 2: Location & Description -->
                <div class="form-section">
                    <div class="form-section-title">ទីតាំង & ការពិពណ៌នា</div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="village">ភូមិ</label>
                            <input type="text" id="village" name="village" value="${school.village || ''}">
                        </div>
                        <div class="form-group">
                            <label for="commune">ឃុំ/សង្កាត់</label>
                            <input type="text" id="commune" name="commune" value="${school.commune || ''}">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="district">ស្រុក/ខណ្ឌ</label>
                            <input type="text" id="district" name="district" value="${school.district || ''}">
                        </div>
                        <div class="form-group">
                            <label for="province">ខេត្ត/ក្រុង</label>
                            <input type="text" id="province" name="province" value="${school.province || ''}">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="description">ការពិពណ៌នាបន្ថែម</label>
                        <textarea id="description" name="description" rows="3" style="resize: none;">${school.description || ''}</textarea>
                    </div>
                </div>
            </div>

            <div class="form-actions" style="margin-top: 32px; justify-content: flex-end; position: sticky; bottom: 0; background: var(--bg-body); padding: 16px 0; z-index: 10;">
                <button type="button" class="btn btn-delete" style="margin-right: auto; background: #FFEBEE; color: #C62828; padding: 10px 20px; border-radius: 12px; font-weight: 600;" onclick="handleDeleteSchoolAndRedirect('${id}')">លុបសាលា</button>
                <button type="button" class="btn btn-secondary" onclick="navigateTo('#/schools')">បោះបង់</button>
                <button type="submit" class="btn btn-primary" style="padding: 12px 40px;">រក្សាទុកការកែប្រែ</button>
            </div>
        </form>
    `;
}

function handleEditSchoolSubmit(event, id) {
    event.preventDefault();

    const form = event.target;
    const formData = new FormData(form);

    let schoolId = formData.get('schoolId').trim();
    if (schoolId && !schoolId.startsWith('Sch')) {
        schoolId = 'Sch' + schoolId;
    }

    const updatedData = {
        schoolId: schoolId,
        schoolName: formData.get('schoolName').trim(),
        village: formData.get('village').trim(),
        commune: formData.get('commune').trim(),
        district: formData.get('district').trim(),
        province: formData.get('province').trim(),
        directorName: formData.get('directorName').trim(),
        phoneNumber: formData.get('phoneNumber').trim(),
        description: formData.get('description').trim()
    };

    updateSchool(id, updatedData);
    if (typeof showAlert === 'function') showAlert('School updated successfully!');
    navigateTo('#/schools');
}

function handleDeleteSchoolAndRedirect(id) {
    if (confirm('Are you sure you want to delete this school?')) {
        if (deleteSchool(id)) {
            if (typeof showAlert === 'function') showAlert('School deleted successfully');
            navigateTo('#/schools');
        }
    }
}
