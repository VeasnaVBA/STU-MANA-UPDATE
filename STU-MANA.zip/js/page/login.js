// js/page/login.js
function renderLogin() {
    const container = document.getElementById('content-area');
    // Hide sidebar on login page
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');
    
    if (sidebar) sidebar.style.display = 'none';
    if (mainContent) {
        mainContent.style.marginLeft = '0';
        mainContent.style.maxWidth = '100%';
    }

    container.innerHTML = `
        <div class="login-wrapper" style="display: flex; align-items: center; justify-content: center; min-height: 80vh; background: var(--bg-body);">
            <div class="login-card" style="background: white; padding: 40px; border-radius: var(--radius); box-shadow: var(--shadow-lg); width: 100%; max-width: 400px; animation: slideUp 0.4s ease;">
                <div style="text-align: center; margin-bottom: 32px;">
                    <div style="display: flex; justify-content: center; align-items: center; gap: 12px; margin-bottom: 16px;">
                        <svg width="40" height="40" viewBox="0 0 32 32" fill="none">
                            <path d="M16 2L4 9V23L16 30L28 23V9L16 2Z" fill="#004ad9" />
                            <path d="M16 2L4 9L16 16L28 9L16 2Z" fill="#3375ff" />
                        </svg>
                        <h2 style="font-size: 24px; font-weight: 700; color: var(--text-primary); margin: 0;">School<span style="color: var(--primary);">Mana</span></h2>
                    </div>
                    <p style="color: var(--text-secondary); font-size: 14px;">Welcome back! Please login to your account.</p>
                </div>

                <form id="login-form" onsubmit="handleLoginSubmit(event)">
                    <div class="form-group" style="margin-bottom: 20px;">
                        <label style="display: block; margin-bottom: 8px; font-size: 13px; font-weight: 600;">Username</label>
                        <input type="text" id="username" name="username" required 
                               style="width: 100%; padding: 12px 16px; border: 2px solid var(--border); border-radius: var(--radius-sm); outline: none; transition: border-color 0.2s;"
                               placeholder="Enter your username">
                    </div>
                    <div class="form-group" style="margin-bottom: 24px;">
                        <label style="display: block; margin-bottom: 8px; font-size: 13px; font-weight: 600;">Password</label>
                        <input type="password" id="password" name="password" required 
                               style="width: 100%; padding: 12px 16px; border: 2px solid var(--border); border-radius: var(--radius-sm); outline: none; transition: border-color 0.2s;"
                               placeholder="Enter your password">
                    </div>
                    
                    <div id="login-error" style="color: #D32F2F; font-size: 13px; margin-bottom: 16px; display: none; text-align: center; padding: 8px; background: #FFEBEE; border-radius: 8px;"></div>

                    <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px; font-weight: 600; font-size: 15px; margin-top: 8px;">
                        Sign In
                    </button>
                </form>

                <div style="margin-top: 32px; text-align: center; border-top: 1px solid var(--border); padding-top: 24px;">
                    <p style="color: var(--text-secondary); font-size: 13px;">Demo Account: admin / 123</p>
                </div>
            </div>
        </div>
    `;

    // Add animation styles
    const style = document.createElement('style');
    style.innerHTML = `
        @keyframes slideUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        #login-form input:focus { border-color: var(--primary) !important; }
    `;
    document.head.appendChild(style);
}

function handleLoginSubmit(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const result = login(formData.get('username'), formData.get('password'));
    
    const errorEl = document.getElementById('login-error');
    if (result.success) {
        errorEl.style.display = 'none';
        // Show sidebar and restore layout
        const sidebar = document.querySelector('.sidebar');
        const mainContent = document.querySelector('.main-content');
        if (sidebar) sidebar.style.display = 'flex';
        if (mainContent) {
            mainContent.style.marginLeft = 'var(--sidebar-width)';
            mainContent.style.maxWidth = 'calc(100% - var(--sidebar-width))';
        }
        
        window.location.hash = '#/dashboard';
        renderDashboard();
        updateSidebarActive('#/dashboard');
        updateUserInfo();
    } else {
        errorEl.textContent = result.message;
        errorEl.style.display = 'block';
    }
}

function updateUserInfo() {
    const user = getCurrentUser();
    if (!user) return;
    
    // You can add a user profile section in the sidebar if needed
}
