/* js/page/students.js */
function renderStudentsList() {
    const container = document.getElementById('content-area');
    const currentUser = getCurrentUser();

    container.innerHTML = `
        <div class="page-header">
            <h1>បញ្ជីឈ្មោះសិស្សសរុប</h1>
            <a href="#/add-student" class="btn btn-primary" onclick="navigateTo('#/add-student'); return false;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
                    <line x1="12" y1="5" x2="12" y2="19"></line>
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
                បន្ថែមសិស្សថ្មី
            </a>
        </div>

        <div class="search-box">
            <div style="display: flex; align-items: center; gap: 8px; flex: 1;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--text-secondary)" stroke-width="2">
                    <circle cx="11" cy="11" r="8"></circle>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                </svg>
                <input type="text" id="search-input" placeholder="Search or filter..." oninput="handleSearch(this.value)">
            </div>
            
            <div style="display: flex; align-items: center; gap: 10px;">
                <select id="filter-select" onchange="handleFilter()" style="min-width: 120px;">
                    <option value="all">ទាំងអស់</option>
                    <option value="Female">ស្រី</option>
                    <option value="Male">ប្រុស</option>
                    <option value="Active">កំពុងរៀន</option>
                    <option value="Inactive">ឈប់រៀន</option>
                </select>
                
                <div style="width: 1px; height: 24px; background: var(--border);"></div>
                
                <select id="sort-select" onchange="handleSort(this.value)" style="min-width: 150px;">
                    <option value="stuKhmerLastName-asc">ឈ្មោះ: ក-អ</option>
                    <option value="stuKhmerLastName-desc">ឈ្មោះ: អ-ក</option>
                    <option value="stuEngFirstName-asc">Name: A-Z</option>
                    <option value="stuEngFirstName-desc">Name: Z-A</option>
                    <option value="gender-female">ភេទ: ស្រី-ប្រុស</option>
                    <option value="gender-male">ភេទ: ប្រុស-ស្រី</option>
                    <option value="status-active">ស្ថានភាព: កំពុងរៀន</option>
                    <option value="status-inactive">ស្ថានភាព: ឈប់រៀន</option>
                    <option value="stuId-asc">អត្តលេខ: ទាប-ខ្ពស់</option>
                    <option value="stuId-desc">អត្តលេខ: ខ្ពស់-ទាប</option>
                </select>

                <button class="btn-minimal" onclick="importStudentsFromExcel()" title="Import Excel">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                        <polyline points="17 8 12 3 7 8"></polyline>
                        <line x1="12" y1="3" x2="12" y2="15"></line>
                    </svg>
                </button>
                <button class="btn-minimal" onclick="exportStudentsToExcel()" title="Export Excel">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                        <polyline points="7 10 12 15 17 10"></polyline>
                        <line x1="12" y1="15" x2="12" y2="3"></line>
                    </svg>
                </button>
            </div>
        </div>

        <div class="data-table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th style="width: 60px; padding-left: 24px;">ស្ថានភាព</th>
                        <th>ឈ្មោះសិស្ស</th>
                        <th>អត្តលេខ</th>
                        <th>ភេទ</th>
                        <th>ថ្ងៃខែឆ្នាំកំណើត</th>
                        <th>លេខទូរស័ព្ទ</th>
                        <th>ថ្នាក់រៀន</th>
                        <th>សាលារៀន</th>
                        <th>គ្រូបន្ទុកថ្នាក់</th>
                        <th class="sticky-actions-header" style="right: 0;">សកម្មភាព</th>
                    </tr>
                </thead>
                <tbody id="students-table-body">
                    <!-- Rendered by JS -->
                </tbody>
            </table>
        </div>
    `;

    refreshStudentTable();
}

let currentStudents = [];

function refreshStudentTable() {
    const tbody = document.getElementById('students-table-body');
    if (!tbody) return;

    const baseStudents = getFilteredStudents();
    const filterValue = document.getElementById('filter-select').value;
    
    let filtered = baseStudents;
    if (filterValue === 'Female') {
        filtered = baseStudents.filter(s => ['Female', 'female', 'ស្រី', 'ស', 'F', 'f'].includes(s.gender));
    } else if (filterValue === 'Male') {
        filtered = baseStudents.filter(s => ['Male', 'male', 'ប្រុស', 'ប', 'M', 'm'].includes(s.gender));
    } else if (filterValue === 'Active') {
        filtered = baseStudents.filter(s => s.status === 'Active');
    } else if (filterValue === 'Inactive') {
        filtered = baseStudents.filter(s => s.status === 'Inactive');
    }

    // Apply search if input is not empty
    const searchQuery = document.getElementById('search-input').value;
    if (searchQuery) {
        const lower = searchQuery.toLowerCase();
        filtered = filtered.filter(s =>
            (s.stuEngFirstName && s.stuEngFirstName.toLowerCase().includes(lower)) ||
            (s.stuEngLastName && s.stuEngLastName.toLowerCase().includes(lower)) ||
            (s.stuKhmerFirstName && s.stuKhmerFirstName.includes(lower)) ||
            (s.stuKhmerLastName && s.stuKhmerLastName.includes(lower)) ||
            (s.stuId && s.stuId.toLowerCase().includes(lower)) ||
            (s.school && s.school.toLowerCase().includes(lower)) ||
            (s.classroom && s.classroom.toLowerCase().includes(lower))
        );
    }

    currentStudents = filtered;
    renderTableData(currentStudents);
}

function handleFilter() {
    refreshStudentTable();
}

function renderTableData(students) {
    const tbody = document.getElementById('students-table-body');
    if (!tbody) return;

    if (students.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="10" style="padding: 48px; text-align: center;">
                    <div style="color: var(--text-secondary); font-size: 14px;">No students match your search.</div>
                </td>
            </tr>
        `;
        return;
    }

    const teachers = getTeachers();

    tbody.innerHTML = students.map((student) => {
        const teacher = teachers.find(t => t.id === student.teacher);
        const teacherName = teacher ? `${teacher.tkhLastName || ''} ${teacher.tkhFirstName || ''}`.trim() || teacher.tengFirstName + ' ' + teacher.tengLastName : student.teacher;

        return `
        <tr>
            <td style="padding-left: 24px;">
                <div class="status-switch ${student.status === 'Active' ? 'active' : ''}" title="${student.status || 'Active'}"></div>
            </td>
            <td>
                <div class="student-name-cell">
                    <div class="student-row-avatar">
                        ${renderAvatar(student.photo, '👨‍🎓')}
                    </div>
                    <div>
                        <div style="font-size: 14px; font-weight: 600;">${student.stuKhmerLastName || ''} ${student.stuKhmerFirstName || ''}</div>
                        <div style="font-size: 11px; color: var(--text-secondary);">${student.stuEngFirstName || ''} ${student.stuEngLastName || ''}</div>
                    </div>
                </div>
            </td>
            <td style="font-family: monospace; font-size: 12px; color: var(--text-secondary);">${student.stuId || student.id}</td>
            <td>${['Male', 'male', 'ប្រុស', 'ប', 'M', 'm'].includes(student.gender) ? 'ប្រុស' : (['Female', 'female', 'ស្រី', 'ស', 'F', 'f'].includes(student.gender) ? 'ស្រី' : student.gender || '-')}</td>
            <td>${(() => {
                if (!student.dateOfBirth) return '-';
                const dob = String(student.dateOfBirth);
                const parts = dob.split(/[-/]/);
                if (parts.length === 3) {
                    if (parts[0].length === 4) return `${parts[2]}/${parts[1]}/${parts[0]}`;
                    return `${parts[0]}/${parts[1]}/${parts[2]}`;
                }
                return dob;
            })()}</td>
            <td>${student.stuPhoneNumber || '-'}</td>
            <td><span class="grade-badge" style="background: var(--bg-body); border: 1px solid var(--border); color: var(--primary); font-size: 11px;">${student.classroom || '-'}</span></td>
            <td style="font-size: 13px;">${student.school || '-'}</td>
            <td style="font-size: 13px; color: var(--text-secondary);">${teacherName || '-'}</td>
            <td class="sticky-actions">
                <div style="display: flex; align-items: center; gap: 4px;">
                    <button class="btn-minimal" onclick="navigateTo('#/show-student?id=${student.id}')" title="View Details">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                            <circle cx="12" cy="12" r="3"></circle>
                        </svg>
                    </button>
                    <button class="btn-minimal" onclick="navigateTo('#/edit-student?id=${student.id}')" title="Edit">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                        </svg>
                    </button>
                    <button class="btn-minimal" onclick="handleDeleteStudent('${student.id}')" title="Delete">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="3 6 5 6 21 6"></polyline>
                            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                        </svg>
                    </button>
                </div>
            </td>
        </tr>
    `;
    }).join('');
}

function handleSearch(query) {
    refreshStudentTable();
}

function handleSort(value) {
    const students = getFilteredStudents();
    const sorted = [...students].sort((a, b) => {
        if (value === 'stuKhmerLastName-asc') {
            const nameA = (a.stuKhmerLastName || '') + (a.stuKhmerFirstName || '');
            const nameB = (b.stuKhmerLastName || '') + (b.stuKhmerFirstName || '');
            return nameA.localeCompare(nameB, 'km');
        }
        if (value === 'stuKhmerLastName-desc') {
            const nameA = (a.stuKhmerLastName || '') + (a.stuKhmerFirstName || '');
            const nameB = (b.stuKhmerLastName || '') + (b.stuKhmerFirstName || '');
            return nameB.localeCompare(nameA, 'km');
        }
        if (value === 'gender-female') {
            const isAFemale = ['Female', 'female', 'ស្រី', 'ស', 'F', 'f'].includes(a.gender);
            const isBFemale = ['Female', 'female', 'ស្រី', 'ស', 'F', 'f'].includes(b.gender);
            if (isAFemale && !isBFemale) return -1;
            if (!isAFemale && isBFemale) return 1;
            return 0;
        }
        if (value === 'gender-male') {
            const isAMale = ['Male', 'male', 'ប្រុស', 'ប', 'M', 'm'].includes(a.gender);
            const isBMale = ['Male', 'male', 'ប្រុស', 'ប', 'M', 'm'].includes(b.gender);
            if (isAMale && !isBMale) return -1;
            if (!isAMale && isBMale) return 1;
            return 0;
        }
        if (value === 'status-active') {
            if (a.status === 'Active' && b.status !== 'Active') return -1;
            if (a.status !== 'Active' && b.status === 'Active') return 1;
            return 0;
        }
        if (value === 'status-inactive') {
            if (a.status === 'Inactive' && b.status !== 'Inactive') return -1;
            if (a.status !== 'Inactive' && b.status === 'Inactive') return 1;
            return 0;
        }

        const [field, direction] = value.split('-');
        let valA = a[field] || '';
        let valB = b[field] || '';

        if (typeof valA === 'string') {
            valA = valA.toLowerCase();
            valB = valB.toLowerCase();
        }

        if (direction === 'asc') {
            return valA > valB ? 1 : -1;
        }
        return valA < valB ? 1 : -1;
    });
    renderTableData(sorted);
}

function handleDeleteStudent(id) {
    if (confirm('Are you sure you want to delete this student?')) {
        if (deleteStudent(id)) {
            showAlert('Student deleted successfully');
            refreshStudentTable();
        }
    }
}

function exportStudentsToExcel() {
    const students = getFilteredStudents();
    if (students.length === 0) {
        if (typeof showAlert === 'function') showAlert('No students to export', 'error');
        return;
    }

    if (!window.confirm(`Are you sure you want to export ${students.length} student records to Excel?`)) {
        return;
    }

    // Prepare data for export
    const teachers = getTeachers();
    const data = students.map((s, index) => {
        const teacher = teachers.find(t => t.id === s.teacher);
        const teacherName = teacher ? `${teacher.tkhLastName || ''} ${teacher.tkhFirstName || ''}`.trim() || (teacher.tengFirstName + ' ' + teacher.tengLastName) : s.teacher;

        return {
            'ល.រ': index + 1,
            'អត្តលេខ': s.stuId || s.id,
            'នាមត្រកូល(ខ្មែរ)': s.stuKhmerLastName || '',
            'នាមខ្លួន(ខ្មែរ)': s.stuKhmerFirstName || '',
            'នាមត្រកូល(អង់គ្លេស)': s.stuEngLastName || '',
            'នាមខ្លួន(អង់គ្លេស)': s.stuEngFirstName || '',
            'ភេទ': s.gender || '',
            'ថ្ងៃខែឆ្នាំកំណើត': s.dateOfBirth || '',
            'ភូមិកំណើត': s.birthVillage || '',
            'ឃុំកំណើត': s.birthCommune || '',
            'ស្រុកកំណើត': s.birthDistrict || '',
            'ខេត្តកំណើត': s.birthProvince || '',
            'ភូមិបច្ចុប្បន្ន': s.currentVillage || '',
            'ឃុំបច្ចុប្បន្ន': s.currentCommmune || '',
            'ស្រុកបច្ចុប្បន្ន': s.currentDistrict || '',
            'ខេត្តបច្ចុប្បន្ន': s.currentProvince || '',
            'លេខទូរស័ព្ទសិស្ស': s.stuPhoneNumber || '',
            'ឈ្មោះឪពុក': s.fatherName || '',
            'មុខរបរឪពុក': s.fatherJob || '',
            'លេខទូរស័ព្ទឪពុក': s.fatherPhone || '',
            'ឈ្មោះម្តាយ': s.motherName || '',
            'មុខរបរម្តាយ': s.motherJob || '',
            'លេខទូរស័ព្ទម្តាយ': s.motherPhone || '',
            'ថ្នាក់រៀន': s.classroom || '',
            'សាលារៀន': s.school || '',
            'គ្រូបន្ទុកថ្នាក់': teacherName || '',
            'ស្ថានភាព': s.status || 'Active',
            'ពណ៌នា': s.description || ''
        };
    });

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Students");

    // Set Column Widths (wch is width in characters)
    const wscols = [
        { wch: 6 },   // A: ល.រ
        { wch: 9 },   // B: អត្តលេខ
        { wch: 15 },  // C: នាមត្រកូល(ខ្មែរ)
        { wch: 20 },  // D: នាមខ្លួន(ខ្មែរ)
        { wch: 20 },  // E: នាមត្រកូល(អង់គ្លេស)
        { wch: 20 },  // F: នាមខ្លួន(អង់គ្លេស)
        { wch: 8 },   // G: ភេទ
        { wch: 13 },  // H: ថ្ងៃខែឆ្នាំកំណើត
        { wch: 15 },  // I: ភូមិកំណើត
        { wch: 15 },  // J: ឃុំកំណើត
        { wch: 15 },  // K: ស្រុកកំណើត
        { wch: 15 },  // L: ខេត្តកំណើត
        { wch: 15 },  // M: ភូមិបច្ចុប្បន្ន
        { wch: 15 },  // N: ឃុំបច្ចុប្បន្ន
        { wch: 15 },  // O: ស្រុកបច្ចុប្បន្ន
        { wch: 15 },  // P: ខេត្តបច្ចុប្បន្ន
        { wch: 15 },  // Q: លេខទូរស័ព្ទសិស្ស
        { wch: 15 },  // R: ឈ្មោះឪពុក
        { wch: 15 },  // S: មុខរបរឪពុក
        { wch: 15 },  // T: លេខទូរស័ព្ទឪពុក
        { wch: 15 },  // U: ឈ្មោះម្តាយ
        { wch: 15 },  // V: មុខរបរម្តាយ
        { wch: 15 },  // W: លេខទូរស័ព្ទម្តាយ
        { wch: 8 },   // X: ថ្នាក់រៀន
        { wch: 25 },  // Y: សាលារៀន
        { wch: 15 },  // Z: គ្រូបន្ទុកថ្នាក់
        { wch: 10 },  // AA: ស្ថានភាព
        { wch: 25 }   // AB: ពណ៌នា
    ];
    worksheet['!cols'] = wscols;

    // Set Row Heights
    const wsrows = [{ hpx: 30 }];
    for (let i = 0; i < data.length; i++) {
        wsrows.push({ hpx: 25 });
    }
    worksheet['!rows'] = wsrows;

    // Apply styles to all cells (requires xlsx-js-style)
    const range = XLSX.utils.decode_range(worksheet['!ref']);
    for (let R = range.s.r; R <= range.e.r; ++R) {
        for (let C = range.s.c; C <= range.e.c; ++C) {
            const cell_address = { c: C, r: R };
            const cell_ref = XLSX.utils.encode_cell(cell_address);
            if (!worksheet[cell_ref]) continue;

            // Determine alignment for this column
            let alignment = 'center'; // Default
            if ([2, 3, 4, 5, 27].includes(C)) { // C, D, E, F, AB
                alignment = 'left';
            }

            worksheet[cell_ref].s = {
                font: {
                    name: "Khmer OS Siemreap",
                    sz: 10,
                    color: { rgb: "000000" }
                },
                alignment: {
                    vertical: "center",
                    horizontal: alignment,
                    wrapText: true
                },
                border: {
                    top: { style: "thin", color: { rgb: "E2E8F0" } },
                    bottom: { style: "thin", color: { rgb: "E2E8F0" } },
                    left: { style: "thin", color: { rgb: "E2E8F0" } },
                    right: { style: "thin", color: { rgb: "E2E8F0" } }
                }
            };

            if (R === 0) {
                worksheet[cell_ref].s.font.bold = true;
                worksheet[cell_ref].s.font.color = { rgb: "FFFFFF" };
                worksheet[cell_ref].s.fill = {
                    patternType: "solid",
                    fgColor: { rgb: "004AD9" }
                };
                worksheet[cell_ref].s.alignment.horizontal = "center"; // Header always center
            }
        }
    }

    XLSX.writeFile(workbook, "Students_List.xlsx");
}

function importStudentsFromExcel() {
    if (!confirm("The Import Data Will replace all the exist data . Do you want to import?")) {
        return;
    }

    const currentUser = getCurrentUser();
    const teachers = getTeachers();
    let mySchool = null;

    if (currentUser && currentUser.role === 'Teacher') {
        const myTeacherRecord = teachers.find(t => (t.tengFirstName + ' ' + t.tengLastName) === currentUser.name);
        if (myTeacherRecord) {
            mySchool = myTeacherRecord.school;
        }
    }

    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.xlsx, .xls';

    input.onchange = e => {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = function (e) {
            try {
                const data = new Uint8Array(e.target.result);
                const workbook = XLSX.read(data, { type: 'array' });
                const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
                const jsonData = XLSX.utils.sheet_to_json(firstSheet);

                if (jsonData.length === 0) {
                    showAlert('Excel file is empty', 'error');
                    return;
                }

                // Clear existing students
                saveStudents([]);

                let importedCount = 0;
                let failedStudents = [];

                jsonData.forEach((row, index) => {
                    const rowNo = index + 1;
                    const stuId = (row['អត្តលេខ'] || '').toString();
                    const stuName = `${row['នាមត្រកូល(ខ្មែរ)'] || ''} ${row['នាមខ្លួន(ខ្មែរ)'] || ''}`.trim() || row['នាមខ្លួន(អង់គ្លេស)'] || 'Unknown';
                    const school = row['សាលារៀន'] || '';

                    // Check school match for Teacher
                    if (mySchool && (!school || school !== mySchool)) {
                        failedStudents.push({
                            no: rowNo,
                            id: stuId,
                            name: stuName,
                            school: school || 'No School'
                        });
                        return;
                    }

                    // Skip if row is essentially empty
                    if (!stuId && !row['នាមខ្លួន(អង់គ្លេស)']) return;

                    // Find teacher by name
                    const teacherName = row['គ្រូបន្ទុកថ្នាក់'];
                    const teacher = teachers.find(t =>
                        (`${t.tkhLastName || ''} ${t.tkhFirstName || ''}`.trim() === teacherName) ||
                        (`${t.tengFirstName || ''} ${t.tengLastName || ''}`.trim() === teacherName)
                    );

                    const student = {
                        stuId: stuId,
                        stuKhmerLastName: row['នាមត្រកូល(ខ្មែរ)'] || '',
                        stuKhmerFirstName: row['នាមខ្លួន(ខ្មែរ)'] || '',
                        stuEngLastName: row['នាមត្រកូល(អង់គ្លេស)'] || '',
                        stuEngFirstName: row['នាមខ្លួន(អង់គ្លេស)'] || '',
                        gender: row['ភេទ'] || '',
                        dateOfBirth: (() => {
                            const raw = row['ថ្ងៃខែឆ្នាំកំណើត'];
                            if (!raw) return '';
                            
                            const numRaw = Number(raw);
                            if (!isNaN(numRaw) && typeof raw !== 'object' && numRaw > 10000 && numRaw < 100000) {
                                // Likely an Excel serial date
                                try {
                                    const date = new Date((numRaw - 25569) * 86400 * 1000);
                                    if (!isNaN(date.getTime())) {
                                        const d = String(date.getDate()).padStart(2, '0');
                                        const m = String(date.getMonth() + 1).padStart(2, '0');
                                        const y = date.getFullYear();
                                        return `${d}/${m}/${y}`;
                                    }
                                } catch (e) {
                                    console.error('Error converting Excel date:', e);
                                }
                            }
                            
                            if (raw instanceof Date) {
                                const d = String(raw.getDate()).padStart(2, '0');
                                const m = String(raw.getMonth() + 1).padStart(2, '0');
                                const y = raw.getFullYear();
                                return `${d}/${m}/${y}`;
                            }
                            return String(raw);
                        })(),
                        birthVillage: row['ភូមិកំណើត'] || '',
                        birthCommune: row['ឃុំកំណើត'] || '',
                        birthDistrict: row['ស្រុកកំណើត'] || '',
                        birthProvince: row['ខេត្តកំណើត'] || '',
                        currentVillage: row['ភូមិបច្ចុប្បន្ន'] || '',
                        currentCommmune: row['ឃុំបច្ចុប្បន្ន'] || '',
                        currentDistrict: row['ស្រុកបច្ចុប្បន្ន'] || '',
                        currentProvince: row['ខេត្តបច្ចុប្បន្ន'] || '',
                        stuPhoneNumber: row['លេខទូរស័ព្ទសិស្ស'] || '',
                        fatherName: row['ឈ្មោះឪពុក'] || '',
                        fatherJob: row['មុខរបរឪពុក'] || '',
                        fatherPhone: row['លេខទូរស័ព្ទឪពុក'] || '',
                        motherName: row['ឈ្មោះម្តាយ'] || '',
                        motherJob: row['មុខរបរម្តាយ'] || '',
                        motherPhone: row['លេខទូរស័ព្ទម្តាយ'] || '',
                        classroom: row['ថ្នាក់រៀន'] || '',
                        school: school,
                        teacher: teacher ? teacher.id : (row['គ្រូបន្ទុកថ្នាក់'] || ''),
                        status: row['ស្ថានភាព'] || 'Active',
                        description: row['ពណ៌នា'] || '',
                        photo: (row['ភេទ'] === 'Female' ? '👩‍GT' : '👨‍🎓')
                    };

                    addStudent(student);
                    importedCount++;
                });

                if (importedCount > 0) {
                    showAlert(`Successfully imported ${importedCount} students! Existing data has been replaced.`);
                    refreshStudentTable();
                } else {
                    showAlert('No students were imported.', 'error');
                }

                if (failedStudents.length > 0) {
                    showFailedImportReport(failedStudents, mySchool);
                }
            } catch (err) {
                console.error(err);
                showAlert('Error parsing Excel file.', 'error');
            }
        };
        reader.readAsArrayBuffer(file);
    };

    input.click();
}

function showFailedImportReport(failedStudents, mySchool) {
    const html = `
        <div style="padding: 20px;">
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 20px; color: #B71C1C;">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="12" y1="8" x2="12" y2="12"></line>
                    <line x1="12" y1="16" x2="12.01" y2="16"></line>
                </svg>
                <div>
                    <h2 style="margin: 0; font-size: 20px;">School Mismatch Report</h2>
                    <p style="margin: 4px 0 0; color: var(--text-secondary); font-size: 14px;">
                        The following students were NOT imported because they don't belong to your school (<b>${mySchool}</b>).
                    </p>
                </div>
            </div>

            <div style="max-height: 400px; overflow-y: auto; border: 1px solid var(--border); border-radius: var(--radius-sm);">
                <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
                    <thead style="background: var(--bg-body); position: sticky; top: 0;">
                        <tr>
                            <th style="padding: 10px; text-align: center; border-bottom: 1px solid var(--border);">No</th>
                            <th style="padding: 10px; text-align: left; border-bottom: 1px solid var(--border);">ID</th>
                            <th style="padding: 10px; text-align: left; border-bottom: 1px solid var(--border);">Student Name</th>
                            <th style="padding: 10px; text-align: left; border-bottom: 1px solid var(--border);">Found School</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${failedStudents.map(s => `
                            <tr>
                                <td style="padding: 8px 10px; text-align: center; border-bottom: 1px solid var(--border);">${s.no}</td>
                                <td style="padding: 8px 10px; border-bottom: 1px solid var(--border); font-family: monospace;">${s.id}</td>
                                <td style="padding: 8px 10px; border-bottom: 1px solid var(--border); font-weight: 500;">${s.name}</td>
                                <td style="padding: 8px 10px; border-bottom: 1px solid var(--border); color: #D32F2F;">${s.school}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>

            <div style="margin-top: 24px; text-align: right;">
                <button class="btn btn-primary" onclick="closeModal()">I Understand</button>
            </div>
        </div>
    `;
    openModal(html);
}
