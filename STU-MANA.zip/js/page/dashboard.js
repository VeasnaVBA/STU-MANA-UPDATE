// js/pages/dashboard.js
function renderDashboard() {
    const container = document.getElementById('content-area');

    const students = getStudents();
    const scores = getScores();
    
    // Find the latest month that has scores
    const periods = [...new Set(scores.map(s => s.period))];
    const latestPeriod = periods.length > 0 ? periods[periods.length - 1] : 'No Data';

    // Calculate averages for each student for the latest period
    const leaderboard = students.map(s => {
        const studentScores = scores.filter(sc => sc.studentId === s.id && sc.period === latestPeriod);
        let total = 0;
        studentScores.forEach(sc => {
            if (sc.score !== '' && sc.score !== null) total += parseFloat(sc.score);
        });
        
        // Use a default coefficient of 10 for dashboard display or detect from settings
        const coeff = 10; 
        const average = studentScores.length > 0 ? (total / coeff) : 0;
        
        return {
            ...s,
            latestAverage: average,
            latestTotal: total
        };
    });

    // Sort by average
    leaderboard.sort((a, b) => b.latestAverage - a.latestAverage);
    const top5 = leaderboard.filter(s => s.latestAverage > 0).slice(0, 5);

    const avgClassScore = leaderboard.length
        ? (leaderboard.reduce((sum, s) => sum + (s.latestAverage || 0), 0) / leaderboard.length).toFixed(2)
        : '0.00';

    const topPerformer = top5[0] ? `${top5[0].stuKhmerFirstName}` : '-';

    container.innerHTML = `
        <div class="dashboard-header">
            <div>
                <h1 style="margin:0;">School Dashboard</h1>
                <p style="margin:5px 0 0; color: var(--text-secondary); font-size: 14px;">Latest Assessment: <strong>${getPeriodName(latestPeriod)}</strong></p>
            </div>
        </div>

        <div style="margin-bottom: 24px;">
            <h2 style="font-size: 18px; margin-bottom: 16px; display: flex; align-items: center; gap: 10px;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"></path>
                </svg>
                Monthly Top Performers
            </h2>
            <div class="leaderboard-container" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px;">
                ${top5.length > 0 ? top5.map((student, index) => {
                    const fullName = `${student.stuKhmerLastName} ${student.stuKhmerFirstName}`;
                    const avg = student.latestAverage.toFixed(2);
                    return `
                    <div class="rank-card rank-${index + 1}" style="display: flex; align-items: center; padding: 16px; background: var(--bg-card); border-radius: 16px; box-shadow: var(--shadow); position: relative; border-left: 4px solid ${index === 0 ? '#ffd700' : (index === 1 ? '#c0c0c0' : (index === 2 ? '#cd7f32' : 'var(--border)'))}">
                        <div class="rank-number" style="width: 32px; height: 32px; background: ${index === 0 ? '#ffd700' : (index === 1 ? '#c0c0c0' : (index === 2 ? '#cd7f32' : 'var(--bg-body)'))}; color: ${index < 3 ? 'white' : 'var(--text-secondary)'}; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 14px; margin-right: 15px;">
                            ${index + 1}
                        </div>
                        <div style="flex: 1;">
                            <div style="font-weight: 700; font-size: 15px; color: var(--text-primary); margin-bottom: 4px;">${fullName}</div>
                            <div style="font-size: 12px; color: var(--text-secondary);">${student.stuId} | ${student.classroom || 'No Class'}</div>
                        </div>
                        <div style="text-align: right;">
                            <div style="font-size: 18px; font-weight: 800; color: var(--primary);">${avg}</div>
                            <div style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; font-weight: 700;">Avg Score</div>
                        </div>
                    </div>
                `}).join('') : `<div style="grid-column: 1/-1; text-align: center; padding: 40px; background: var(--bg-card); border-radius: 16px; border: 2px dashed var(--border); color: var(--text-secondary);">No score data available for ${latestPeriod} yet.</div>`}
            </div>
        </div>

        <div class="stats-grid" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px;">
            <div class="stat-card" style="background: var(--bg-card); padding: 20px; border-radius: 16px; display: flex; align-items: center; gap: 15px; box-shadow: var(--shadow);">
                <div class="stat-icon" style="width: 48px; height: 48px; background: var(--border); border-radius: 12px; display: flex; align-items: center; justify-content: center; color: var(--primary);">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                    </svg>
                </div>
                <div>
                    <div style="font-size: 24px; font-weight: 800; color: var(--text-primary);">${students.length}</div>
                    <div style="font-size: 12px; color: var(--text-secondary);">Total Students</div>
                </div>
            </div>
            <div class="stat-card" style="background: var(--bg-card); padding: 20px; border-radius: 16px; display: flex; align-items: center; gap: 15px; box-shadow: var(--shadow);">
                <div class="stat-icon" style="width: 48px; height: 48px; background: var(--border); border-radius: 12px; display: flex; align-items: center; justify-content: center; color: var(--primary);">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <polyline points="12 6 12 12 16 14"></polyline>
                    </svg>
                </div>
                <div>
                    <div style="font-size: 24px; font-weight: 800; color: var(--text-primary);">${avgClassScore}</div>
                    <div style="font-size: 12px; color: var(--text-secondary);">Class Average</div>
                </div>
            </div>
            <div class="stat-card" style="background: var(--bg-card); padding: 20px; border-radius: 16px; display: flex; align-items: center; gap: 15px; box-shadow: var(--shadow);">
                <div class="stat-icon" style="width: 48px; height: 48px; background: var(--border); border-radius: 12px; display: flex; align-items: center; justify-content: center; color: var(--primary);">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M6 9l6 6 6-6"></path>
                    </svg>
                </div>
                <div>
                    <div style="font-size: 20px; font-weight: 800; color: var(--text-primary);">${topPerformer}</div>
                    <div style="font-size: 12px; color: var(--text-secondary);">Top Performer</div>
                </div>
            </div>
        </div>
    `;
}
