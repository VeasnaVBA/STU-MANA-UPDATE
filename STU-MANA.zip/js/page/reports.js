// js/page/reports.js
console.log('Reports script loading...');

function renderReportsList() {
    const container = document.getElementById('content-area');
    const currentUser = getCurrentUser();
    if (!currentUser) return;

    let teacherClassroom = '';
    let teacherGrade = '';
    if (currentUser.role === 'Teacher') {
        const teachers = getTeachers();
        const myTeacher = teachers.find(t => (t.tengFirstName + ' ' + t.tengLastName) === currentUser.name);
        if (myTeacher) {
            teacherClassroom = myTeacher.classroom || '';
            // Extract numeric grade from classroom (e.g., "10A" -> "10")
            const match = teacherClassroom ? teacherClassroom.match(/\d+/) : null;
            if (match) teacherGrade = match[0];
        }
    }

    const periods = [
        "First Test", "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December",
        "Semester 1 Exam", "Semester 2 Exam", "Semester 1", "Semester 2", "Annual"
    ];

    container.innerHTML = `
        <div class="page-header">
            <div class="header-title">
                <h1>School Reports</h1>
                <p>Generate official school reports</p>
            </div>
        </div>

        <div style="padding: 24px;">
            <div style="background: var(--bg-card); padding: 32px; border-radius: var(--radius-md); box-shadow: var(--shadow-sm); display: flex; align-items: center; justify-content: space-between; border: 1px solid var(--border);">
                <div>
                    <h3 style="margin-bottom: 8px; color: var(--text-primary);">តារាងស្រង់ពិន្ទុ</h3>
                    <p style="color: var(--text-secondary); margin: 0; font-size: 15px;">Generate official classroom score lists with customizable typography, borders, and margins.</p>
                </div>
                <button class="btn btn-primary" onclick="navigateTo('#/handwriting-report')" style="padding: 12px 24px; font-size: 16px; font-weight: 600; display: flex; align-items: center; gap: 10px;">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                    </svg>
                    តារាងស្រង់ពិន្ទុ
                </button>
            </div>
            
            <div style="background: var(--bg-card); padding: 32px; border-radius: var(--radius-md); box-shadow: var(--shadow-sm); display: flex; align-items: center; justify-content: space-between; border: 1px solid var(--border); margin-top: 20px;">
                <div>
                    <h3 style="margin-bottom: 8px; color: var(--text-primary);">តារាងចំណាត់ថ្នាក់(ពីរជួរ)</h3>
                    <p style="color: var(--text-secondary); margin: 0; font-size: 15px;">Generate official two-column ranking lists for a specific period.</p>
                </div>
                <div style="display: flex; gap: 12px; align-items: center; flex-wrap: nowrap;">
                    ${teacherClassroom ? `
                        <div style="background: #f1f5f9; padding: 0 16px; border-radius: 8px; border: 1px solid #cbd5e1; font-weight: 700; color: var(--primary); height: 48px; display: flex; align-items: center; font-size: 14px; min-width: 100px;">
                            Class: ${teacherClassroom}
                        </div>
                        <input type="hidden" id="ranking-grade" value="${teacherGrade}">
                    ` : `
                        <select id="ranking-grade" class="form-control" style="width: 120px; height: 48px; padding: 0 12px; border-radius: 8px; border: 1px solid #cbd5e1; font-weight: 600;">
                            <option value="">Grade</option>
                            <option value="7">Grade 7</option>
                            <option value="8">Grade 8</option>
                            <option value="9">Grade 9</option>
                            <option value="10">Grade 10</option>
                            <option value="11">Grade 11</option>
                            <option value="12">Grade 12</option>
                        </select>
                    `}
                    <select id="ranking-month" class="form-control" style="width: 180px; height: 48px; padding: 0 12px; border-radius: 8px; border: 1px solid #cbd5e1; font-weight: 600;">
                        <option value="">ជ្រើសរើសខែ</option>
                        ${periods.map(p => `<option value="${p}">${getPeriodName(p)}</option>`).join('')}
                    </select>
                    <button class="btn btn-primary" onclick="initRankingReport()" style="height: 48px; padding: 0 20px; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 8px; border-radius: 8px; border: none; white-space: nowrap;">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                            <polyline points="14 2 14 8 20 8"></polyline>
                            <line x1="16" y1="13" x2="8" y2="13"></line>
                            <line x1="16" y1="17" x2="8" y2="17"></line>
                        </svg>
                        តារាងចំណាត់ថ្នាក់
                    </button>
                    <button class="btn btn-secondary" onclick="syncAndInitHonor()" style="height: 48px; padding: 0 20px; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 8px; background: #FFF3E0; color: #E65100; border: 1px solid #FFE0B2; border-radius: 8px; white-space: nowrap;">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"></path>
                        </svg>
                        តារាងកិត្តិយស
                    </button>
                </div>
            </div>
        </div>
    `;
}

window.renderReportsList = renderReportsList;

window.initRankingReport = function () {
    const grade = document.getElementById('ranking-grade').value;
    const period = document.getElementById('ranking-month').value;
    if (!grade || !period) {
        showAlert('Please select Grade and Month first.', 'info');
        return;
    }

    const savedCalc = localStorage.getItem(`calc_${grade}_${period}`);
    if (!savedCalc) {
        showAlert('Setup the score first', 'error');
        return;
    }

    localStorage.setItem('temp_ranking_grade', grade);
    localStorage.setItem('temp_ranking_period', period);

    navigateTo('#/ranking-report');
};

function handleReportFilterChange() {
    const grade = document.getElementById('report-grade').value;
    const period = document.getElementById('report-period').value;

    if (grade && period) {
        generateClassReport();
    }
}

function generateClassReport() {
    const grade = document.getElementById('report-grade').value;
    const period = document.getElementById('report-period').value;

    if (!grade || !period) {
        showAlert('Please select both Grade and Period.', 'info');
        return;
    }

    const reportContent = document.getElementById('report-content');
    const subjects = getSubjects();
    const students = getFilteredStudents().filter(s => s.classroom && s.classroom.startsWith(grade));

    if (students.length === 0) {
        reportContent.innerHTML = `
            <div style="text-align: center; padding: 100px 40px; color: var(--text-secondary);">
                <p>No students found for Grade ${grade}.</p>
            </div>
        `;
        return;
    }

    // Use coefficient from settings
    const coeff = getPeriodCoefficient(period);

    const results = students.map(s => {
        let total = 0;
        const subScores = {};
        subjects.forEach(sub => {
            const scores = getScoresByPeriodAndSubject(period, sub.id);
            const scoreObj = scores.find(sc => sc.studentId === s.id);
            const scoreVal = (scoreObj && scoreObj.score !== '' && scoreObj.score !== null) ? parseFloat(scoreObj.score) : 0;
            total += scoreVal;
            subScores[sub.id] = scoreVal > 0 ? scoreVal : '-';
        });

        const average = total / coeff;
        return {
            id: s.stuId,
            dbId: s.id,
            name: `${s.stuKhmerLastName} ${s.stuKhmerFirstName}`,
            gender: s.gender,
            total: total.toFixed(2),
            average: average.toFixed(2),
            avgNum: average,
            subScores: subScores
        };
    });

    results.sort((a, b) => b.avgNum - a.avgNum);
    results.forEach((r, i) => r.rank = i + 1);

    reportContent.innerHTML = `
        <div style="padding: 24px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 style="font-size: 18px; color: var(--text-primary);">Class Summary: Grade ${grade} - ${getPeriodName(period)}</h2>
                <div style="font-size: 14px; color: var(--text-secondary);">
                    Total Students: <strong>${students.length}</strong> | 
                    Average Coefficient: <strong>${coeff}</strong>
                </div>
            </div>
            
            <div style="overflow-x: auto;">
                <table class="data-table" style="width: 100%; min-width: 1000px;">
                    <thead>
                        <tr>
                            <th style="width: 50px; text-align: center;">No</th>
                            <th style="width: 60px; text-align: center;">Rank</th>
                            <th style="width: 100px;">ID</th>
                            <th>Student Name</th>
                            <th style="width: 60px; text-align: center;">Sex</th>
                            ${subjects.map(sub => `<th style="text-align: center; font-size: 11px;">${sub.subjectName}</th>`).join('')}
                            <th style="width: 80px; text-align: center; background: #f8f9fa;">Total</th>
                            <th style="width: 80px; text-align: center; background: #f0f4ff;">Avg</th>
                            <th style="width: 60px; text-align: center;">Grade</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${results.map((r, index) => `
                            <tr onclick="viewIndividualReport('${r.dbId}', '${period}')" style="cursor: pointer;">
                                <td style="text-align: center;">${index + 1}</td>
                                <td style="text-align: center;">
                                    <span style="font-weight: 700; color: #d32f2f;">${r.rank}</span>
                                </td>
                                <td>${r.id}</td>
                                <td style="font-weight: 600;">${r.name}</td>
                                <td style="text-align: center;">${r.gender}</td>
                                ${subjects.map(sub => `<td style="text-align: center;">${r.subScores[sub.id]}</td>`).join('')}
                                <td style="text-align: center; font-weight: 700; background: #fafafa;">${r.total}</td>
                                <td style="text-align: center; font-weight: 700; color: var(--primary); background: #f5f8ff;">${r.average}</td>
                                <td style="text-align: center;">
                                    ${renderGradeBadge(calculateGrade(r.average, 50))}
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        </div>
    `;
}

function viewIndividualReport(studentId, period) {
    const student = getStudentById(studentId);
    if (!student) return;

    const subjects = getSubjects();
    const scores = subjects.map(sub => {
        const studentScores = getScoresByPeriodAndSubject(period, sub.id);
        const scoreObj = studentScores.find(s => s.studentId === studentId);
        const gradeMatch = student.classroom ? student.classroom.match(/^\d+/) : null;
        const studentGrade = gradeMatch ? gradeMatch[0] : '';
        return {
            name: sub.subjectName,
            score: (scoreObj && scoreObj.score !== '' && scoreObj.score !== null) ? parseFloat(scoreObj.score) : 0,
            max: sub.maxScores ? (sub.maxScores[studentGrade] || 100) : 100
        };
    });

    const total = scores.reduce((sum, s) => sum + s.score, 0);
    const coeff = getPeriodCoefficient(period);
    const average = (total / coeff).toFixed(2);
    const grade = calculateGrade(average, 50);

    const html = `
        <div style="padding: 30px; max-width: 600px;">
            <div style="display: flex; align-items: center; gap: 20px; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 1px solid var(--border);">
                <div style="width: 80px; height: 80px; background: #f0f4ff; border-radius: 16px; display: flex; align-items: center; justify-content: space-center; font-size: 32px;">
                    👤
                </div>
                <div>
                    <h2 style="margin: 0; font-size: 24px; color: var(--text-primary);">${student.stuKhmerLastName} ${student.stuKhmerFirstName}</h2>
                    <p style="margin: 5px 0 0; color: var(--text-secondary);">ID: ${student.stuId} | Class: ${student.classroom} | ${getPeriodName(period)}</p>
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin-bottom: 30px;">
                <div style="background: #f8f9fa; padding: 15px; border-radius: 12px; text-align: center;">
                    <div style="font-size: 12px; color: var(--text-secondary); text-transform: uppercase; margin-bottom: 5px;">Total Score</div>
                    <div style="font-size: 20px; font-weight: 700; color: var(--text-primary);">${total.toFixed(2)}</div>
                </div>
                <div style="background: #eef2ff; padding: 15px; border-radius: 12px; text-align: center; border: 1px solid #e0e7ff;">
                    <div style="font-size: 12px; color: var(--primary); text-transform: uppercase; margin-bottom: 5px;">Average</div>
                    <div style="font-size: 20px; font-weight: 800; color: var(--primary);">${average}</div>
                </div>
                <div style="background: #f8f9fa; padding: 15px; border-radius: 12px; text-align: center;">
                    <div style="font-size: 12px; color: var(--text-secondary); text-transform: uppercase; margin-bottom: 5px;">Letter Grade</div>
                    <div>${renderGradeBadge(grade)}</div>
                </div>
            </div>

            <h3 style="font-size: 16px; margin-bottom: 15px;">Subject Breakdown</h3>
            <div style="display: flex; flex-direction: column; gap: 10px;">
                ${scores.map(s => `
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 12px 16px; background: white; border: 1px solid var(--border); border-radius: 8px;">
                        <span style="font-weight: 500;">${s.name}</span>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <span style="font-weight: 700; color: ${s.score < (s.max * 0.5) ? '#d32f2f' : 'var(--text-primary)'}">${s.score}</span>
                            <span style="color: var(--text-secondary); font-size: 12px;">/ ${s.max}</span>
                        </div>
                    </div>
                `).join('')}
            </div>

            <div style="margin-top: 30px; display: flex; gap: 12px;">
                <button class="btn btn-primary" onclick="printReport()" style="flex: 1; padding: 12px;">
                    Print Report Card
                </button>
                <button class="btn btn-secondary" onclick="closeModal()" style="padding: 12px 24px;">Close</button>
            </div>
        </div>
    `;
    openModal(html);
}

function exportFullReport() {
    const grade = document.getElementById('report-grade').value;
    const period = document.getElementById('report-period').value;

    if (!grade || !period) {
        showAlert('Please select Grade and Period first.', 'info');
        return;
    }

    if (typeof exportAllSubjects === 'function') {
        const scoreGrade = document.getElementById('score-grade');
        const scorePeriod = document.getElementById('score-period');

        if (scoreGrade && scorePeriod) {
            scoreGrade.value = grade;
            scorePeriod.value = period;
        }

        exportAllSubjects();
    } else {
        showAlert('Export functionality is being initialized...', 'info');
    }
}

function printClassReport() {
    const grade = document.getElementById('report-grade').value;
    const period = document.getElementById('report-period').value;

    if (!grade || !period) {
        showAlert('Please select Grade and Period first.', 'info');
        return;
    }

    const subjects = getSubjects();
    const students = getFilteredStudents().filter(s => s.classroom && s.classroom.startsWith(grade));

    if (students.length === 0) {
        showAlert('No students found to print.', 'error');
        return;
    }

    const coeff = getPeriodCoefficient(period);
    const results = students.map(s => {
        let total = 0;
        const subScores = {};
        subjects.forEach(sub => {
            const scores = getScoresByPeriodAndSubject(period, sub.id);
            const scoreObj = scores.find(sc => sc.studentId === s.id);
            const scoreVal = (scoreObj && scoreObj.score !== '' && scoreObj.score !== null) ? parseFloat(scoreObj.score) : 0;
            total += scoreVal;
            subScores[sub.id] = scoreVal > 0 ? scoreVal.toFixed(1) : '-';
        });
        const average = total / coeff;
        return {
            id: s.stuId || '-',
            dbId: s.id,
            name: `${s.stuKhmerLastName || ''} ${s.stuKhmerFirstName || ''}`.trim(),
            gender: s.gender || '-',
            total: total.toFixed(2),
            average: average.toFixed(2),
            grade: calculateGrade(average, 50),
            subScores: subScores
        };
    });

    results.sort((a, b) => b.average - a.average);
    results.forEach((r, i) => r.rank = i + 1);

    let iframe = document.getElementById('print-iframe');
    if (!iframe) {
        iframe = document.createElement('iframe');
        iframe.id = 'print-iframe';
        iframe.style.position = 'absolute';
        iframe.style.width = '0';
        iframe.style.height = '0';
        iframe.style.border = 'none';
        document.body.appendChild(iframe);
    }
    const printDoc = iframe.contentWindow.document;
    printDoc.open();
    printDoc.write(`
        <html>
        <head>
            <title>Class Report - Grade ${grade} - ${period}</title>
            <style>
                @page { size: A4 landscape; margin: 1cm; }
                body { font-family: 'Khmer OS Battambang', 'Inter', sans-serif; margin: 0; padding: 20px; color: #000; }
                .header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #333; padding-bottom: 10px; }
                .header h1 { margin: 0; font-size: 24px; text-transform: uppercase; }
                .header p { margin: 5px 0 0; font-size: 16px; color: #555; }
                
                table { width: 100%; border-collapse: collapse; margin-top: 10px; }
                th, td { border: 1px solid #333; padding: 6px 4px; text-align: center; font-size: 11px; }
                th { background-color: #f2f2f2; font-weight: bold; }
                
                .text-left { text-align: left; padding-left: 8px; }
                .student-name { min-width: 160px; }
                .rank-column { background-color: #f9f9f9; font-weight: bold; color: #d32f2f; }
                .total-column { background-color: #f2f2f2; font-weight: bold; }
                
                .footer { margin-top: 40px; display: flex; justify-content: space-between; padding: 0 50px; }
                .signature-box { text-align: center; width: 220px; }
                .signature-line { margin-top: 50px; border-top: 1px solid #000; padding-top: 5px; font-weight: 600; }

                @media print {
                    .no-print { display: none; }
                    body { padding: 0; }
                }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>Student Score Report Summary</h1>
                <p>Grade: ${grade} | Period: ${period} | Total Students: ${students.length}</p>
            </div>

            <table>
                <thead>
                    <tr>
                        <th style="width: 30px;">No</th>
                        <th style="width: 40px;">Rank</th>
                        <th style="width: 70px;">ID</th>
                        <th class="student-name">Student Full Name</th>
                        <th style="width: 40px;">Sex</th>
                        ${subjects.map(sub => `<th>${sub.subjectName}</th>`).join('')}
                        <th class="total-column" style="width: 60px;">Total</th>
                        <th class="total-column" style="width: 60px;">Avg</th>
                        <th style="width: 40px;">Grade</th>
                    </tr>
                </thead>
                <tbody>
                    ${results.map((r, index) => `
                        <tr>
                            <td>${index + 1}</td>
                            <td class="rank-column">${r.rank}</td>
                            <td style="font-family: monospace; font-size: 10px;">${r.id}</td>
                            <td class="text-left">${r.name}</td>
                            <td>${r.gender}</td>
                            ${subjects.map(sub => `<td>${r.subScores[sub.id]}</td>`).join('')}
                            <td class="total-column">${r.total}</td>
                            <td class="total-column">${r.average}</td>
                            <td>${r.grade}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>

            <div class="footer">
                <div class="signature-box">
                    <div>Class Teacher</div>
                    <div class="signature-line">Name & Signature</div>
                </div>
                <div class="signature-box">
                    <div>Director</div>
                    <div class="signature-line">Name & Signature</div>
                </div>
            </div>

            <script>
                window.onload = function() {
                    setTimeout(() => {
                        window.print();
                    }, 500);
                };
            </script>
        </body>
        </html>
    `);
    printDoc.close();
}

function getFontOptions(selected) {
    const fonts = [
        { name: 'Khmer OS Muol Light', value: 'Khmer OS Muol Light' },
        { name: 'Khmer OS Battambang', value: 'Khmer OS Battambang' },
        { name: 'Khmer OS Siemreap', value: 'Khmer OS Siemreap' },
        { name: 'Inter', value: 'Inter' }
    ];
    return fonts.map(f => `<option value="${f.value}" ${selected === f.value ? 'selected' : ''}>${f.name}</option>`).join('');
}

function getHandwritingReportHTML(students, school, margins, grade) {
    const uniqueClassrooms = [...new Set(students.map(s => s.classroom).filter(Boolean))];
    const displayGrade = (uniqueClassrooms.length === 1) ? uniqueClassrooms[0] : (grade || '.......');
    const mid = Math.ceil(students.length / 2);
    const leftCol = students.slice(0, mid);
    const rightCol = students.slice(mid);
    const fs = margins.fontSizes || {};
    const ff = margins.fontFamilies || {};

    const colWidths = margins.colWidths || { no: 25, id: 50, name: 120, sex: 30, dob: 75, score: 45, remarks: 45 };

    const renderTable = (list, startIdx) => {
        let rows = list.map((s, i) => `
            <tr>
                <td style="width: ${colWidths.no}px;">${startIdx + i + 1}</td>
                <td class="id-cell">${s.stuId || ''}</td>
                <td class="name-cell">${s.stuKhmerLastName} ${s.stuKhmerFirstName}</td>
                <td class="sex-cell">${['Female', 'female', 'ស្រី', 'ស', 'F', 'f'].includes(s.gender) ? 'ស្រី' : (['Male', 'male', 'ប្រុស', 'ប', 'M', 'm'].includes(s.gender) ? 'ប្រុស' : (s.gender || ''))}</td>
                <td class="dob-cell">${(() => {
                    if (!s.dateOfBirth) return '';
                    const dob = String(s.dateOfBirth);
                    const parts = dob.split(/[-/]/);
                    if (parts.length === 3) {
                        // If yyyy-mm-dd, convert to dd/mm/yyyy
                        if (parts[0].length === 4) return `${parts[2]}/${parts[1]}/${parts[0]}`;
                        // If already dd/mm/yyyy or dd-mm-yyyy, return as dd/mm/yyyy
                        return `${parts[0]}/${parts[1]}/${parts[2]}`;
                    }
                    return dob;
                })()}</td>
                <td class="score-cell"></td>
                <td class="remarks-cell"></td>
            </tr>
        `).join('');

        const minRows = margins.minRows || 0;
        if (list.length < minRows) {
            for (let i = list.length; i < minRows; i++) {
                rows += `<tr><td style="width: ${colWidths.no}px;">&nbsp;</td><td></td><td></td><td></td><td></td><td></td><td></td></tr>`;
            }
        }

        return `
            <table>
                <thead>
                    <tr>
                        <th style="width: ${colWidths.no}px;">ល.រ</th>
                        <th class="id-cell">អត្តលេខ</th>
                        <th class="name-cell">គោត្តនាម និងនាម</th>
                        <th class="sex-cell">ភេទ</th>
                        <th class="dob-cell">ថ្ងៃខែឆ្នាំកំណើត</th>
                        <th class="score-cell">ពិន្ទុ</th>
                        <th class="remarks-cell">ផ្សេងៗ</th>
                    </tr>
                </thead>
                <tbody>${rows}</tbody>
            </table>
        `;
    };

    return `
        <div class="report-print-body">
            <div class="official-header" style="margin-top: ${margins.headerTop}px; margin-bottom: ${margins.titleSpacing}px;">
                <div class="ministry-info">
                    <div class="school-ministry" style="margin-top: ${margins.ministrySpacing}px; margin-left: ${margins.ministryIndent || 0}px; word-break: break-word;">${school.ministry || 'ក្រសួងអប់រំ យុវជន និងកីឡា'}</div>
                    <div class="school-location" style="margin-top: ${margins.locationSpacing}px; margin-left: ${margins.locationIndent || 0}px; word-break: break-word;">${school.location || 'មន្ទីរអប់រំ យុវជន និងកីឡា'}</div>
                    <div class="school-name" style="margin-top: ${margins.schoolNameSpacing}px; margin-left: ${margins.schoolNameIndent || 0}px; word-break: break-word;">${school.schoolName || 'សាលារៀន................'}</div>
                </div>
                <div class="kingdom-info">
                    <div class="kingdom-slogan" style="margin-top: ${margins.kingdomSpacing}px; margin-left: ${margins.kingdomIndent || 0}px; word-break: break-word;">${school.kingdomSlogan || 'ព្រះរាជាណាចក្រកម្ពុជា'}</div>
                    <div class="nation-slogan" style="margin-top: ${margins.nationSpacing}px; margin-left: ${margins.nationIndent || 0}px; word-break: break-word;">${school.nationSlogan || 'ជាតិ សាសនា ព្រះមហាក្សត្រ'}</div>
                    <div style="text-align: center; margin-top: 10px;"><img src="https://upload.wikimedia.org/wikipedia/commons/b/b2/Sihanouk_Slogan.png" style="width: 80px; filter: grayscale(1);" onerror="this.style.display='none'"></div>
                </div>
            </div>

            <div class="report-title" style="margin: ${margins.titleSpacing}px 0; text-align: center;">
                <h1>តារាងស្រង់ពិន្ទុប្រចាំខែ${school.reportMonth || '.....................'}</h1>
            </div>

            <div class="sub-title" style="text-align: center; margin-bottom: 15px; font-weight: normal; word-break: break-word;">
                មុខវិជ្ជា:......................... ថ្នាក់ទី: ${displayGrade}  ឆ្នាំសិក្សា: ${school.schoolYear || '2024-2025'}
            </div>

            <div class="columns-container" style="margin-top: ${margins.tableTop}px;">
                <div class="report-column">${renderTable(leftCol, 0)}</div>
                <div class="report-column">${renderTable(rightCol, mid)}</div>
            </div>

            <div class="report-footer" style="margin-top: ${margins.footerTop !== undefined ? margins.footerTop : 30}px; display: flex; justify-content: space-between; align-items: flex-start; padding: 0 40px;">
                <div class="signature-box" style="margin-top: 50px; margin-left: ${margins.footerSeenIndent || 0}px;">
                    <div class="footer-seen" style="padding-top: 5px; font-weight: normal;">${school.footerSeen || 'បានឃើញ និងឯកភាព'}</div>
                    <div class="footer-director" style="padding-top: 5px; font-weight: normal; margin-left: ${margins.footerDirectorIndent || 0}px;">${school.footerDirector || 'នាយក'}</div>
                    <div class="signature-line" style="margin-top: 60px;"></div>
                </div>
                <div class="signature-box" style="margin-left: ${margins.footerSignatureIndent || 0}px; text-align: center;">
                    ${school.footerDate2 ? `<div class="footer-date2" style="padding-top: 5px; font-weight: normal; margin-left: ${margins.footerDate2Indent || 0}px; white-space: nowrap;">${school.footerDate2}</div>` : ''}
                    <div class="footer-date" style="padding-top: 5px; font-weight: normal; margin-left: ${margins.footerDateIndent || 0}px; white-space: nowrap;">${school.footerLocation ? school.footerLocation + ', ' : ''}${school.footerDate || 'ថ្ងៃទី.......ខែ.......ឆ្នាំ២០២...'}</div>
                    <div class="footer-signature" style="padding-top: 5px; font-weight: normal; white-space: nowrap;">${school.footerSignature || 'ហត្ថលេខាគ្រូមុខវិជ្ជា'}</div>
                    <div class="signature-line" style="margin-top: 60px;"></div>
                </div>
            </div>
        </div>
    `;
}

function getRankingReportHTML(results, school, margins, grade, period) {
    const uniqueClassrooms = [...new Set(results.map(r => r.classroom).filter(Boolean))];
    const displayGrade = (uniqueClassrooms.length === 1) ? uniqueClassrooms[0] : (grade || '.......');
    const mid = Math.ceil(results.length / 2);
    const leftCol = results.slice(0, mid);
    const rightCol = results.slice(mid);
    const fs = margins.fontSizes || {};
    const ff = margins.fontFamilies || {};

    const colWidths = margins.colWidths || { no: 25, id: 50, name: 120, sex: 30, dob: 75, score: 45, remarks: 45, rank: 45 };

    const renderTable = (list, startIdx) => {
        let rows = list.map((s, i) => `
            <tr>
                <td style="width: ${colWidths.no}px; text-align: center;">${startIdx + i + 1}</td>
                <td class="name-cell">${s.name || ''}</td>
                <td class="sex-cell" style="text-align: center;">${['Female', 'female', 'ស្រី', 'ស', 'F', 'f'].includes(s.gender) ? 'ស្រី' : (['Male', 'male', 'ប្រុស', 'ប', 'M', 'm'].includes(s.gender) ? 'ប្រុស' : (s.gender || ''))}</td>
                <td class="score-cell" style="text-align: center; font-weight: bold;">${s.average}</td>
                <td class="score-cell" style="text-align: center; width: ${colWidths.rank || 45}px; color: #d32f2f; font-weight: bold;">${s.rank}</td>
                <td class="remarks-cell" style="text-align: center;">${s.grade}</td>
            </tr>
        `).join('');

        const minRows = margins.minRows || 0;
        if (list.length < minRows) {
            for (let i = list.length; i < minRows; i++) {
                rows += `<tr><td style="width: ${colWidths.no}px;">&nbsp;</td><td></td><td></td><td></td><td style="width: ${colWidths.rank || 45}px;"></td><td></td></tr>`;
            }
        }

        return `
            <table>
                <thead>
                    <tr>
                        <th style="width: ${colWidths.no}px;">ល.រ</th>
                        <th class="name-cell">គោត្តនាម និងនាម</th>
                        <th class="sex-cell">ភេទ</th>
                        <th class="score-cell">មធ្យមភាគ</th>
                        <th class="score-cell" style="width: ${colWidths.rank || 45}px;">ចំណាត់ថ្នាក់</th>
                        <th class="remarks-cell">និទ្ទេស</th>
                    </tr>
                </thead>
                <tbody>${rows}</tbody>
            </table>
        `;
    };

    return `
        <div class="report-print-body">
            <div class="official-header" style="margin-top: ${margins.headerTop}px; margin-bottom: ${margins.titleSpacing}px;">
                <div class="ministry-info">
                    <div class="school-ministry" style="margin-top: ${margins.ministrySpacing}px; margin-left: ${margins.ministryIndent || 0}px; word-break: break-word;">${school.ministry || 'ក្រសួងអប់រំ យុវជន និងកីឡា'}</div>
                    <div class="school-location" style="margin-top: ${margins.locationSpacing}px; margin-left: ${margins.locationIndent || 0}px; word-break: break-word;">${school.location || 'មន្ទីរអប់រំ យុវជន និងកីឡា'}</div>
                    <div class="school-name" style="margin-top: ${margins.schoolNameSpacing}px; margin-left: ${margins.schoolNameIndent || 0}px; word-break: break-word;">${school.schoolName || 'សាលារៀន................'}</div>
                </div>
                <div class="kingdom-info">
                    <div class="kingdom-slogan" style="margin-top: ${margins.kingdomSpacing}px; margin-left: ${margins.kingdomIndent || 0}px; word-break: break-word;">${school.kingdomSlogan || 'ព្រះរាជាណាចក្រកម្ពុជា'}</div>
                    <div class="nation-slogan" style="margin-top: ${margins.nationSpacing}px; margin-left: ${margins.nationIndent || 0}px; word-break: break-word;">${school.nationSlogan || 'ជាតិ សាសនា ព្រះមហាក្សត្រ'}</div>
                    <div style="text-align: center; margin-top: 10px;"><img src="https://upload.wikimedia.org/wikipedia/commons/b/b2/Sihanouk_Slogan.png" style="width: 80px; filter: grayscale(1);" onerror="this.style.display='none'"></div>
                </div>
            </div>

            <div class="report-title" style="margin: ${margins.titleSpacing}px 0; text-align: center;">
                <h1>តារាងចំណាត់ថ្នាក់ ${getPeriodName(period)}</h1>
            </div>

            <div class="sub-title" style="text-align: center; margin-bottom: 15px; font-weight: normal; word-break: break-word;">
                ថ្នាក់ទី: ${displayGrade}  ឆ្នាំសិក្សា: ${school.schoolYear || '2024-2025'}
            </div>

            <div class="columns-container" style="margin-top: ${margins.tableTop}px;">
                <div class="report-column">${renderTable(leftCol, 0)}</div>
                <div class="report-column">${renderTable(rightCol, mid)}</div>
            </div>

            
            ${(() => {
            const isFemale = g => ['Female', 'female', 'ស្រី', 'ស', 'F', 'f'].includes(g);
            const totalAll = results.length;
            const totalFemale = results.filter(r => isFemale(r.gender)).length;

            const getGradeStats = gl => {
                const grp = results.filter(r => r.grade === gl);
                const fem = grp.filter(r => isFemale(r.gender)).length;
                return `និទ្ទេស ${gl}: <strong>${grp.length}</strong> នាក់ (ស្រី <strong>${fem}</strong>)`;
            };

            return `
                <div class="ranking-stats" style="margin-top:10px; line-height:1.8;">
                    <div style="margin-bottom:5px;">- សរុបសរុប: <strong>${totalAll}</strong> នាក់, ស្រី: <strong>${totalFemale}</strong> នាក់</div>
                    <div style="display: flex; gap: 40px;">
                        <div>
                            <div style="margin-bottom:2px;">- ${getGradeStats('A')}</div>
                            <div style="margin-bottom:2px;">- ${getGradeStats('B')}</div>
                            <div style="margin-bottom:2px;">- ${getGradeStats('C')}</div>
                        </div>
                        <div>
                            <div style="margin-bottom:2px;">- ${getGradeStats('D')}</div>
                            <div style="margin-bottom:2px;">- ${getGradeStats('E')}</div>
                            <div style="margin-bottom:2px;">- ${getGradeStats('F')}</div>
                        </div>
                    </div>
                </div>`;
        })()}
            <div class="report-footer" style="margin-top: ${margins.footerTop !== undefined ? margins.footerTop : 30}px; display: flex; justify-content: space-between; align-items: flex-start; padding: 0 40px;">
                <div class="signature-box" style="margin-top: 50px; margin-left: ${margins.footerSeenIndent || 0}px;">
                    <div class="footer-seen" style="padding-top: 5px; font-weight: normal;">${school.footerSeen || 'បានឃើញ និងឯកភាព'}</div>
                    <div class="footer-director" style="padding-top: 5px; font-weight: normal; margin-left: ${margins.footerDirectorIndent || 0}px;">${school.footerDirector || 'នាយក'}</div>
                    <div class="signature-line" style="margin-top: 60px;"></div>
                </div>
                <div class="signature-box" style="margin-left: ${margins.footerSignatureIndent || 0}px; text-align: center;">
                    ${school.footerDate2 ? `<div class="footer-date2" style="padding-top: 5px; font-weight: normal; margin-left: ${margins.footerDate2Indent || 0}px; white-space: nowrap;">${school.footerDate2}</div>` : ''}
                    <div class="footer-date" style="padding-top: 5px; font-weight: normal; margin-left: ${margins.footerDateIndent || 0}px; white-space: nowrap;">${school.footerLocation ? school.footerLocation + ', ' : ''}${school.footerDate || 'ថ្ងៃទី.......ខែ.......ឆ្នាំ២០២...'}</div>
                    <div class="footer-signature" style="padding-top: 5px; font-weight: normal; white-space: nowrap;">${school.footerSignature || 'គ្រូប្រចាំថ្នាក់'}</div>
                    <div class="signature-line" style="margin-top: 60px;"></div>
                </div>
            </div>
        </div>
    `;
}

function getHandwritingReportStyles(margins = {}) {
    const fs = margins.fontSizes || {};
    const ff = margins.fontFamilies || {};
    const colWidths = margins.colWidths || { no: 25, id: 50, name: 120, sex: 30, dob: 75, score: 45, remarks: 45 };
    return `
        .report-print-body { 
            font-family: '${ff.tableBody || 'Khmer OS Battambang'}', 'Inter', sans-serif; 
            color: #000; 
            line-height: 1.4; 
            background: white;
            display: flex;
            flex-direction: column;
            height: 100%;
        }
        .official-header { display: flex; justify-content: space-between; flex-shrink: 0; width: 100%; }
        .ministry-info, .kingdom-info { text-align: center; max-width: 45%; flex: 1; }
        
        .school-ministry { font-size: ${fs.ministry || 14}px !important; font-family: '${ff.ministry || 'Khmer OS Battambang'}' !important; }
        .school-location { font-size: ${fs.location || 14}px !important; font-family: '${ff.location || 'Khmer OS Battambang'}' !important; }
        .school-name { font-size: ${fs.schoolName || 16}px !important; font-family: '${ff.schoolName || 'Khmer OS Muol Light'}' !important; }
        
        .kingdom-slogan { font-size: ${fs.kingdom || 15}px !important; font-family: '${ff.kingdom || 'Khmer OS Muol Light'}' !important; }
        .nation-slogan { font-size: ${fs.nation || 14}px !important; font-family: '${ff.nation || 'Khmer OS Muol Light'}' !important; }

        .report-title h1 { 
            font-size: ${fs.title || 20}px !important; 
            font-family: '${ff.title || 'Khmer OS Muol Light'}' !important; 
            text-align: center;
            margin: 0;
        }
        .sub-title { 
            font-size: ${fs.subTitle || 14}px !important; 
            font-family: '${ff.subTitle || 'Khmer OS Battambang'}' !important; 
            text-align: center;
        }

        .columns-container { 
            display: flex;
            justify-content: space-between;
            min-height: 0;
            margin-bottom: 10px;
        }
        .report-column { 
            width: calc(50% - 10px);
            height: 100%; 
        }
        table { width: 100%; border-collapse: collapse; border: ${margins.tableBorderSize !== undefined ? margins.tableBorderSize : 1.5}px solid #000; background: white; }
        th, td { border: ${margins.tableBorderSize !== undefined ? margins.tableBorderSize : 1}px solid #000; padding: 4px 2px; text-align: center; height: 2.5em; box-sizing: border-box; }
        th { background: ${margins.tableHeaderColor || '#f0f0f0'} !important; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; color: #000; font-weight: normal; font-size: ${fs.tableHeader || 11}px; font-family: '${ff.tableHeader || 'Khmer OS Muol Light'}'; white-space: nowrap; }
        td { font-size: ${fs.tableBody || 11}px; font-family: '${ff.tableBody || 'Khmer OS Battambang'}'; }
        
        .footer-seen { font-size: ${fs.footerSeen || 13}px !important; font-family: '${ff.footerSeen || 'Khmer OS Muol Light'}' !important; }
        .footer-director { font-size: ${fs.footerDirector || 13}px !important; font-family: '${ff.footerDirector || 'Khmer OS Muol Light'}' !important; }
        .footer-date { font-size: ${fs.footerDate || 12}px !important; font-family: '${ff.footerDate || 'Khmer OS Battambang'}' !important; }
        .footer-date2 { font-size: ${fs.footerDate2 || 12}px !important; font-family: '${ff.footerDate2 || 'Khmer OS Battambang'}' !important; }
        .footer-signature { font-size: ${fs.footerSignature || 13}px !important; font-family: '${ff.footerSignature || 'Khmer OS Muol Light'}' !important; }
        
        .name-cell { text-align: left; padding-left: 8px; width: ${colWidths.name}px; font-weight: normal; }
        .id-cell { width: ${colWidths.id}px; }
        .sex-cell { width: ${colWidths.sex}px; }
        .dob-cell { width: ${colWidths.dob}px; }
        .score-cell { width: ${colWidths.score}px; }
        .remarks-cell { width: ${colWidths.remarks}px; }
        .report-footer { flex-shrink: 0; display: flex; justify-content: space-between; align-items: flex-start; padding: 0 40px; min-height: 150px; }
        .signature-box { text-align: center; min-width: 250px; width: auto; }
        .ranking-stats { font-family: '${ff.tableBody || 'Khmer OS Battambang'}' !important; font-size: ${fs.tableBody || 11}px !important; }
    `;
}

function printScoreSheet() {
    const gradeSelect = document.getElementById('report-grade');
    const grade = gradeSelect ? gradeSelect.value : '';
    const settings = getSettings();
    const school = settings.schoolInfo || {};
    const margins = settings.reportMargins || { headerTop: 0, tableTop: 20, footerTop: 30, titleSpacing: 10 };

    const students = getFilteredStudents()
        .filter(s => !grade || (s.classroom && s.classroom.startsWith(grade)))
        .sort((a, b) => (a.stuKhmerLastName + a.stuKhmerFirstName).localeCompare(b.stuKhmerLastName + b.stuKhmerFirstName));

    if (students.length === 0) {
        showAlert('No students found for this grade.', 'error');
        return;
    }

    let iframe = document.getElementById('print-iframe');
    if (!iframe) {
        iframe = document.createElement('iframe');
        iframe.id = 'print-iframe';
        iframe.style.position = 'absolute';
        iframe.style.width = '0';
        iframe.style.height = '0';
        iframe.style.border = 'none';
        document.body.appendChild(iframe);
    }
    const printDoc = iframe.contentWindow.document;
    printDoc.open();
    printDoc.write(`
        <html>
        <head>
            <title>Handwriting Report - Grade ${grade}</title>
            <style>
                @page { size: A4 portrait; margin: 0; }
                body { margin: 0; padding: 0; -webkit-print-color-adjust: exact; }
                .report-print-body {
                    padding-top: 10mm;
                    padding-bottom: 10mm;
                    padding-left: ${margins.pageLeft !== undefined ? margins.pageLeft : 38}px;
                    padding-right: ${margins.pageRight !== undefined ? margins.pageRight : 38}px;
                    width: 100%;
                    height: 296mm;
                    overflow: hidden;
                    display: flex;
                    flex-direction: column;
                    box-sizing: border-box;
                }
                ${getHandwritingReportStyles(margins)}
            </style>
        </head>
        <body>
            ${getHandwritingReportHTML(students, school, margins, grade)}
            <script>
                window.onload = function() {
                    setTimeout(() => {
                        window.print();
                    }, 500);
                };
            </script>
        </body>
        </html>
    `);
    printDoc.close();
}

function renderHandwritingReportUI() {
    const isHonor = window.location.hash === '#/honor-roll';
    const container = document.getElementById('content-area');
    const settings = getSettings();
    const schoolKey = window.location.hash === '#/ranking-report' ? 'rankingSchoolInfo' : (window.location.hash === '#/honor-roll' ? 'honorSchoolInfo' : 'reportSchoolInfo');
    const school = settings[schoolKey] || settings.schoolInfo || {};
    const marginKey = window.location.hash === '#/ranking-report' ? 'rankingMargins' : (window.location.hash === '#/honor-roll' ? 'honorMargins' : 'reportMargins');
    const margins = settings[marginKey] || {
        headerTop: 0, tableTop: 20, footerTop: 30, titleSpacing: 10,
        ministrySpacing: 0, locationSpacing: 0, schoolNameSpacing: 0,
        kingdomSpacing: 0, nationSpacing: 0
    };

    window.currentReportZoom = 0.8;

    const classrooms = [...new Set(getFilteredStudents().map(s => s.classroom).filter(Boolean))].sort();
    const periods = [
        "First Test", "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December",
        "Semester 1 Exam", "Semester 2 Exam", "Semester 1", "Semester 2", "Annual"
    ];

    const initialGrade = isHonor ? (localStorage.getItem('temp_honor_grade') || '') : (localStorage.getItem('temp_ranking_grade') || '');
    const initialPeriod = isHonor ? (localStorage.getItem('temp_honor_period') || '') : (localStorage.getItem('temp_ranking_period') || '');

    container.innerHTML = `
        <div class="report-ui-container">
            <div class="report-ui-header">
                <div class="header-left">
                    <a href="#/reports" class="back-link">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                            <line x1="19" y1="12" x2="5" y2="12"></line>
                            <polyline points="12 19 5 12 12 5"></polyline>
                        </svg>
                        Back to Reports
                    </a>
                    <h1>${window.location.hash === '#/honor-roll' ? 'តារាងកិត្តិយស' : (window.location.hash === '#/ranking-report' ? 'តារាងចំណាត់ថ្នាក់(ពីរជួរ)' : 'តារាងស្រង់ពិន្ទុ')}</h1>
                </div>
                <div class="header-right">
                    <button class="btn-glass" onclick="saveSchoolInfo(false)">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path>
                            <polyline points="17 21 17 13 7 13 7 21"></polyline>
                            <polyline points="7 3 7 8 15 8"></polyline>
                        </svg>
                        Save Settings
                    </button>
                    <button class="btn-dark" onclick="saveSchoolInfo(true)">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="6 9 6 2 18 2 18 9"></polyline>
                            <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path>
                            <rect x="6" y="14" width="12" height="8"></rect>
                        </svg>
                        Print Report
                    </button>
                    ${window.location.hash !== '#/honor-roll' ? `
                    <button class="btn-dark" onclick="exportHandwritingReportToPDF()" style="background: #D32F2F;">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                            <polyline points="14 2 14 8 20 8"></polyline>
                            <line x1="16" y1="13" x2="8" y2="13"></line>
                            <line x1="16" y1="17" x2="8" y2="17"></line>
                        </svg>
                        Export PDF
                    </button>
                    ` : ''}
                </div>
            </div>

            <div class="report-split-layout" style="grid-template-columns: auto 1fr;">

                <div class="controls-panel" id="report-controls-panel" style="height: min-content;">
                    <div class="panel-header" style="display: flex; align-items: center; gap: 10px;">
                        <button onclick="toggleReportControls()" class="btn-icon" style="background:none; border:none; cursor:pointer; color: var(--text-secondary); padding: 0; display: flex; align-items: center;" title="Toggle Controls">
                            <svg id="eye-icon-open" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:none;">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                                <circle cx="12" cy="12" r="3"></circle>
                            </svg>
                            <svg id="eye-icon-closed" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path>
                                <line x1="1" y1="1" x2="23" y2="23"></line>
                            </svg>
                        </button>
                        <h2 style="margin: 0;">Report Configuration</h2>
                    </div>

                    <div class="panel-body" id="report-controls-body" style="display: none;">
                        ${!isHonor ? `
                        <div class="control-section">
                            <div class="section-title">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
                                </svg>
                                ការកំណត់ទិន្នន័យ (Report Data)
                            </div>
                            <div class="form-group">
                                <label>ថ្នាក់ / បន្ទប់ (Grade / Classroom)</label>
                                <select id="report-grade" class="form-control" onchange="updateReportPreview()">
                                    <option value="">គ្រប់ថ្នាក់ទាំងអស់</option>
                                    ${classrooms.map(c => `<option value="${c}" ${c === initialGrade ? 'selected' : ''}>${c}</option>`).join('')}
                                </select>
                            </div>
                            ${(window.location.hash === '#/ranking-report' || isHonor) ? `
                            <div class="form-group">
                                <label>ខែ / គ្រា (Month / Period)</label>
                                <select id="report-period" class="form-control" onchange="updateReportPreview()">
                                    <option value="">ជ្រើសរើសគ្រា</option>
                                    ${periods.map(p => `<option value="${p}" ${p === initialPeriod ? 'selected' : ''}>${getPeriodName(p)}</option>`).join('')}
                                </select>
                            </div>
                            ` : ''}
                        </div>
                        ` : ''}

                        <div class="control-section">
                            <div class="section-title">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                                </svg>
                                School Information
                            </div>
                            
                            <div class="form-group">
                                <label>Ministry Name</label>
                                <div class="input-with-margin">
                                    <input type="text" id="school-info-ministry" value="${school.ministry || ''}" oninput="updateReportPreview()">
                                    <input type="number" id="margin-ministry" value="${margins.ministrySpacing || 0}" oninput="updateReportPreview()" class="margin-input" title="Top Margin">
                                    <input type="number" id="indent-ministry" value="${margins.ministryIndent || 0}" oninput="updateReportPreview()" class="indent-input" title="Left Margin">
                                    <input type="number" id="fs-ministry" value="${(margins.fontSizes || {}).ministry || 14}" oninput="updateReportPreview()" class="font-input" title="Font Size">
                                    <select id="ff-ministry" oninput="updateReportPreview()" class="font-family-select">${getFontOptions((margins.fontFamilies || {}).ministry || 'Khmer OS Battambang')}</select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Location / Province</label>
                                <div class="input-with-margin">
                                    <input type="text" id="school-info-location" value="${school.location || ''}" oninput="updateReportPreview()">
                                    <input type="number" id="margin-location" value="${margins.locationSpacing || 0}" oninput="updateReportPreview()" class="margin-input" title="Top Margin">
                                    <input type="number" id="indent-location" value="${margins.locationIndent || 0}" oninput="updateReportPreview()" class="indent-input" title="Left Margin">
                                    <input type="number" id="fs-location" value="${(margins.fontSizes || {}).location || 14}" oninput="updateReportPreview()" class="font-input" title="Font Size">
                                    <select id="ff-location" oninput="updateReportPreview()" class="font-family-select">${getFontOptions((margins.fontFamilies || {}).location || 'Khmer OS Battambang')}</select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label>School Name</label>
                                <div class="input-with-margin">
                                    <input type="text" id="school-info-name" value="${school.schoolName || ''}" oninput="updateReportPreview()">
                                    <input type="number" id="margin-school-name" value="${margins.schoolNameSpacing || 0}" oninput="updateReportPreview()" class="margin-input" title="Top Margin">
                                    <input type="number" id="indent-school-name" value="${margins.schoolNameIndent || 0}" oninput="updateReportPreview()" class="indent-input" title="Left Margin">
                                    <input type="number" id="fs-school-name" value="${(margins.fontSizes || {}).schoolName || 16}" oninput="updateReportPreview()" class="font-input" title="Font Size">
                                    <select id="ff-school-name" oninput="updateReportPreview()" class="font-family-select">${getFontOptions((margins.fontFamilies || {}).schoolName || 'Khmer OS Muol Light')}</select>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group">
                                    <label>School Year</label>
                                    <input type="text" id="school-info-year" value="${school.schoolYear || '2024-2025'}" oninput="updateReportPreview()">
                                </div>
                                <div class="form-group">
                                    <label>Report Month (Score Sheet)</label>
                                    <input type="text" id="school-info-report-month" value="${school.reportMonth || ''}" placeholder="មករា" oninput="updateReportPreview()">
                                </div>
                            </div>
                        </div>

                        <div class="control-section">
                            <div class="section-title">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <circle cx="12" cy="12" r="10"></circle>
                                    <path d="M12 8l4 4-4 4M8 12h7"></path>
                                </svg>
                                Official Slogans
                            </div>

                            <div class="form-group">
                                <label>Kingdom Slogan</label>
                                <div class="input-with-margin">
                                    <input type="text" id="school-info-kingdom" value="${school.kingdomSlogan || 'ព្រះរាជាណាចក្រកម្ពុជា'}" oninput="updateReportPreview()">
                                    <input type="number" id="margin-kingdom" value="${margins.kingdomSpacing || 0}" oninput="updateReportPreview()" class="margin-input" title="Top Margin">
                                    <input type="number" id="indent-kingdom" value="${margins.kingdomIndent || 0}" oninput="updateReportPreview()" class="indent-input" title="Left Margin">
                                    <input type="number" id="fs-kingdom" value="${(margins.fontSizes || {}).kingdom || 15}" oninput="updateReportPreview()" class="font-input" title="Font Size">
                                    <select id="ff-kingdom" oninput="updateReportPreview()" class="font-family-select">${getFontOptions((margins.fontFamilies || {}).kingdom || 'Khmer OS Muol Light')}</select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Nation Slogan</label>
                                <div class="input-with-margin">
                                    <input type="text" id="school-info-nation" value="${school.nationSlogan || 'ជាតិ សាសនា ព្រះមហាក្សត្រ'}" oninput="updateReportPreview()">
                                    <input type="number" id="margin-nation" value="${margins.nationSpacing || 0}" oninput="updateReportPreview()" class="margin-input" title="Top Margin">
                                    <input type="number" id="indent-nation" value="${margins.nationIndent || 0}" oninput="updateReportPreview()" class="indent-input" title="Left Margin">
                                    <input type="number" id="fs-nation" value="${(margins.fontSizes || {}).nation || 14}" oninput="updateReportPreview()" class="font-input" title="Font Size">
                                    <select id="ff-nation" oninput="updateReportPreview()" class="font-family-select">${getFontOptions((margins.fontFamilies || {}).nation || 'Khmer OS Muol Light')}</select>
                                </div>
                            </div>
                        </div>


                            <div class="control-section">
                            <div class="section-title">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M12 20h9M12 4h9M3 12h18M3 20h6M3 4h6"></path>
                                </svg>
                                Footer Information
                            </div>
                            <div class="form-group">
                                <label>Location (City/Province)</label>
                                <input type="text" id="footer-location" value="${school.footerLocation || ''}" placeholder="រាជធានីភ្នំពេញ" oninput="updateReportPreview()">
                            </div>
                            <div class="form-group">
                                <label>Date Text (Lunar)</label>
                                <div class="input-with-margin">
                                    <input type="text" id="footer-date2" value="${school.footerDate2 || ''}" placeholder="ថ្ងៃ... ... ខែ... ឆ្នាំ... ..." oninput="updateReportPreview()">
                                    <input type="number" id="indent-footer-date2" value="${margins.footerDate2Indent || 0}" oninput="updateReportPreview()" class="indent-input" title="Left Margin">
                                    <input type="number" id="fs-footer-date2" value="${(margins.fontSizes || {}).footerDate2 || 12}" oninput="updateReportPreview()" class="font-input" title="Font Size">
                                    <select id="ff-footer-date2" oninput="updateReportPreview()" class="font-family-select">${getFontOptions((margins.fontFamilies || {}).footerDate2 || 'Khmer OS Battambang')}</select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Date Text (Solar)</label>
                                <div class="input-with-margin">
                                    <input type="text" id="footer-date" value="${school.footerDate || 'ថ្ងៃទី.......ខែ.......ឆ្នាំ២០២...'}" oninput="updateReportPreview()">
                                    <input type="number" id="indent-footer-date" value="${margins.footerDateIndent || 0}" oninput="updateReportPreview()" class="indent-input" title="Left Margin">
                                    <input type="number" id="fs-footer-date" value="${(margins.fontSizes || {}).footerDate || 12}" oninput="updateReportPreview()" class="font-input" title="Font Size">
                                    <select id="ff-footer-date" oninput="updateReportPreview()" class="font-family-select">${getFontOptions((margins.fontFamilies || {}).footerDate || 'Khmer OS Battambang')}</select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Seen and Agreed</label>
                                <div class="input-with-margin">
                                    <input type="text" id="footer-seen" value="${school.footerSeen || 'បានឃើញ និងឯកភាព'}" oninput="updateReportPreview()">
                                    <input type="number" id="indent-footer-seen" value="${margins.footerSeenIndent || 0}" oninput="updateReportPreview()" class="indent-input" title="Left Margin">
                                    <input type="number" id="fs-footer-seen" value="${(margins.fontSizes || {}).footerSeen || 13}" oninput="updateReportPreview()" class="font-input" title="Font Size">
                                    <select id="ff-footer-seen" oninput="updateReportPreview()" class="font-family-select">${getFontOptions((margins.fontFamilies || {}).footerSeen || 'Khmer OS Muol Light')}</select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Director Title</label>
                                <div class="input-with-margin">
                                    <input type="text" id="footer-director" value="${school.footerDirector || 'នាយក'}" oninput="updateReportPreview()">
                                    <input type="number" id="indent-footer-director" value="${margins.footerDirectorIndent || 0}" oninput="updateReportPreview()" class="indent-input" title="Left Margin">
                                    <input type="number" id="fs-footer-director" value="${(margins.fontSizes || {}).footerDirector || 13}" oninput="updateReportPreview()" class="font-input" title="Font Size">
                                    <select id="ff-footer-director" oninput="updateReportPreview()" class="font-family-select">${getFontOptions((margins.fontFamilies || {}).footerDirector || 'Khmer OS Muol Light')}</select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Signature Label</label>
                                <div class="input-with-margin">
                                    <input type="text" id="footer-signature" value="${school.footerSignature || (isHonor ? 'គ្រូប្រចាំថ្នាក់' : 'ហត្ថលេខាគ្រូមុខវិជ្ជា')}" oninput="updateReportPreview()">
                                    <input type="number" id="indent-footer-signature" value="${margins.footerSignatureIndent || 0}" oninput="updateReportPreview()" class="indent-input" title="Left Margin">
                                    <input type="number" id="fs-footer-signature" value="${(margins.fontSizes || {}).footerSignature || 13}" oninput="updateReportPreview()" class="font-input" title="Font Size">
                                    <select id="ff-footer-signature" oninput="updateReportPreview()" class="font-family-select">${getFontOptions((margins.fontFamilies || {}).footerSignature || 'Khmer OS Muol Light')}</select>
                                </div>
                            </div>
                        </div>


                            <div class="control-section">
                            <div class="section-title">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                                    <line x1="3" y1="9" x2="21" y2="9"></line>
                                    <line x1="9" y1="21" x2="9" y2="9"></line>
                                </svg>
                                Layout & Margins (px)
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label>Page Top</label>
                                    <input type="number" id="margin-header-top" value="${margins.headerTop}" oninput="updateReportPreview()">
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label>Page Left</label>
                                    <input type="number" id="margin-page-left" value="${margins.pageLeft !== undefined ? margins.pageLeft : 38}" oninput="updateReportPreview()">
                                </div>
                                <div class="form-group">
                                    <label>Page Right</label>
                                    <input type="number" id="margin-page-right" value="${margins.pageRight !== undefined ? margins.pageRight : 38}" oninput="updateReportPreview()">
                                </div>
                            </div>
                            <div class="form-row">
                                ${!isHonor ? `
                                <div class="form-group">
                                    <label>Table Top</label>
                                    <input type="number" id="margin-table-top" value="${margins.tableTop}" oninput="updateReportPreview()">
                                </div>
                                ` : ''}
                                <div class="form-group">
                                    <label>Footer Top</label>
                                    <input type="number" id="margin-footer-top" value="${margins.footerTop}" oninput="updateReportPreview()">
                                </div>
                                <div class="form-group">
                                    <label>Title Font</label>
                                    <div class="input-with-margin">
                                        <input type="number" id="fs-title" value="${(margins.fontSizes || {}).title || 20}" oninput="updateReportPreview()" title="Title Font Size" class="font-input">
                                        <input type="number" id="margin-title" value="${margins.titleSpacing !== undefined ? margins.titleSpacing : 0}" oninput="updateReportPreview()" class="margin-input" title="Top Margin">
                                        <select id="ff-title" oninput="updateReportPreview()" class="font-family-select">${getFontOptions((margins.fontFamilies || {}).title || 'Khmer OS Muol Light')}</select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Subtitle Font</label>
                                    <div class="input-with-margin">
                                        <input type="number" id="fs-subtitle" value="${(margins.fontSizes || {}).subTitle || 14}" oninput="updateReportPreview()" title="Subtitle Font Size" class="font-input">
                                        <input type="number" id="margin-subtitle" value="${margins.subtitleSpacing || 0}" oninput="updateReportPreview()" class="margin-input" title="Top Margin">
                                        <select id="ff-subtitle" oninput="updateReportPreview()" class="font-family-select">${getFontOptions((margins.fontFamilies || {}).subTitle || 'Khmer OS Battambang')}</select>
                                    </div>
                                </div>
                                ${!isHonor ? `
                                <div class="form-group">
                                    <label>Table Header Font</label>
                                    <div class="input-with-margin">
                                        <input type="number" id="fs-table-header" value="${(margins.fontSizes || {}).tableHeader || 11}" oninput="updateReportPreview()" title="Header Font Size" class="font-input">
                                        <select id="ff-table-header" oninput="updateReportPreview()" class="font-family-select">${getFontOptions((margins.fontFamilies || {}).tableHeader || 'Khmer OS Muol Light')}</select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Table Body Font</label>
                                    <div class="input-with-margin">
                                        <input type="number" id="fs-table-body" value="${(margins.fontSizes || {}).tableBody || 11}" oninput="updateReportPreview()" title="Body Font Size" class="font-input">
                                        <select id="ff-table-body" oninput="updateReportPreview()" class="font-family-select">${getFontOptions((margins.fontFamilies || {}).tableBody || 'Khmer OS Battambang')}</select>
                                    </div>
                                </div>
                                ` : ''}
                            </div>
                            ${!isHonor ? `
                            <div class="form-row">
                                <div class="form-group">
                                     <label>Empty Rows</label>
                                     <input type="number" id="margin-min-rows" value="${margins.minRows || 0}" oninput="updateReportPreview()">
                                 </div>
                                <div class="form-group">
                                     <label>Header Fill</label>
                                     <input type="color" id="table-header-color" value="${margins.tableHeaderColor || '#f0f0f0'}" oninput="updateReportPreview()" style="height: 44px; padding: 2px; width: 100%; border-radius: 12px; border: 1px solid var(--border);">
                                 </div>
                             </div>
                             ` : ''}
                             ${!isHonor ? `
                             <div class="form-row">
                                <div class="form-group">
                                     <label>Table Border (px)</label>
                                     <input type="number" step="0.5" id="table-border-size" value="${margins.tableBorderSize !== undefined ? margins.tableBorderSize : 1.5}" oninput="updateReportPreview()">
                                 </div>
                             </div>
                             ` : `
                             <div class="form-row">
                                <div class="form-group">
                                     <label>Rounded Corners</label>
                                     <div class="checkbox-wrapper" style="margin-top: 10px;">
                                        <input type="checkbox" id="honor-box-round" ${margins.honorBoxRound ? 'checked' : ''} onchange="updateReportPreview()">
                                        <span>Apply rounding to student boxes</span>
                                     </div>
                                 </div>
                                 <div class="form-group">
                                     <label>Box Gap (px)</label>
                                     <input type="number" id="honor-box-gap" value="${margins.honorBoxGap !== undefined ? margins.honorBoxGap : 80}" oninput="updateReportPreview()">
                                 </div>
                                 <div class="form-group">
                                     <label>Box Width (px)</label>
                                     <input type="number" id="honor-box-width" value="${margins.honorBoxWidth !== undefined ? margins.honorBoxWidth : 300}" oninput="updateReportPreview()">
                                 </div>
                                 <div class="form-group">
                                     <label>Row Gap (px)</label>
                                     <input type="number" id="honor-row-gap" value="${margins.honorRowGap !== undefined ? margins.honorRowGap : 40}" oninput="updateReportPreview()">
                                 </div>
                             </div>
                             <div class="form-row">
                                <div class="form-group">
                                    <label>Student Name Font</label>
                                    <div class="input-with-margin">
                                        <input type="number" id="fs-honor-name" value="${(margins.fontSizes || {}).honorName || 18}" oninput="updateReportPreview()" title="Name Font Size" class="font-input">
                                        <select id="ff-honor-name" oninput="updateReportPreview()" class="font-family-select">${getFontOptions((margins.fontFamilies || {}).honorName || 'Khmer OS Muol Light')}</select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Rank Number Font</label>
                                    <div class="input-with-margin">
                                        <input type="number" id="fs-rank-number" value="${(margins.fontSizes || {}).rankNumber || 32}" oninput="updateReportPreview()" title="Rank Size" class="font-input">
                                        <select id="ff-rank-number" oninput="updateReportPreview()" class="font-family-select">${getFontOptions((margins.fontFamilies || {}).rankNumber || 'Khmer OS Muol Light')}</select>
                                    </div>
                                </div>
                             </div>
                             `}
                            </div>

                            ${!isHonor ? `
                            <div class="control-section">
                                <div class="section-title">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M8 7v10M12 7v10M16 7v10M2 12h20M2 5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5z"></path>
                                    </svg>
                                    Column Widths (px)
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label>No.</label>
                                        <input type="number" id="col-width-no" value="${(margins.colWidths || {}).no || 25}" oninput="updateReportPreview()">
                                    </div>
                                    <div class="form-group">
                                        <label>Name</label>
                                        <input type="number" id="col-width-name" value="${(margins.colWidths || {}).name || 120}" oninput="updateReportPreview()">
                                    </div>
                                    <div class="form-group">
                                        <label>Sex</label>
                                        <input type="number" id="col-width-sex" value="${(margins.colWidths || {}).sex || 30}" oninput="updateReportPreview()">
                                    </div>
                                    ${window.location.hash === '#/ranking-report' ? `
                                        <div class="form-group">
                                            <label>Average</label>
                                            <input type="number" id="col-width-score" value="${(margins.colWidths || {}).score || 45}" oninput="updateReportPreview()">
                                        </div>
                                    ` : `
                                        <div class="form-group">
                                            <label>ID</label>
                                            <input type="number" id="col-width-id" value="${(margins.colWidths || {}).id || 50}" oninput="updateReportPreview()">
                                        </div>
                                    `}
                                </div>
                                <div class="form-row">
                                    ${window.location.hash === '#/ranking-report' ? `
                                        <div class="form-group">
                                            <label>Rank</label>
                                            <input type="number" id="col-width-rank" value="${(margins.colWidths || {}).rank || 45}" oninput="updateReportPreview()">
                                        </div>
                                        <div class="form-group">
                                            <label>Grade</label>
                                            <input type="number" id="col-width-grade" value="${(margins.colWidths || {}).remarks || 45}" oninput="updateReportPreview()">
                                        </div>
                                    ` : `
                                        <div class="form-group">
                                            <label>DOB</label>
                                            <input type="number" id="col-width-dob" value="${(margins.colWidths || {}).dob || 75}" oninput="updateReportPreview()">
                                        </div>
                                        <div class="form-group">
                                            <label>Score</label>
                                            <input type="number" id="col-width-score" value="${(margins.colWidths || {}).score || 45}" oninput="updateReportPreview()">
                                        </div>
                                        <div class="form-group">
                                            <label>Remarks</label>
                                            <input type="number" id="col-width-remarks" value="${(margins.colWidths || {}).remarks || 45}" oninput="updateReportPreview()">
                                        </div>
                                    `}
                                </div>
                            </div>
                            ` : ''}


                    </div>
                </div>

                <div class="preview-panel">
                    <div class="preview-toolbar">
                        <div style="font-weight: 600; font-size: 14px; color: var(--text-secondary);">PREVIEW</div>
                        <div class="zoom-controls">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                                <circle cx="11" cy="11" r="8"></circle>
                                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                                <line x1="8" y1="11" x2="14" y2="11"></line>
                            </svg>
                            <button onclick="fitReportWidth()" class="btn-fit" title="Fit to Width">Fit</button>
                            <input type="range" id="preview-zoom" min="0.4" max="1.5" step="0.1" value="0.8" oninput="updatePreviewZoom(this.value)">
                            <span id="zoom-value" style="font-size: 11px; font-weight: 700; width: 35px;">80%</span>
                        </div>
                    </div>
                    <div class="preview-content-wrapper" id="preview-viewport" style="display: block; text-align: center;">
                        <iframe id="report-preview-iframe" scrolling="no" style="display: inline-block; border: none; background: white; width: 210mm; min-width: 210mm; height: 297mm; flex-shrink: 0; box-shadow: 0 0 0 1px rgba(0,0,0,0.1), 0 20px 50px rgba(0,0,0,0.3); transform-origin: top center; transition: transform 0.2s ease; pointer-events: none;"></iframe>
                    </div>
                </div>
            </div>
        </div>
    `;
    setTimeout(updateReportPreview, 100);
}

window.toggleReportControls = function () {
    const layout = document.querySelector('.report-split-layout');
    const body = document.getElementById('report-controls-body');
    const panel = document.getElementById('report-controls-panel');
    const iconOpen = document.getElementById('eye-icon-open');
    const iconClosed = document.getElementById('eye-icon-closed');

    if (body.style.display === 'none') {
        body.style.display = 'block';
        layout.style.gridTemplateColumns = '450px 1fr';
        panel.style.height = 'auto';
        iconOpen.style.display = 'block';
        iconClosed.style.display = 'none';
    } else {
        body.style.display = 'none';
        layout.style.gridTemplateColumns = 'auto 1fr';
        panel.style.height = 'min-content';
        iconOpen.style.display = 'none';
        iconClosed.style.display = 'block';
    }

    setTimeout(fitReportWidth, 50);
};

function fitReportWidth() {
    const viewport = document.getElementById('preview-viewport');
    if (!viewport) return;
    const availableWidth = viewport.clientWidth - 80;
    const paperWidthPx = 210 * 3.78;
    const fitZoom = Math.min(1.5, Math.max(0.4, (availableWidth / paperWidthPx)));

    const slider = document.getElementById('preview-zoom');
    if (slider) {
        slider.value = fitZoom.toFixed(1);
        updatePreviewZoom(fitZoom);
    }
}

function updatePreviewZoom(val) {
    const zoomValueEl = document.getElementById('zoom-value');
    const iframe = document.getElementById('report-preview-iframe');
    if (zoomValueEl) zoomValueEl.textContent = Math.round(val * 100) + '%';
    if (iframe) {
        iframe.style.transform = `scale(${val})`;
        window.currentReportZoom = val;
    }
}


function getRankingReportStyles(margins = {}) {
    return getHandwritingReportStyles(margins);
}


function getCurrentReportConfig() {
    const getVal = (id) => document.getElementById(id) ? document.getElementById(id).value : '';
    const getInt = (id, def = 0) => document.getElementById(id) ? (parseInt(document.getElementById(id).value) || def) : def;

    const school = {
        ministry: getVal('school-info-ministry'),
        location: getVal('school-info-location'),
        schoolName: getVal('school-info-name'),
        kingdomSlogan: getVal('school-info-kingdom'),
        nationSlogan: getVal('school-info-nation'),
        schoolYear: getVal('school-info-year'),
        reportMonth: getVal('school-info-report-month'),
        footerLocation: getVal('footer-location'),
        footerDate: getVal('footer-date'),
        footerDate2: getVal('footer-date2'),
        footerSeen: getVal('footer-seen'),
        footerDirector: getVal('footer-director'),
        footerSignature: getVal('footer-signature')
    };

    const fontFamilies = {
        ministry: getVal('ff-ministry'),
        location: getVal('ff-location'),
        schoolName: getVal('ff-school-name'),
        kingdom: getVal('ff-kingdom'),
        nation: getVal('ff-nation'),
        footerDate: getVal('ff-footer-date'),
        footerDate2: getVal('ff-footer-date2'),
        footerSeen: getVal('ff-footer-seen'),
        footerDirector: getVal('ff-footer-director'),
        footerSignature: getVal('ff-footer-signature'),
        title: getVal('ff-title'),
        subTitle: getVal('ff-subtitle'),
        tableHeader: getVal('ff-table-header'),
        tableBody: getVal('ff-table-body'),
        honorName: getVal('ff-honor-name') || 'Khmer OS Muol Light',
        rankNumber: getVal('ff-rank-number') || 'Khmer OS Muol Light'
    };

    const fontSizes = {
        ministry: getInt('fs-ministry', 14),
        location: getInt('fs-location', 14),
        schoolName: getInt('fs-school-name', 16),
        kingdom: getInt('fs-kingdom', 15),
        nation: getInt('fs-nation', 14),
        title: getInt('fs-title', 20),
        subTitle: getInt('fs-subtitle', 14),
        tableHeader: getInt('fs-table-header', 11),
        tableBody: getInt('fs-table-body', 11),
        footerDate: getInt('fs-footer-date', 12),
        footerDate2: getInt('fs-footer-date2', 12),
        footerSeen: getInt('fs-footer-seen', 13),
        footerDirector: getInt('fs-footer-director', 13),
        footerSignature: getInt('fs-footer-signature', 13),
        honorName: getInt('fs-honor-name', 18),
        rankNumber: getInt('fs-rank-number', 32)
    };

    const colWidths = {
        no: getInt('col-width-no', 25),
        name: getInt('col-width-name', 120),
        sex: getInt('col-width-sex', 30)
    };

    if (window.location.hash === '#/ranking-report') {
        colWidths.score = getInt('col-width-score', 45);
        colWidths.rank = getInt('col-width-rank', 45);
        colWidths.remarks = getInt('col-width-grade', 45);
    } else {
        colWidths.id = getInt('col-width-id', 50);
        colWidths.dob = getInt('col-width-dob', 75);
        colWidths.score = getInt('col-width-score', 45);
        colWidths.remarks = getInt('col-width-remarks', 45);
    }

    const margins = {
        headerTop: getInt('margin-header-top'),
        titleSpacing: getInt('margin-title'),
        subtitleSpacing: getInt('margin-subtitle'),
        tableTop: getInt('margin-table-top'),
        footerTop: getInt('margin-footer-top'),
        minRows: getInt('margin-min-rows'),
        pageLeft: getInt('margin-page-left', 38),
        pageRight: getInt('margin-page-right', 38),
        tableHeaderColor: getVal('table-header-color') || '#f0f0f0',
        tableBorderSize: parseFloat(getVal('table-border-size')) || 1.5,
        honorBoxRound: document.getElementById('honor-box-round') ? document.getElementById('honor-box-round').checked : false,
        honorBoxGap: getInt('honor-box-gap', 80),
        honorBoxWidth: getInt('honor-box-width', 300),
        honorRowGap: getInt('honor-row-gap', 40),
        fontSizes, fontFamilies, colWidths,
        ministrySpacing: getInt('margin-ministry'),
        locationSpacing: getInt('margin-location'),
        schoolNameSpacing: getInt('margin-school-name'),
        kingdomSpacing: getInt('margin-kingdom'),
        nationSpacing: getInt('margin-nation'),
        ministryIndent: getInt('indent-ministry'),
        locationIndent: getInt('indent-location'),
        schoolNameIndent: getInt('indent-school-name'),
        kingdomIndent: getInt('indent-kingdom'),
        nationIndent: getInt('indent-nation'),
        footerDateIndent: getInt('indent-footer-date'),
        footerDate2Indent: getInt('indent-footer-date2'),
        footerSeenIndent: getInt('indent-footer-seen'),
        footerDirectorIndent: getInt('indent-footer-director'),
        footerSignatureIndent: getInt('indent-footer-signature')
    };

    return { school, margins };
}

function updateReportPreview() {
    const iframe = document.getElementById('report-preview-iframe');
    if (!iframe) return;

    const { school, margins } = getCurrentReportConfig();
    const grade = document.getElementById('report-grade') ? document.getElementById('report-grade').value : '';
    const period = document.getElementById('report-period') ? document.getElementById('report-period').value : '';

    const isRanking = window.location.hash === '#/ranking-report';
    const isHonor = window.location.hash === '#/honor-roll';

    let reportHTML = '';
    if (isRanking || isHonor) {
        const rGrade = grade || (isHonor ? localStorage.getItem('temp_honor_grade') : localStorage.getItem('temp_ranking_grade')) || '';
        const rPeriod = period || (isHonor ? localStorage.getItem('temp_honor_period') : localStorage.getItem('temp_ranking_period')) || '';
        
        // Sync back to temp storage for consistency in printing/exporting
        if (isHonor) {
            if (rGrade) localStorage.setItem('temp_honor_grade', rGrade);
            if (rPeriod) localStorage.setItem('temp_honor_period', rPeriod);
        } else {
            if (rGrade) localStorage.setItem('temp_ranking_grade', rGrade);
            if (rPeriod) localStorage.setItem('temp_ranking_period', rPeriod);
        }

        const savedCalc = localStorage.getItem(`calc_${rGrade}_${rPeriod}`);
        let rankingResults = [];
        if (savedCalc) {
            const parsed = JSON.parse(savedCalc);
            const coeff = parsed.coeff || 10;
            const subjects = getSubjects();
            const rankingStudents = getFilteredStudents().filter(s => !rGrade || (s.classroom && s.classroom.startsWith(rGrade)));

            rankingResults = rankingStudents.map(s => {
                let total = 0;
                subjects.forEach(sub => {
                    const scores = getScoresByPeriodAndSubject(rPeriod, sub.id);
                    const scoreObj = scores.find(sc => sc.studentId === s.id);
                    const scoreVal = (scoreObj && scoreObj.score !== '' && scoreObj.score !== null) ? parseFloat(scoreObj.score) : 0;
                    total += scoreVal;
                });
                const average = total / coeff;
                return {
                    id: s.stuId, dbId: s.id, name: `${s.stuKhmerLastName} ${s.stuKhmerFirstName}`,
                    gender: s.gender, classroom: s.classroom, total: total.toFixed(2),
                    average: average.toFixed(2), avgNum: average, grade: calculateGrade(average, 50)
                };
            });
            rankingResults.sort((a, b) => b.avgNum - a.avgNum);
            rankingResults.forEach((r, i) => r.rank = i + 1);
        }

        if (isHonor) {
            reportHTML = getHonorRollHTML(rankingResults, school, margins, rGrade, rPeriod);
        } else {
            reportHTML = getRankingReportHTML(rankingResults, school, margins, rGrade, rPeriod);
        }
    } else {
        const students = getFilteredStudents()
            .filter(s => !grade || (s.classroom && s.classroom.startsWith(grade)))
            .sort((a, b) => (a.stuKhmerLastName + a.stuKhmerFirstName).localeCompare(b.stuKhmerLastName + b.stuKhmerFirstName));
        reportHTML = getHandwritingReportHTML(students, school, margins, grade);
    }

    const doc = iframe.contentDocument || iframe.contentWindow.document;
    doc.open();
    doc.write(`
        <html style="width: 210mm;">
        <head>
            <style>
                * { box-sizing: border-box; }
                html, body { margin: 0; padding: 0; width: 210mm; background: white; }
                .report-print-body {
                    padding-top: 10mm; padding-bottom: 10mm;
                    padding-left: ${margins.pageLeft !== undefined ? margins.pageLeft : 38}px;
                    padding-right: ${margins.pageRight !== undefined ? margins.pageRight : 38}px;
                    min-height: 297mm; width: 100%; display: flex; flex-direction: column;
                }
                ${isHonor ? getHonorRollStyles(margins) : (isRanking ? getHandwritingReportStyles(margins) : getHandwritingReportStyles(margins))}
            </style>
        </head>
        <body>${reportHTML}</body>
        </html>
    `);
    doc.close();

    setTimeout(() => {
        const bodyHeight = doc.body.scrollHeight;
        iframe.style.height = Math.max(297 * 3.78, bodyHeight) + 'px';
        if (window.currentReportZoom) iframe.style.transform = `scale(${window.currentReportZoom})`;
    }, 50);
}

function saveSchoolInfo(shouldPrint = true) {
    const { school, margins } = getCurrentReportConfig();
    const settings = getSettings();
    const schoolKey = window.location.hash === '#/ranking-report' ? 'rankingSchoolInfo' : (window.location.hash === '#/honor-roll' ? 'honorSchoolInfo' : 'reportSchoolInfo');
    const marginKey = window.location.hash === '#/ranking-report' ? 'rankingMargins' : (window.location.hash === '#/honor-roll' ? 'honorMargins' : 'reportMargins');

    settings[schoolKey] = school;
    settings.schoolInfo = school;
    settings[marginKey] = margins;
    saveSettings(settings);

    if (shouldPrint) {
        if (window.location.hash === '#/ranking-report') printRankingReport();
        else if (window.location.hash === '#/honor-roll') printHonorRoll();
        else printScoreSheet();
    } else {
        showAlert('Settings saved successfully!', 'success');
    }
}


function printRankingReport() {
    const rGrade = localStorage.getItem('temp_ranking_grade') || '';
    const rPeriod = localStorage.getItem('temp_ranking_period') || '';
    if (!rGrade || !rPeriod) { showAlert('No ranking data found.', 'error'); return; }

    const savedCalc = localStorage.getItem(`calc_${rGrade}_${rPeriod}`);
    if (!savedCalc) { showAlert('Setup the score first', 'error'); return; }

    const settings = getSettings();
    const schoolKey = 'rankingSchoolInfo';
    const school = settings[schoolKey] || settings.schoolInfo || {};
    const marginKey = 'rankingMargins';
    const margins = settings[marginKey] || { headerTop: 0, tableTop: 20, footerTop: 30, titleSpacing: 10 };
    const parsed = JSON.parse(savedCalc);
    const coeff = parsed.coeff || 10;
    const subjects = getSubjects();
    const students = getFilteredStudents().filter(s => s.classroom && s.classroom.startsWith(rGrade));

    const results = students.map(s => {
        let total = 0;
        subjects.forEach(sub => {
            const scores = getScoresByPeriodAndSubject(rPeriod, sub.id);
            const sc = scores.find(x => x.studentId === s.id);
            total += (sc && sc.score !== '' && sc.score !== null) ? parseFloat(sc.score) : 0;
        });
        const avg = total / coeff;
        return { name: `${s.stuKhmerLastName} ${s.stuKhmerFirstName}`, gender: s.gender, classroom: s.classroom, average: avg.toFixed(2), avgNum: avg, grade: calculateGrade(avg, 50) };
    });
    results.sort((a, b) => b.avgNum - a.avgNum);
    results.forEach((r, i) => r.rank = i + 1);

    let iframe = document.getElementById('print-iframe');
    if (!iframe) { iframe = document.createElement('iframe'); iframe.id = 'print-iframe'; iframe.style.cssText = 'position:absolute;width:0;height:0;border:none;'; document.body.appendChild(iframe); }
    const doc = iframe.contentWindow.document;
    doc.open();
    doc.write(`<html><head><title>Ranking Report</title><style>@page{size:A4 portrait;margin:0}body{margin:0;padding:0;-webkit-print-color-adjust:exact}.report-print-body{padding-top:10mm;padding-bottom:10mm;padding-left:${margins.pageLeft || 38}px;padding-right:${margins.pageRight || 38}px;width:100%;height:296mm;overflow:hidden;display:flex;flex-direction:column;box-sizing:border-box}${getHandwritingReportStyles(margins)}</style></head><body>${getRankingReportHTML(results, school, margins, rGrade, rPeriod)}<script>window.onload=function(){setTimeout(()=>window.print(),500)}<\/script></body></html>`);
    doc.close();
}

function printHonorRoll() {
    const rGrade = localStorage.getItem('temp_honor_grade') || '';
    const rPeriod = localStorage.getItem('temp_honor_period') || '';
    if (!rGrade || !rPeriod) { showAlert('No honor roll data found.', 'error'); return; }

    const savedCalc = localStorage.getItem(`calc_${rGrade}_${rPeriod}`);
    if (!savedCalc) { showAlert('Setup the score first', 'error'); return; }

    const settings = getSettings();
    const schoolKey = 'honorSchoolInfo';
    const school = settings[schoolKey] || settings.schoolInfo || {};
    const marginKey = 'honorMargins';
    const margins = settings[marginKey] || { headerTop: 0, tableTop: 20, footerTop: 30, titleSpacing: 10 };
    const parsed = JSON.parse(savedCalc);
    const coeff = parsed.coeff || 10;
    const subjects = getSubjects();
    const students = getFilteredStudents().filter(s => s.classroom && s.classroom.startsWith(rGrade));

    const results = students.map(s => {
        let total = 0;
        subjects.forEach(sub => {
            const scores = getScoresByPeriodAndSubject(rPeriod, sub.id);
            const sc = scores.find(x => x.studentId === s.id);
            total += (sc && sc.score !== '' && sc.score !== null) ? parseFloat(sc.score) : 0;
        });
        const avg = total / coeff;
        return { name: `${s.stuKhmerLastName} ${s.stuKhmerFirstName}`, gender: s.gender, classroom: s.classroom, average: avg.toFixed(2), avgNum: avg, grade: calculateGrade(avg, 50) };
    });
    results.sort((a, b) => b.avgNum - a.avgNum);
    results.forEach((r, i) => r.rank = i + 1);

    let iframe = document.getElementById('print-iframe');
    if (!iframe) { iframe = document.createElement('iframe'); iframe.id = 'print-iframe'; iframe.style.cssText = 'position:absolute;width:0;height:0;border:none;'; document.body.appendChild(iframe); }
    const doc = iframe.contentWindow.document;
    doc.open();
    doc.write(`<html><head><title>Honor Roll</title><style>@page{size:A4 portrait;margin:0}body{margin:0;padding:0;-webkit-print-color-adjust:exact}${getHonorRollStyles(margins)}</style></head><body>${getHonorRollHTML(results, school, margins, rGrade, rPeriod)}<script>window.onload=function(){setTimeout(()=>window.print(),500)}<\/script></body></html>`);
    doc.close();
}

window.renderRankingReportUI = renderHandwritingReportUI;

function exportHandwritingReportToPDF() {
    saveSchoolInfo(false);

    const { school, margins } = getCurrentReportConfig();
    const gradeSelect = document.getElementById('report-grade');
    const grade = gradeSelect ? gradeSelect.value : (localStorage.getItem('temp_ranking_grade') || '');

    const students = getFilteredStudents()
        .filter(s => !grade || (s.classroom && s.classroom.startsWith(grade)))
        .sort((a, b) => (a.stuKhmerLastName + a.stuKhmerFirstName).localeCompare(b.stuKhmerLastName + b.stuKhmerFirstName));

    if (students.length === 0 && window.location.hash !== '#/ranking-report') {
        showAlert('No students found for this grade.', 'error');
        return;
    }

    if (typeof html2pdf === 'undefined') {
        showAlert('PDF Library is still loading, please try again in a few seconds.', 'error');
        return;
    }

    const container = document.createElement('div');
    const isRanking = window.location.hash === '#/ranking-report';
    const isHonor = window.location.hash === '#/honor-roll';

    if (isRanking || isHonor) {
        const rGrade = isHonor ? (localStorage.getItem('temp_honor_grade') || grade) : (localStorage.getItem('temp_ranking_grade') || grade);
        const rPeriod = isHonor ? (localStorage.getItem('temp_honor_period') || '') : (localStorage.getItem('temp_ranking_period') || '');
        const savedCalc = localStorage.getItem(`calc_${rGrade}_${rPeriod}`);
        let rankingResults = [];
        if (savedCalc) {
            const parsed = JSON.parse(savedCalc);
            const coeff = parsed.coeff || 10;
            const subjects = getSubjects();
            const filteredStudents = getFilteredStudents().filter(s => !rGrade || (s.classroom && s.classroom.startsWith(rGrade)));

            rankingResults = filteredStudents.map(s => {
                let total = 0;
                subjects.forEach(sub => {
                    const scores = getScoresByPeriodAndSubject(rPeriod, sub.id);
                    const scoreObj = scores.find(sc => sc.studentId === s.id);
                    const scoreVal = (scoreObj && scoreObj.score !== '' && scoreObj.score !== null) ? parseFloat(scoreObj.score) : 0;
                    total += scoreVal;
                });
                const average = total / coeff;
                return {
                    name: `${s.stuKhmerLastName} ${s.stuKhmerFirstName}`,
                    gender: s.gender,
                    classroom: s.classroom,
                    total: total.toFixed(2),
                    average: average.toFixed(2),
                    avgNum: average,
                    grade: calculateGrade(average, 50)
                };
            });
            rankingResults.sort((a, b) => b.avgNum - a.avgNum);
            rankingResults.forEach((r, i) => r.rank = i + 1);
        }
        if (isHonor) {
            container.innerHTML = getHonorRollHTML(rankingResults, school, margins, rGrade, rPeriod);
        } else {
            container.innerHTML = getRankingReportHTML(rankingResults, school, margins, rGrade, rPeriod);
        }
    } else {
        container.innerHTML = getHandwritingReportHTML(students, school, margins, grade);
    }

    const style = document.createElement('style');
    if (isHonor) {
        style.innerHTML = `
            .report-print-body {
                width: 210mm !important;
                height: 296mm !important;
                overflow: hidden !important;
                box-sizing: border-box !important;
                background: white !important;
            }
            ${getHonorRollStyles(margins)}
        `;
    } else if (isRanking) {
        style.innerHTML = `
            .report-print-body {
                width: 210mm !important;
                height: 296mm !important;
                overflow: hidden !important;
                box-sizing: border-box !important;
                background: white !important;
                padding: 10mm !important;
                padding-left: ${margins.pageLeft !== undefined ? margins.pageLeft : 38}px !important;
                padding-right: ${margins.pageRight !== undefined ? margins.pageRight : 38}px !important;
            }
            ${getRankingReportStyles(margins)}
        `;
    } else {
        style.innerHTML = `
            .report-print-body {
                padding-top: 10mm !important;
                padding-bottom: 10mm !important;
                padding-left: ${margins.pageLeft !== undefined ? margins.pageLeft : 38}px !important;
                padding-right: ${margins.pageRight !== undefined ? margins.pageRight : 38}px !important;
                width: 210mm !important;
                height: 296mm !important;
                overflow: hidden !important;
                box-sizing: border-box !important;
                background: white !important;
            }
            ${getHandwritingReportStyles(margins)}
        `;
    }
    container.appendChild(style);

    container.style.position = 'absolute';
    container.style.left = '-9999px';
    container.style.top = '0';
    document.body.appendChild(container);

    let finalClassroom = grade;
    if (!finalClassroom) {
        const currentUser = typeof getCurrentUser === 'function' ? getCurrentUser() : null;
        if (currentUser && currentUser.role === 'Teacher') {
            const teachers = typeof getTeachers === 'function' ? getTeachers() : [];
            const myTeacher = teachers.find(t => (t.tengFirstName + ' ' + t.tengLastName) === currentUser.name);
            if (myTeacher && myTeacher.classroom) {
                finalClassroom = myTeacher.classroom;
            }
        }
    }
    if (!finalClassroom) {
        const uniqueClassrooms = [...new Set(students.map(s => s.classroom).filter(Boolean))];
        if (uniqueClassrooms.length === 1) {
            finalClassroom = uniqueClassrooms[0];
        } else {
            finalClassroom = 'All';
        }
    }

    let pdfFilename = `Student_Score_List Classroom - ${finalClassroom}.pdf`;
    if (window.location.hash === '#/honor-roll') {
        const rPeriod = localStorage.getItem('temp_honor_period') || '';
        pdfFilename = `Top 5 of month ${rPeriod} Classroom - ${finalClassroom}.pdf`;
    } else if (window.location.hash === '#/ranking-report') {
        const rPeriod = localStorage.getItem('temp_ranking_period') || '';
        pdfFilename = `Ranking_Report_${rPeriod}_Classroom_${finalClassroom}.pdf`;
    }

    const opt = {
        margin: 0,
        filename: pdfFilename,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true, logging: false, letterRendering: true },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
        pagebreak: { mode: ['avoid-all', 'css', 'legacy'] }
    };

    const targetElement = container.querySelector('.report-print-body');
    if (targetElement) {
        targetElement.prepend(style);
    }

    showAlert('Generating PDF, please wait...', 'info');

    html2pdf().set(opt).from(targetElement || container).save().then(() => {
        document.body.removeChild(container);
        showAlert('PDF exported successfully!', 'success');
    }).catch(err => {
        console.error('PDF export error:', err);
        document.body.removeChild(container);
        showAlert('Error exporting PDF.', 'error');
    });
}

window.initHonorRoll = function () {
    const grade = document.getElementById('honor-grade').value;
    const period = document.getElementById('honor-month').value;
    if (!grade || !period) {
        showAlert('Please select Grade and Month first.', 'info');
        return;
    }

    const savedCalc = localStorage.getItem(`calc_${grade}_${period}`);
    if (!savedCalc) {
        showAlert('Setup the score first', 'error');
        return;
    }

    localStorage.setItem('temp_honor_grade', grade);
    localStorage.setItem('temp_honor_period', period);

    navigateTo('#/honor-roll');
};

window.syncAndInitHonor = function () {
    const grade = document.getElementById('ranking-grade').value;
    const period = document.getElementById('ranking-month').value;
    if (!grade || !period) {
        showAlert('Please select Grade and Month first.', 'info');
        return;
    }

    const savedCalc = localStorage.getItem(`calc_${grade}_${period}`);
    if (!savedCalc) {
        showAlert('Setup the score first', 'error');
        return;
    }

    localStorage.setItem('temp_honor_grade', grade);
    localStorage.setItem('temp_honor_period', period);

    navigateTo('#/honor-roll');
};

window.renderHonorRollUI = function () {
    window.renderHandwritingReportUI();
};

function getHonorRollHTML(results, school, margins, grade, period) {
    const fs = margins.fontSizes || {};
    const ff = margins.fontFamilies || {};

    const top5 = results.slice(0, 5);

    while (top5.length < 5) {
        top5.push({ name: '', gender: '', classroom: '', average: '', rank: top5.length + 1 });
    }

    const khmerNumbers = ['០', '១', '២', '៣', '៤', '៥'];

    const renderStudentBox = (student, index) => {
        const rank = index + 1;
        const khRank = khmerNumbers[rank];

        return `
            <div class="honor-box rank-${rank}">
                <div class="rank-number">${khRank}</div>
                <div class="student-name-frame">
                    <div class="student-name">${student.name || '........................'}</div>
                </div>
            </div>
        `;
    };

    return `
        <style>${getHonorRollStyles(margins)}</style>
        <div class="report-print-body honor-roll-page">
            <div class="honor-roll-border">
                <div class="official-header" style="margin-top: ${margins.headerTop}px; margin-bottom: 20px; display: flex; justify-content: space-between; width: 100%; align-items: flex-start;">
                    <div class="ministry-info" style="text-align: center;">
                        <div class="school-ministry" style="margin-top: ${margins.ministrySpacing}px; margin-left: ${margins.ministryIndent || 0}px;">${school.ministry || 'ក្រសួងអប់រំ យុវជន និងកីឡា'}</div>
                        <div class="school-location" style="margin-top: ${margins.locationSpacing}px; margin-left: ${margins.locationIndent || 0}px;">${school.location || 'មន្ទីរអប់រំ យុវជន និងកីឡា'}</div>
                        <div class="school-name" style="margin-top: ${margins.schoolNameSpacing}px; margin-left: ${margins.schoolNameIndent || 0}px;">${school.schoolName || 'សាលារៀន................'}</div>
                    </div>
                    <div class="kingdom-info" style="text-align: center;">
                        <div class="kingdom-slogan" style="margin-top: ${margins.kingdomSpacing}px; margin-left: ${margins.kingdomIndent || 0}px;">${school.kingdomSlogan || 'ព្រះរាជាណាចក្រកម្ពុជា'}</div>
                        <div class="nation-slogan" style="margin-top: ${margins.nationSpacing}px; margin-left: ${margins.nationIndent || 0}px;">${school.nationSlogan || 'ជាតិ សាសនា ព្រះមហាក្សត្រ'}</div>
                    </div>
                </div>

                <div class="honor-title-section" style="margin-top: ${margins.titleSpacing || 0}px; text-align: center; margin-bottom: 10px;">
                    <h1 class="honor-main-title">តារាងកិត្តិយស</h1>
                    <h2 class="honor-sub-title">
                        ${getPeriodName(period)} 
                        <span style="font-family: '${ff.subTitle || 'Khmer OS Battambang'}'; margin-left: 10px;">
                            ថ្នាក់ទី: ${results[0]?.classroom || grade} &nbsp;&nbsp; ឆ្នាំសិក្សា: ${school.schoolYear || '2024-2025'}
                        </span>
                    </h2>
                </div>

                <div class="honor-students-container">
                    <div class="honor-row center">
                        ${renderStudentBox(top5[0], 0)}
                    </div>

                    <div class="honor-row split">
                        ${renderStudentBox(top5[1], 1)}
                        ${renderStudentBox(top5[2], 2)}
                    </div>

                    <div class="honor-row split">
                        ${renderStudentBox(top5[3], 3)}
                        ${renderStudentBox(top5[4], 4)}
                    </div>
                </div>

                <div class="report-footer" style="margin-top: auto; padding-bottom: 40px; display: flex; justify-content: space-between; align-items: flex-start; padding-left: 40px; padding-right: 40px;">
                    <div class="signature-box" style="margin-left: ${margins.footerSeenIndent || 0}px; margin-top: 50px; text-align: center;">
                        <div class="footer-seen" style="font-weight: normal;">${school.footerSeen || 'បានឃើញ និងឯកភាព'}</div>
                        <div class="footer-director" style="margin-top: 5px; font-weight: normal;">${school.footerDirector || 'នាយក'}</div>
                        <div class="signature-line" style="margin-top: 60px;"></div>
                    </div>
                    <div class="signature-box" style="margin-left: ${margins.footerSignatureIndent || 0}px; text-align: center;">
                        ${school.footerDate2 ? `<div class="footer-date2" style="font-style: italic; font-weight: normal; margin-bottom: 5px; margin-left: ${margins.footerDate2Indent || 0}px;">${school.footerDate2}</div>` : ''}
                        <div class="footer-date" style="font-style: italic; font-weight: normal; margin-left: ${margins.footerDateIndent || 0}px;">${school.footerLocation ? school.footerLocation + ', ' : ''}${school.footerDate || 'ថ្ងៃទី.......ខែ.......ឆ្នាំ២០២...'}</div>
                        <div class="footer-signature" style="margin-top: 5px; font-weight: normal;">${school.footerSignature || 'គ្រូប្រចាំថ្នាក់'}</div>
                        <div class="signature-line" style="margin-top: 60px;"></div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function getHonorRollStyles(margins) {
    const fs = margins.fontSizes || {};
    const ff = margins.fontFamilies || {};
    return `
        * { box-sizing: border-box; }
        .honor-roll-page {
            background: white;
            padding-top: 10mm !important;
            padding-bottom: 10mm !important;
            padding-left: ${margins.pageLeft !== undefined ? margins.pageLeft : 38}px !important;
            padding-right: ${margins.pageRight !== undefined ? margins.pageRight : 38}px !important;
            height: 296mm;
            position: relative;
            box-sizing: border-box;
        }
        .honor-roll-border {
            height: 100%;
            width: 100%;
            padding: 10mm;
            display: flex;
            flex-direction: column;
            position: relative;
        }
        .honor-title-section {
            text-align: center;
            margin: 20px 0;
        }
        .honor-main-title {
            font-family: '${ff.title || 'Khmer OS Muol Light'}' !important;
            font-size: ${fs.title || 36}px !important;
            color: #d32f2f;
            margin: 0 0 10px 0 !important;
            line-height: 1.3 !important;
        }
        .honor-sub-title {
            font-family: '${ff.subTitle || 'Khmer OS Muol Light'}' !important;
            font-size: ${fs.subTitle || 24}px !important;
            margin-top: ${margins.subtitleSpacing !== undefined ? margins.subtitleSpacing : 25}px !important;
            margin-bottom: 0 !important;
            line-height: 1.2 !important;
            color: #1976d2 !important;
            text-align: center;
            width: 100%;
        }
        .honor-students-container {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: space-around;
            margin-top: 10px;
            margin-bottom: 20px;
        }
        .honor-students-container > .honor-row:not(:last-child) {
            margin-bottom: ${margins.honorRowGap !== undefined ? margins.honorRowGap : 40}px;
        }
        .honor-row {
            display: flex;
            justify-content: center;
            align-items: center;
            position: relative;
        }
        .honor-row.split {
            justify-content: center;
        }
        .honor-row.split > .honor-box:not(:last-child) {
            margin-right: ${margins.honorBoxGap !== undefined ? margins.honorBoxGap : 80}px;
        }
        .honor-box {
            position: relative;
            text-align: center;
            width: ${margins.honorBoxWidth !== undefined ? margins.honorBoxWidth : 300}px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .rank-number {
            font-family: '${(ff.rankNumber || 'Khmer OS Muol Light')}' !important;
            font-size: ${(fs.rankNumber || 32)}px !important;
            color: #d32f2f;
            margin-bottom: 12px !important;
            line-height: 1.1 !important;
            display: block;
            width: 100%;
            text-align: center;
        }
        .student-name-frame {
            border: 3px solid #FFD700;
            border-radius: ${margins.honorBoxRound ? '50px' : '0'};
            padding: 5px 15px;
            background: linear-gradient(135deg, #ffffff 0%, #fff9e6 100%);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            position: relative;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            text-align: center;
            box-sizing: border-box;
            overflow: hidden;
        }
        
        .student-name {
            font-family: '${(ff.honorName || 'Khmer OS Muol Light')}';
            font-size: ${(fs.honorName || 18)}px;
            color: #1a237e;
            white-space: nowrap;
            font-weight: normal;
            line-height: 1.2;
            margin: 0;
            padding: 0;
        }
        
        .rank-1 .student-name {
            font-size: ${((fs.honorName || 18) + 4)}px;
        }

        .school-ministry { font-size: ${fs.ministry || 14}px !important; font-family: '${ff.ministry || 'Khmer OS Battambang'}' !important; }
        .school-location { font-size: ${fs.location || 14}px !important; font-family: '${ff.location || 'Khmer OS Battambang'}' !important; }
        .school-name { font-size: ${fs.schoolName || 16}px !important; font-family: '${ff.schoolName || 'Khmer OS Muol Light'}' !important; }
        .kingdom-slogan { font-size: ${fs.kingdom || 15}px !important; font-family: '${ff.kingdom || 'Khmer OS Muol Light'}' !important; }
        .nation-slogan { font-size: ${fs.nation || 14}px !important; font-family: '${ff.nation || 'Khmer OS Muol Light'}' !important; }
        .footer-seen { font-size: ${fs.footerSeen || 13}px !important; font-family: '${ff.footerSeen || 'Khmer OS Muol Light'}' !important; }
        .footer-director { font-size: ${fs.footerDirector || 13}px !important; font-family: '${ff.footerDirector || 'Khmer OS Muol Light'}' !important; }
        .footer-date { font-size: ${fs.footerDate || 12}px !important; font-family: '${ff.footerDate || 'Khmer OS Battambang'}' !important; }
        .footer-date2 { font-size: ${fs.footerDate2 || 12}px !important; font-family: '${ff.footerDate2 || 'Khmer OS Battambang'}' !important; }
        .footer-signature { font-size: ${fs.footerSignature || 13}px !important; font-family: '${ff.footerSignature || 'Khmer OS Muol Light'}' !important; }
    `;
}

window.renderReportsList = renderReportsList;
window.renderHandwritingReportUI = renderHandwritingReportUI;
window.renderRankingReportUI = renderHandwritingReportUI;
window.renderHonorRollUI = renderHandwritingReportUI;
