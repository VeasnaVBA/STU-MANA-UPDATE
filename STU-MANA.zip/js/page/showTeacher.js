/* js/page/showTeacher.js */
function renderShowTeacher() {
    renderTeachersList(); // Render background

    const params = getUrlParams();
    const teacherId = params.id;

    if (!teacherId) {
        openModal('<div style="padding:24px;text-align:center;">No teacher selected.</div>');
        return;
    }

    const teacher = getTeacherById(teacherId);
    if (!teacher) {
        openModal('<div style="padding:24px;text-align:center;">Teacher not found.</div>');
        return;
    }

    const html = `
        <div style="padding: 24px; max-width: 520px; margin: 0 auto;">
            <!-- Profile Card -->
            <div style="background: var(--bg-card); border-radius: 32px; box-shadow: 0 10px 40px rgba(0,0,0,0.15); overflow: hidden; font-family: var(--font-family); border: 1px solid var(--border);">
                
                <!-- Top Section (Header) -->
                <div style="padding: 24px; display: flex; gap: 20px; align-items: flex-start;">
                    <!-- Photo -->
                    <div style="width: 100px; height: 120px; border-radius: 20px; overflow: hidden; background: #EEF2FF; border: 1px solid #E0E7FF; flex-shrink: 0; display: flex; align-items: center; justify-content: center;">
                        ${renderAvatar(teacher.photo, '👨‍🏫', { fontSize: '48px' })}
                    </div>

                    <!-- Info -->
                    <div style="flex: 1;">
                        <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 8px;">
                            <span style="width: 8px; height: 8px; border-radius: 50%; background: #4ADE80; display: inline-block;"></span>
                            <span style="font-size: 12px; font-weight: 600; color: var(--text-secondary);">កំពុងបង្រៀន</span>
                        </div>
                        
                        <h2 style="margin: 0; font-size: 20px; font-weight: 800; color: var(--text-primary); line-height: 1.2;">
                            ${teacher.tkhLastName || ''} ${teacher.tkhFirstName || ''}
                        </h2>
                        <div style="font-size: 14px; color: var(--text-secondary); margin-top: 2px;">
                            ${teacher.tengFirstName || ''} ${teacher.tengLastName || ''}
                        </div>
                        
                        <div style="margin-top: 12px; display: flex; gap: 10px; align-items: center;">
                            <span style="background: #EEF2FF; padding: 3px 10px; border-radius: 100px; font-size: 11px; font-weight: 700; color: #4F46E5;">
                                ID: #${teacher.teacherId || teacher.id}
                            </span>
                        </div>
                    </div>
                </div>

                <!-- School Bar -->
                <div style="margin: 0 24px; padding: 12px 16px; background: var(--bg-body); border-radius: 14px; display: flex; align-items: center; gap: 10px; border: 1px solid var(--border);">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--text-secondary)" stroke-width="2.5">
                        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                        <polyline points="9 22 9 12 15 12 15 22"></polyline>
                    </svg>
                    <div style="flex: 1; font-size: 13px; color: var(--text-primary); font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                        សាលារៀន: ${teacher.school || 'មិនមានព័ត៌មាន'}
                    </div>
                </div>

                <!-- Stats Grid -->
                <div style="padding: 24px; display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px;">
                    <div style="padding: 12px 8px; border: 1px solid var(--border); border-radius: 16px; text-align: center; background: var(--bg-card);">
                        <div style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; font-weight: 700; margin-bottom: 2px;">ភេទ</div>
                        <div style="font-size: 13px; font-weight: 700; color: var(--text-primary);">${['Male', 'male', 'ប្រុស', 'ប', 'M', 'm'].includes(teacher.gender) ? 'ប្រុស' : (['Female', 'female', 'ស្រី', 'ស', 'F', 'f'].includes(teacher.gender) ? 'ស្រី' : teacher.gender || '-')}</div>
                    </div>
                    <div style="padding: 12px 8px; border: 1px solid var(--border); border-radius: 16px; text-align: center; background: var(--bg-card);">
                        <div style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; font-weight: 700; margin-bottom: 2px;">ថ្នាក់</div>
                        <div style="font-size: 13px; font-weight: 700; color: var(--text-primary);">${teacher.classroom || '-'}</div>
                    </div>
                    <div style="padding: 12px 8px; border: 1px solid var(--border); border-radius: 16px; text-align: center; background: var(--bg-card);">
                        <div style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; font-weight: 700; margin-bottom: 2px;">អាយុ</div>
                        <div style="font-size: 13px; font-weight: 700; color: var(--text-primary);">${teacher.age || '-'} ឆ្នាំ</div>
                    </div>
                    <div style="padding: 12px 8px; border: 1px solid var(--border); border-radius: 16px; text-align: center; background: var(--bg-card);">
                        <div style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; font-weight: 700; margin-bottom: 2px;">ទូរស័ព្ទ</div>
                        <div style="font-size: 13px; font-weight: 700; color: var(--text-primary);">${teacher.phoneNumber ? teacher.phoneNumber.slice(-4) : '-'}</div>
                    </div>
                </div>

                <!-- Detailed Info -->
                <div style="padding: 0 24px 24px;">
                    <div style="font-size: 11px; font-weight: 800; text-transform: uppercase; color: #4F46E5; margin-bottom: 8px; display: flex; align-items: center; gap: 8px;">
                        <span>ព័ត៌មានបន្ថែម</span>
                        <div style="flex: 1; height: 1px; background: var(--border);"></div>
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                        <div style="display: flex; justify-content: space-between; border-bottom: 1px dashed var(--border); padding-bottom: 6px;">
                            <span style="color: var(--text-secondary); font-size: 12px;">ថ្ងៃកំណើត:</span>
                            <span style="font-weight: 600; color: var(--text-primary); font-size: 12px;">${teacher.dateOfBirth || '-'}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; border-bottom: 1px dashed var(--border); padding-bottom: 6px;">
                            <span style="color: var(--text-secondary); font-size: 12px;">ជំនាញ:</span>
                            <span style="font-weight: 600; color: var(--text-primary); font-size: 12px;">គ្រូបង្រៀន</span>
                        </div>
                    </div>
                </div>

                <!-- Actions -->
                <div style="padding: 16px 24px; background: var(--bg-body); border-top: 1px solid var(--border); display: flex; justify-content: flex-end; gap: 10px;">
                    <button class="btn btn-secondary" onclick="closeModal()" style="border-radius: 10px; padding: 8px 20px; font-size: 13px; font-weight: 700; background: var(--bg-card); border: 1px solid var(--border); color: var(--text-primary);">បិទ</button>
                    <button class="btn btn-primary" onclick="navigateTo('#/edit-teacher?id=${teacherId}')" style="border-radius: 10px; padding: 8px 20px; font-size: 13px; font-weight: 700; background: #4F46E5; box-shadow: 0 4px 12px rgba(79,70,229,0.2);">កែប្រែ</button>
                </div>

            </div>
        </div>
    `;
    openModal(html, true);
}
