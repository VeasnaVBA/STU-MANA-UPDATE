/* js/page/teachers.js */
function renderTeachersList() {
    const container = document.getElementById('content-area');
    const currentUser = getCurrentUser();

    container.innerHTML = `
        <div class="page-header">
            <h1>All Teachers</h1>
            ${currentUser && currentUser.role !== 'Teacher' ? `
            <a href="#/add-teacher" class="btn btn-primary" onclick="navigateTo('#/add-teacher'); return false;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
                    <line x1="12" y1="5" x2="12" y2="19"></line>
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
                Add Teacher
            </a>
            ` : ''}
        </div>

        <div class="search-box">
            <div style="display: flex; align-items: center; gap: 8px; flex: 1;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--text-secondary)" stroke-width="2">
                    <circle cx="11" cy="11" r="8"></circle>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                </svg>
                <input type="text" id="search-teacher-input" placeholder="Search or filter teachers..." oninput="handleTeacherSearch(this.value)">
            </div>
            
            <div style="display: flex; align-items: center; gap: 10px;">
                <select id="teacher-filter-select" onchange="handleTeacherFilter()" style="min-width: 120px;">
                    <option value="all">ទាំងអស់</option>
                    <option value="Female">ស្រី</option>
                    <option value="Male">ប្រុស</option>
                </select>

                <div style="width: 1px; height: 24px; background: var(--border);"></div>

                <select id="sort-teacher-select" onchange="handleTeacherSort(this.value)" style="min-width: 150px;">
                    <option value="tkhLastName-asc">ឈ្មោះ: ក-អ</option>
                    <option value="tkhLastName-desc">ឈ្មោះ: អ-ក</option>
                    <option value="tengFirstName-asc">Name: A-Z</option>
                    <option value="tengFirstName-desc">Name: Z-A</option>
                    <option value="gender-female">ភេទ: ស្រី-ប្រុស</option>
                    <option value="gender-male">ភេទ: ប្រុស-ស្រី</option>
                    <option value="age-asc">អាយុ: តិច-ច្រើន</option>
                    <option value="age-desc">អាយុ: ច្រើន-តិច</option>
                </select>

                <button class="btn-minimal" onclick="exportTeachersToExcel()" title="Export Excel">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                        <polyline points="7 10 12 15 17 10"></polyline>
                        <line x1="12" y1="15" x2="12" y2="3"></line>
                    </svg>
                </button>
            </div>
        </div>

        <div class="data-table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th style="width: 60px; padding-left: 24px;">Status</th>
                        <th>Teacher Name</th>
                        <th>Teacher ID</th>
                        <th>Gender</th>
                        <th>Date of Birth</th>
                        <th>Age</th>
                        <th>Phone Number</th>
                        <th>Classroom</th>
                        <th>School</th>
                        <th class="sticky-actions-header" style="right: 0;">Actions</th>
                    </tr>
                </thead>
                <tbody id="teachers-table-body">
                    <!-- Rendered by JS -->
                </tbody>
            </table>
        </div>
    `;

    refreshTeacherTable();
}

let currentTeachers = [];

function refreshTeacherTable() {
    const tbody = document.getElementById('teachers-table-body');
    if (!tbody) return;

    let teachers = getTeachers();
    const currentUser = getCurrentUser();
    if (currentUser && currentUser.role === 'Teacher') {
        teachers = teachers.filter(t => (t.tengFirstName + ' ' + t.tengLastName) === currentUser.name);
    }

    const filterValue = document.getElementById('teacher-filter-select').value;
    if (filterValue === 'Female') {
        teachers = teachers.filter(t => ['Female', 'female', 'ស្រី', 'ស', 'F', 'f'].includes(t.gender));
    } else if (filterValue === 'Male') {
        teachers = teachers.filter(t => ['Male', 'male', 'ប្រុស', 'ប', 'M', 'm'].includes(t.gender));
    }

    const searchQuery = document.getElementById('search-teacher-input').value;
    if (searchQuery) {
        const lower = searchQuery.toLowerCase();
        teachers = teachers.filter(t => 
            (t.tengFirstName && t.tengFirstName.toLowerCase().includes(lower)) ||
            (t.tengLastName && t.tengLastName.toLowerCase().includes(lower)) ||
            (t.tkhFirstName && t.tkhFirstName.includes(lower)) ||
            (t.tkhLastName && t.tkhLastName.includes(lower)) ||
            (t.teacherId && t.teacherId.toLowerCase().includes(lower)) ||
            (t.classroom && t.classroom.toLowerCase().includes(lower))
        );
    }

    currentTeachers = teachers;
    renderTeacherTableData(currentTeachers);
}

function handleTeacherFilter() {
    refreshTeacherTable();
}

function renderTeacherTableData(teachers) {
    const tbody = document.getElementById('teachers-table-body');
    const currentUser = getCurrentUser();
    if (!tbody) return;

    if (teachers.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="10" style="padding: 48px; text-align: center;">
                    <div style="color: var(--text-secondary); font-size: 14px;">No teachers match your search.</div>
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = teachers.map((teacher) => `
        <tr>
            <td style="padding-left: 24px;">
                <div class="status-switch active" title="Active"></div>
            </td>
            <td>
                <div class="student-name-cell">
                    <div class="student-row-avatar" style="background: #eef2ff; color: #4f46e5;">
                        ${renderAvatar(teacher.photo, '👨‍🏫')}
                    </div>
                    <div>
                        <div style="font-size: 14px; font-weight: 600;">${teacher.tkhLastName || ''} ${teacher.tkhFirstName || ''}</div>
                        <div style="font-size: 11px; color: var(--text-secondary);">${teacher.tengFirstName || ''} ${teacher.tengLastName || ''}</div>
                    </div>
                </div>
            </td>
            <td style="font-family: monospace; font-size: 12px; color: var(--text-secondary);">${teacher.teacherId || teacher.id}</td>
            <td>${['Male', 'male', 'ប្រុស', 'ប', 'M', 'm'].includes(teacher.gender) ? 'ប្រុស' : (['Female', 'female', 'ស្រី', 'ស', 'F', 'f'].includes(teacher.gender) ? 'ស្រី' : teacher.gender || '-')}</td>
            <td>${(() => {
                if (!teacher.dateOfBirth) return '-';
                const dob = String(teacher.dateOfBirth);
                const parts = dob.split(/[-/]/);
                if (parts.length === 3) {
                    if (parts[0].length === 4) return `${parts[2]}/${parts[1]}/${parts[0]}`;
                    return `${parts[0]}/${parts[1]}/${parts[2]}`;
                }
                return dob;
            })()}</td>
            <td>${teacher.age || '-'}</td>
            <td>${teacher.phoneNumber || '-'}</td>
            <td><span class="grade-badge" style="background: var(--bg-body); border: 1px solid var(--border); color: var(--primary); font-size: 11px;">${teacher.classroom || '-'}</span></td>
            <td style="font-size: 13px;">${teacher.school || '-'}</td>
            <td class="sticky-actions">
                <div style="display: flex; align-items: center; gap: 4px;">
                    <button class="btn-minimal" onclick="navigateTo('#/show-teacher?id=${teacher.id}')" title="View Details">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                            <circle cx="12" cy="12" r="3"></circle>
                        </svg>
                    </button>
                    ${currentUser && currentUser.role !== 'Teacher' ? `
                    <button class="btn-minimal" onclick="navigateTo('#/edit-teacher?id=${teacher.id}')" title="Edit">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                        </svg>
                    </button>
                    <button class="btn-minimal" onclick="handleDeleteTeacher('${teacher.id}')" title="Delete">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="3 6 5 6 21 6"></polyline>
                            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                        </svg>
                    </button>
                    ` : ''}
                </div>
            </td>
        </tr>
    `).join('');
}

function handleTeacherSearch(query) {
    refreshTeacherTable();
}

function handleTeacherSort(value) {
    let teachers = getTeachers();
    const currentUser = getCurrentUser();
    if (currentUser && currentUser.role === 'Teacher') {
        teachers = teachers.filter(t => (t.tengFirstName + ' ' + t.tengLastName) === currentUser.name);
    }

    const sorted = [...teachers].sort((a, b) => {
        if (value === 'tkhLastName-asc') {
            const nameA = (a.tkhLastName || '') + (a.tkhFirstName || '');
            const nameB = (b.tkhLastName || '') + (b.tkhFirstName || '');
            return nameA.localeCompare(nameB, 'km');
        }
        if (value === 'tkhLastName-desc') {
            const nameA = (a.tkhLastName || '') + (a.tkhFirstName || '');
            const nameB = (b.tkhLastName || '') + (b.tkhFirstName || '');
            return nameB.localeCompare(nameA, 'km');
        }
        if (value === 'gender-female') {
            const isAFemale = ['Female', 'female', 'ស្រី', 'ស', 'F', 'f'].includes(a.gender);
            const isBFemale = ['Female', 'female', 'ស្រី', 'ស', 'F', 'f'].includes(b.gender);
            if (isAFemale && !isBFemale) return -1;
            if (!isAFemale && isBFemale) return 1;
            return 0;
        }
        if (value === 'gender-male') {
            const isAMale = ['Male', 'male', 'ប្រុស', 'ប', 'M', 'm'].includes(a.gender);
            const isBMale = ['Male', 'male', 'ប្រុស', 'ប', 'M', 'm'].includes(b.gender);
            if (isAMale && !isBMale) return -1;
            if (!isAMale && isBMale) return 1;
            return 0;
        }

        const [field, direction] = value.split('-');
        let valA = a[field];
        let valB = b[field];

        if (typeof valA === 'string') {
            valA = valA.toLowerCase();
            valB = valB.toLowerCase();
        }

        if (direction === 'asc') {
            return valA > valB ? 1 : -1;
        }
        return valA < valB ? 1 : -1;
    });
    renderTeacherTableData(sorted);
}

function handleDeleteTeacher(id) {
    if (confirm('Are you sure you want to delete this teacher?')) {
        if (deleteTeacher(id)) {
            showAlert('Teacher deleted successfully');
            refreshTeacherTable();
        }
    }
}

function exportTeachersToExcel() {
    let teachers = getTeachers();
    const currentUser = getCurrentUser();
    if (currentUser && currentUser.role === 'Teacher') {
        teachers = teachers.filter(t => (t.tengFirstName + ' ' + t.tengLastName) === currentUser.name);
    }
    if (teachers.length === 0) {
        if (typeof showAlert === 'function') showAlert('No teachers to export', 'error');
        return;
    }

    if (!window.confirm(`Are you sure you want to export ${teachers.length} teacher records to Excel?`)) {
        return;
    }

    const data = teachers.map((t, index) => ({
        'No': index + 1,
        'Teacher ID': t.teacherId || t.id,
        'Khmer Last Name': t.tkhLastName || '',
        'Khmer First Name': t.tkhFirstName || '',
        'English Last Name': t.tengLastName || '',
        'English First Name': t.tengFirstName || '',
        'Gender': t.gender || '',
        'Date of Birth': t.dateOfBirth || '',
        'Age': t.age || '',
        'Phone': t.phoneNumber || '',
        'Classroom': t.classroom || '',
        'School': t.school || ''
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Teachers");

    const wscols = [
        {wch: 25}, // No (A)
        {wch: 15}, // ID
        {wch: 18}, // KHLN
        {wch: 18}, // KHFN
        {wch: 18}, // ENLN
        {wch: 18}, // ENFN
        {wch: 10}, // Gender
        {wch: 15}, // DOB
        {wch: 8},  // Age
        {wch: 18}, // Phone
        {wch: 12}, // Class
        {wch: 25}  // School
    ];
    worksheet['!cols'] = wscols;

    const wsrows = [
        {hpx: 30}, // Header
    ];
    for(let i = 0; i < data.length; i++) {
        wsrows.push({hpx: 25});
    }
    worksheet['!rows'] = wsrows;

    XLSX.writeFile(workbook, "Teachers_List.xlsx");
}
