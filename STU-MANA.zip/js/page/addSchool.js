// js/page/addSchool.js
function renderAddSchool() {
    const container = document.getElementById('content-area');

    container.innerHTML = `
        <div class="page-header">
            <div style="display: flex; align-items: center; gap: 16px;">
                <button class="btn-minimal" onclick="navigateTo('#/schools')" title="Back to List">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="19" y1="12" x2="5" y2="12"></line>
                        <polyline points="12 19 5 12 12 5"></polyline>
                    </svg>
                </button>
                <div>
                    <h1 style="margin: 0;">បន្ថែមសាលារៀនថ្មី</h1>
                    <p style="font-size: 14px; color: var(--text-secondary); margin: 4px 0 0;">បំពេញព័ត៌មានសាលារៀនខាងក្រោម</p>
                </div>
            </div>
        </div>

        <form id="add-school-form" onsubmit="handleAddSchoolSubmit(event)" style="padding-bottom: 40px;">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 24px;">
                
                <!-- Section 1: General Info -->
                <div class="form-section">
                    <div class="form-section-title">ព័ត៌មានទូទៅ</div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="schoolId">អត្តលេខសាលា *</label>
                            <input type="text" id="schoolId" name="schoolId" required placeholder="ឧទាហរណ៍: Sch001">
                        </div>
                        <div class="form-group">
                            <label for="phoneNumber">លេខទូរស័ព្ទ</label>
                            <input type="tel" id="phoneNumber" name="phoneNumber" placeholder="012 345 678">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="schoolName">ឈ្មោះសាលារៀន *</label>
                        <input type="text" id="schoolName" name="schoolName" required placeholder="ឧទាហរណ៍: វិទ្យាល័យ ហ៊ុន សែន">
                    </div>
                    <div class="form-group">
                        <label for="directorName">ឈ្មោះនាយកសាលា</label>
                        <input type="text" id="directorName" name="directorName">
                    </div>
                </div>

                <!-- Section 2: Location & Description -->
                <div class="form-section">
                    <div class="form-section-title">ទីតាំង & ការពិពណ៌នា</div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="village">ភូមិ</label>
                            <input type="text" id="village" name="village">
                        </div>
                        <div class="form-group">
                            <label for="commune">ឃុំ/សង្កាត់</label>
                            <input type="text" id="commune" name="commune">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="district">ស្រុក/ខណ្ឌ</label>
                            <input type="text" id="district" name="district">
                        </div>
                        <div class="form-group">
                            <label for="province">ខេត្ត/ក្រុង</label>
                            <input type="text" id="province" name="province">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="description">ការពិពណ៌នាបន្ថែម</label>
                        <textarea id="description" name="description" rows="3" style="resize: none;"></textarea>
                    </div>
                </div>
            </div>

            <div class="form-actions" style="margin-top: 32px; justify-content: flex-end; position: sticky; bottom: 0; background: var(--bg-body); padding: 16px 0; z-index: 10;">
                <button type="button" class="btn btn-secondary" onclick="navigateTo('#/schools')">បោះបង់</button>
                <button type="submit" class="btn btn-primary" style="padding: 12px 40px;">រក្សាទុកសាលា</button>
            </div>
        </form>
    `;
}

function handleAddSchoolSubmit(event) {
    event.preventDefault();

    const form = event.target;
    const formData = new FormData(form);

    let schoolId = formData.get('schoolId').trim();
    if (schoolId && !schoolId.startsWith('Sch')) {
        schoolId = 'Sch' + schoolId;
    }

    const school = {
        schoolId: schoolId,
        schoolName: formData.get('schoolName').trim(),
        village: formData.get('village').trim(),
        commune: formData.get('commune').trim(),
        district: formData.get('district').trim(),
        province: formData.get('province').trim(),
        directorName: formData.get('directorName').trim(),
        phoneNumber: formData.get('phoneNumber').trim(),
        description: formData.get('description').trim()
    };

    addSchool(school);
    if (typeof showAlert === 'function') showAlert('School added successfully!');
    navigateTo('#/schools');
}
