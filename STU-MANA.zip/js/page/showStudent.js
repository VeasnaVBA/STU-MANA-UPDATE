function renderShowStudent(isEdit = false) {
    if (!isEdit) {
        renderStudentsList(); // Render background only when not toggling edit mode
    }
    const params = getUrlParams();
    const studentId = params.id;

    if (!studentId) {
        openModal('<div style="padding:24px;text-align:center;">No student selected.</div>');
        return;
    }

    const student = getStudentById(studentId);
    if (!student) {
        openModal('<div style="padding:24px;text-align:center;">Student not found.</div>');
        return;
    }

    const teachers = getTeachers();
    const teacher = teachers.find(t => t.id === student.teacher);
    const teacherName = teacher ? teacher.tengFirstName + ' ' + teacher.tengLastName : student.teacher || '-';

    const statusLabel = student.status === 'Active' ? 'កំពុងរៀន' : (student.status === 'Inactive' ? 'ឈប់រៀន' : (student.status === 'Graduated' ? 'បញ្ចប់ការសិក្សា' : student.status || 'កំពុងរៀន'));
    const statusColor = student.status === 'Active' ? '#4ADE80' : (student.status === 'Inactive' ? '#F87171' : '#60A5FA');

    const html = `
        <div style="padding: 24px; max-width: 900px; margin: 0 auto;">
            <div style="background: var(--bg-card); border-radius: 32px; box-shadow: 0 10px 40px rgba(0,0,0,0.15); overflow: hidden; font-family: var(--font-family); border: 1px solid var(--border); display: flex; flex-direction: column;">
                
                <div style="padding: 24px; display: grid; grid-template-columns: 1fr 1fr; gap: 32px;">
                    <!-- Left Column -->
                    <div style="display: flex; flex-direction: column; gap: 20px;">
                        <div style="display: flex; gap: 20px; align-items: flex-start;">
                            <div style="width: 100px; height: 120px; border-radius: 20px; overflow: hidden; background: var(--bg-body); border: 1px solid var(--border); flex-shrink: 0; position: relative;">
                                ${renderAvatar(student.photo, '👨‍🎓', { fontSize: '48px' })}
                                ${isEdit ? `
                                    <div style="position: absolute; bottom: 0; left: 0; right: 0; background: rgba(0,0,0,0.5); padding: 4px; display: flex; justify-content: center;">
                                        <label for="mini-photo-upload" style="cursor: pointer; color: white;">
                                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path>
                                                <circle cx="12" cy="13" r="4"></circle>
                                            </svg>
                                        </label>
                                        <input type="file" id="mini-photo-upload" style="display: none;" onchange="handleMiniImageUpload(this)">
                                        <input type="hidden" id="edit-photo-base64" value="${student.photo || ''}">
                                    </div>
                                ` : ''}
                            </div>

                            <div style="flex: 1;">
                                <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 8px;">
                                    <span style="width: 8px; height: 8px; border-radius: 50%; background: ${statusColor}; display: inline-block;"></span>
                                    ${isEdit ? `
                                        <select id="edit-status" style="font-size: 11px; border: none; background: transparent; font-weight: 700; color: var(--text-secondary); outline: none; cursor: pointer;">
                                            <option value="Active" ${student.status === 'Active' ? 'selected' : ''}>កំពុងរៀន</option>
                                            <option value="Inactive" ${student.status === 'Inactive' ? 'selected' : ''}>ឈប់រៀន</option>
                                            <option value="Graduated" ${student.status === 'Graduated' ? 'selected' : ''}>បញ្ចប់ការសិក្សា</option>
                                        </select>
                                    ` : `
                                        <span style="font-size: 12px; font-weight: 600; color: var(--text-secondary);">${statusLabel}</span>
                                    `}
                                </div>
                                
                                ${isEdit ? `
                                    <div style="display: flex; gap: 4px; margin-bottom: 4px;">
                                        <input type="text" id="edit-lastName" placeholder="ត្រកូល" value="${student.stuKhmerLastName || ''}" style="width: 50%; border: 1px solid var(--border); border-radius: 4px; padding: 4px; font-size: 14px; font-family: Khmer OS Muol Light;">
                                        <input type="text" id="edit-firstName" placeholder="ឈ្មោះ" value="${student.stuKhmerFirstName || ''}" style="width: 50%; border: 1px solid var(--border); border-radius: 4px; padding: 4px; font-size: 14px; font-family: Khmer OS Muol Light;">
                                    </div>
                                    <div style="display: flex; gap: 4px;">
                                        <input type="text" id="edit-engLastName" placeholder="Last Name" value="${student.stuEngLastName || ''}" style="width: 50%; border: 1px solid var(--border); border-radius: 4px; padding: 4px; font-size: 12px;">
                                        <input type="text" id="edit-engFirstName" placeholder="First Name" value="${student.stuEngFirstName || ''}" style="width: 50%; border: 1px solid var(--border); border-radius: 4px; padding: 4px; font-size: 12px;">
                                    </div>
                                ` : `
                                    <h2 style="margin: 0; font-size: 20px; font-weight: 800; color: var(--text-primary); line-height: 1.2;">
                                        ${student.stuKhmerLastName || ''} ${student.stuKhmerFirstName || ''}
                                    </h2>
                                    <div style="font-size: 14px; color: var(--text-secondary); margin-top: 2px;">
                                        ${student.stuEngFirstName || ''} ${student.stuEngLastName || ''}
                                    </div>
                                `}
                                
                                <div style="margin-top: 12px; display: flex; gap: 10px; align-items: center;">
                                    <span style="background: var(--bg-body); padding: 3px 10px; border-radius: 100px; font-size: 11px; font-weight: 700; color: var(--text-secondary);">
                                        ID: #${student.stuId || student.id}
                                    </span>
                                    <span style="font-size: 12px; color: var(--border);">|</span>
                                    <span style="font-size: 12px; color: var(--text-secondary); font-weight: 500;">
                                        ${student.school || 'សាលារៀន'}
                                    </span>
                                </div>
                            </div>
                        </div>

                        <!-- Content wrapper to align with right side -->
                        <div style="flex: 1; display: flex; flex-direction: column; gap: 20px; justify-content: flex-end;">
                            <!-- Address Section Title -->
                            <div style="font-size: 11px; font-weight: 800; text-transform: uppercase; color: var(--primary); margin-bottom: 0; display: flex; align-items: center; gap: 8px;">
                                <span>អាសយដ្ឋាន</span>
                                <div style="flex: 1; height: 1px; background: var(--border);"></div>
                            </div>

                            <!-- Birth Address -->
                            <div style="padding: 12px 16px; background: #FFF9C4; border-radius: 14px; display: flex; flex-direction: column; gap: 6px; border: 1px solid #FBC02D; height: 75px; justify-content: center;">
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#F57F17" stroke-width="2.5">
                                        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                                        <polyline points="9 22 9 12 15 12 15 22"></polyline>
                                    </svg>
                                    <span style="font-size: 11px; font-weight: 700; color: #F57F17; text-transform: uppercase;">ទីកន្លែងកំណើត</span>
                                </div>
                                <div style="font-size: 12px; color: #333; font-weight: 500;">
                                    ${isEdit ? `
                                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 4px;">
                                            <input type="text" id="edit-birthVillage" value="${student.birthVillage || ''}" placeholder="ភូមិ" style="border: 1px solid #FBC02D; border-radius: 4px; padding: 2px 4px; font-size: 11px;">
                                            <input type="text" id="edit-birthCommune" value="${student.birthCommune || ''}" placeholder="ឃុំ/សង្កាត់" style="border: 1px solid #FBC02D; border-radius: 4px; padding: 2px 4px; font-size: 11px;">
                                            <input type="text" id="edit-birthDistrict" value="${student.birthDistrict || ''}" placeholder="ស្រុក/ខណ្ឌ" style="border: 1px solid #FBC02D; border-radius: 4px; padding: 2px 4px; font-size: 11px;">
                                            <input type="text" id="edit-birthProvince" value="${student.birthProvince || ''}" placeholder="ខេត្ត/ក្រុង" style="border: 1px solid #FBC02D; border-radius: 4px; padding: 2px 4px; font-size: 11px;">
                                        </div>
                                    ` : `
                                        <div style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; line-height: 1.2;">
                                            ${[student.birthVillage, student.birthCommune, student.birthDistrict, student.birthProvince].filter(Boolean).join(', ') || 'មិនមានព័ត៌មានទីកន្លែងកំណើត'}
                                        </div>
                                    `}
                                </div>
                            </div>

                            <!-- Current Address -->
                            <div style="padding: 12px 16px; background: var(--bg-body); border-radius: 14px; display: flex; flex-direction: column; gap: 6px; border: 1px solid var(--border); height: 75px; justify-content: center;">
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--text-secondary)" stroke-width="2.5">
                                        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                        <circle cx="12" cy="10" r="3"></circle>
                                    </svg>
                                    <span style="font-size: 11px; font-weight: 700; color: var(--text-secondary); text-transform: uppercase;">អាសយដ្ឋានបច្ចុប្បន្ន</span>
                                </div>
                                <div style="font-size: 12px; color: var(--text-primary); font-weight: 500;">
                                    ${isEdit ? `
                                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 4px;">
                                            <input type="text" id="edit-village" value="${student.currentVillage || ''}" placeholder="ភូមិ" style="border: 1px solid var(--border); border-radius: 4px; padding: 2px 4px; font-size: 11px;">
                                            <input type="text" id="edit-commune" value="${student.currentCommmune || ''}" placeholder="ឃុំ/សង្កាត់" style="border: 1px solid var(--border); border-radius: 4px; padding: 2px 4px; font-size: 11px;">
                                            <input type="text" id="edit-district" value="${student.currentDistrict || ''}" placeholder="ស្រុក/ខណ្ឌ" style="border: 1px solid var(--border); border-radius: 4px; padding: 2px 4px; font-size: 11px;">
                                            <input type="text" id="edit-province" value="${student.currentProvince || ''}" placeholder="ខេត្ត/ក្រុង" style="border: 1px solid var(--border); border-radius: 4px; padding: 2px 4px; font-size: 11px;">
                                        </div>
                                    ` : `
                                        <div style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; line-height: 1.2;">
                                            ${[student.currentVillage, student.currentCommmune, student.currentDistrict, student.currentProvince].filter(Boolean).join(', ') || 'មិនមានអាសយដ្ឋាន'}
                                        </div>
                                    `}
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Right Column -->
                    <div style="display: flex; flex-direction: column; gap: 20px;">
                        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; height: 120px;">
                            <div style="padding: 12px 8px; border: 1px solid var(--border); border-radius: 16px; text-align: center; background: var(--bg-card); display: flex; flex-direction: column; justify-content: center;">
                                <div style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; font-weight: 700; margin-bottom: 2px;">ភេទ</div>
                                ${isEdit ? `
                                    <select id="edit-gender" style="width: 100%; border: none; background: transparent; font-size: 12px; font-weight: 700; text-align: center; outline: none;">
                                        <option value="Male" ${['Male', 'male', 'ប្រុស', 'ប', 'M', 'm'].includes(student.gender) ? 'selected' : ''}>ប្រុស</option>
                                        <option value="Female" ${['Female', 'female', 'ស្រី', 'ស', 'F', 'f'].includes(student.gender) ? 'selected' : ''}>ស្រី</option>
                                    </select>
                                ` : `
                                    <div style="font-size: 13px; font-weight: 700; color: var(--text-primary);">${['Male', 'male', 'ប្រុស', 'ប', 'M', 'm'].includes(student.gender) ? 'ប្រុស' : (['Female', 'female', 'ស្រី', 'ស', 'F', 'f'].includes(student.gender) ? 'ស្រី' : student.gender || '-')}</div>
                                `}
                            </div>
                            <div style="padding: 12px 8px; border: 1px solid var(--border); border-radius: 16px; text-align: center; background: var(--bg-card); display: flex; flex-direction: column; justify-content: center;">
                                <div style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; font-weight: 700; margin-bottom: 2px;">ថ្នាក់</div>
                                <div style="font-size: 13px; font-weight: 700; color: var(--text-primary);">${student.classroom || '-'}</div>
                            </div>
                            <div style="padding: 12px 8px; border: 1px solid var(--border); border-radius: 16px; text-align: center; background: var(--bg-card); display: flex; flex-direction: column; justify-content: center;">
                                <div style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; font-weight: 700; margin-bottom: 2px;">ឆ្នាំ</div>
                                ${isEdit ? `
                                    <input type="text" id="edit-dob" value="${student.dateOfBirth || ''}" placeholder="DD/MM/YYYY" style="width: 100%; border: none; background: transparent; font-size: 11px; font-weight: 700; text-align: center; outline: none;">
                                ` : `
                                    <div style="font-size: 13px; font-weight: 700; color: var(--text-primary);">${(() => {
                                        if (!student.dateOfBirth) return '-';
                                        const dob = String(student.dateOfBirth);
                                        const parts = dob.split(/[-/]/);
                                        if (parts.length === 3) {
                                            // If first part is 4 digits, it's yyyy-mm-dd
                                            if (parts[0].length === 4) return parts[0];
                                            // Otherwise it's dd/mm/yyyy or dd-mm-yyyy, so return last part (year)
                                            return parts[2];
                                        }
                                        return dob;
                                    })()}</div>
                                `}
                            </div>
                            <div style="padding: 12px 8px; border: 1px solid var(--border); border-radius: 16px; text-align: center; background: var(--bg-card); display: flex; flex-direction: column; justify-content: center;">
                                <div style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase; font-weight: 700; margin-bottom: 2px;">ទូរស័ព្ទ</div>
                                ${isEdit ? `
                                    <input type="text" id="edit-phone" value="${student.stuPhoneNumber || ''}" placeholder="Phone" style="width: 100%; border: none; background: transparent; font-size: 11px; font-weight: 700; text-align: center; outline: none;">
                                ` : `
                                    <div style="font-size: 13px; font-weight: 700; color: var(--text-primary);">${student.stuPhoneNumber ? student.stuPhoneNumber.slice(-10) : '-'}</div>
                                `}
                            </div>
                        </div>

                        <div style="padding: 0; flex: 1; display: flex; flex-direction: column; gap: 20px; justify-content: flex-end;">
                            <div style="font-size: 11px; font-weight: 800; text-transform: uppercase; color: var(--primary); margin-bottom: 0; display: flex; align-items: center; gap: 8px;">
                                <span>ព័ត៌មានអាណាព្យាបាល</span>
                                <div style="flex: 1; height: 1px; background: var(--border);"></div>
                            </div>
                            
                            <div style="display: flex; flex-direction: column; gap: 12px;">
                                <!-- Father -->
                                <div style="padding: 10px; background: var(--bg-body); border-radius: 12px; border: 1px solid var(--border); height: 75px; display: flex; flex-direction: column; justify-content: center;">
                                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
                                        <span style="font-size: 11px; color: var(--text-secondary); font-weight: 700;">ឪពុក:</span>
                                        ${isEdit ? `
                                            <input type="text" id="edit-fatherName" value="${student.fatherName || ''}" placeholder="ឈ្មោះឪពុក" style="width: 70%; border: none; background: transparent; font-size: 13px; font-weight: 700; text-align: right; outline: none;">
                                        ` : `
                                            <span style="font-size: 13px; font-weight: 700; color: var(--text-primary);">${student.fatherName || '-'}</span>
                                        `}
                                    </div>
                                    <div style="display: flex; justify-content: space-between; font-size: 11px;">
                                        <span style="color: var(--text-secondary);">មុខរបរ / ទូរស័ព្ទ:</span>
                                        ${isEdit ? `
                                            <div style="display: flex; gap: 4px;">
                                                <input type="text" id="edit-fatherJob" value="${student.fatherJob || ''}" placeholder="មុខរបរ" style="width: 80px; border: none; background: transparent; font-size: 11px; text-align: right; outline: none;">
                                                <span>|</span>
                                                <input type="text" id="edit-fatherPhone" value="${student.fatherPhone || ''}" placeholder="ទូរស័ព្ទ" style="width: 100px; border: none; background: transparent; font-size: 11px; text-align: right; outline: none;">
                                            </div>
                                        ` : `
                                            <span style="color: var(--text-primary);">${student.fatherJob || '-'} | ${student.fatherPhone || '-'}</span>
                                        `}
                                    </div>
                                </div>

                                <!-- Mother -->
                                <div style="padding: 10px; background: var(--bg-body); border-radius: 12px; border: 1px solid var(--border); height: 75px; display: flex; flex-direction: column; justify-content: center;">
                                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
                                        <span style="font-size: 11px; color: var(--text-secondary); font-weight: 700;">ម្តាយ:</span>
                                        ${isEdit ? `
                                            <input type="text" id="edit-motherName" value="${student.motherName || ''}" placeholder="ឈ្មោះម្តាយ" style="width: 70%; border: none; background: transparent; font-size: 13px; font-weight: 700; text-align: right; outline: none;">
                                        ` : `
                                            <span style="font-size: 13px; font-weight: 700; color: var(--text-primary);">${student.motherName || '-'}</span>
                                        `}
                                    </div>
                                    <div style="display: flex; justify-content: space-between; font-size: 11px;">
                                        <span style="color: var(--text-secondary);">មុខរបរ / ទូរស័ព្ទ:</span>
                                        ${isEdit ? `
                                            <div style="display: flex; gap: 4px;">
                                                <input type="text" id="edit-motherJob" value="${student.motherJob || ''}" placeholder="មុខរបរ" style="width: 80px; border: none; background: transparent; font-size: 11px; text-align: right; outline: none;">
                                                <span>|</span>
                                                <input type="text" id="edit-motherPhone" value="${student.motherPhone || ''}" placeholder="ទូរស័ព្ទ" style="width: 100px; border: none; background: transparent; font-size: 11px; text-align: right; outline: none;">
                                            </div>
                                        ` : `
                                            <span style="color: var(--text-primary);">${student.motherJob || '-'} | ${student.motherPhone || '-'}</span>
                                        `}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div style="padding: 16px 24px; background: var(--bg-body); border-top: 1px solid var(--border); display: flex; justify-content: flex-end; gap: 10px;">
                    ${isEdit ? `
                        <button class="btn btn-secondary" onclick="renderShowStudent(false)" style="border-radius: 10px; padding: 8px 20px; font-size: 13px; font-weight: 700; background: var(--bg-card); border: 1px solid var(--border); color: var(--text-primary);">បោះបង់</button>
                        <button class="btn btn-primary" onclick="handleQuickUpdate('${studentId}')" style="border-radius: 10px; padding: 8px 20px; font-size: 13px; font-weight: 700; background: #22c55e; border: none; color: white; box-shadow: 0 4px 12px rgba(34,197,94,0.3);">រក្សាទុក</button>
                    ` : `
                        <button class="btn btn-secondary" onclick="closeModal()" style="border-radius: 10px; padding: 8px 20px; font-size: 13px; font-weight: 700; background: var(--bg-card); border: 1px solid var(--border); color: var(--text-primary);">បិទ</button>
                        <button class="btn btn-primary" onclick="renderShowStudent(true)" style="border-radius: 10px; padding: 8px 20px; font-size: 13px; font-weight: 700; box-shadow: 0 4px 12px rgba(0,74,217,0.2);">កែប្រែក្នុងប័ណ្ណ</button>
                    `}
                </div>
            </div>
        </div>
    `;
    openModal(html, true);
}

window.handleMiniImageUpload = function (input) {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function (e) {
        document.getElementById('edit-photo-base64').value = e.target.result;
        // Update avatar in UI immediately
        const avatarContainer = input.closest('div').parentElement;
        avatarContainer.innerHTML = `<img src="${e.target.result}" style="width:100%; height:100%; object-fit:cover;">` + avatarContainer.innerHTML.split('</svg>')[1] || '';
    };
    reader.readAsDataURL(file);
};

window.handleQuickUpdate = function (studentId) {
    const student = getStudentById(studentId);
    if (!student) return;

    const updatedData = {
        ...student,
        status: document.getElementById('edit-status').value,
        stuKhmerLastName: document.getElementById('edit-lastName').value,
        stuKhmerFirstName: document.getElementById('edit-firstName').value,
        stuEngLastName: document.getElementById('edit-engLastName').value,
        stuEngFirstName: document.getElementById('edit-engFirstName').value,
        currentVillage: document.getElementById('edit-village').value,
        currentCommmune: document.getElementById('edit-commune').value,
        currentDistrict: document.getElementById('edit-district').value,
        currentProvince: document.getElementById('edit-province').value,
        birthVillage: document.getElementById('edit-birthVillage').value,
        birthCommune: document.getElementById('edit-birthCommune').value,
        birthDistrict: document.getElementById('edit-birthDistrict').value,
        birthProvince: document.getElementById('edit-birthProvince').value,
        fatherName: document.getElementById('edit-fatherName').value,
        fatherJob: document.getElementById('edit-fatherJob').value,
        fatherPhone: document.getElementById('edit-fatherPhone').value,
        motherName: document.getElementById('edit-motherName').value,
        motherJob: document.getElementById('edit-motherJob').value,
        motherPhone: document.getElementById('edit-motherPhone').value,
        gender: document.getElementById('edit-gender').value,
        dateOfBirth: document.getElementById('edit-dob').value,
        stuPhoneNumber: document.getElementById('edit-phone').value,
        photo: document.getElementById('edit-photo-base64').value
    };

    updateStudent(studentId, updatedData);
    showAlert('ព័ត៌មានត្រូវបានកែប្រែដោយជោគជ័យ!');
    renderShowStudent(false);
    if (window.refreshStudentsTable) window.refreshStudentsTable();
}
