// js/page/settings.js

function renderSettings() {
    const container = document.getElementById('content-area');
    const settings = getSettings();
    const headerSize = localStorage.getItem('sms_header_size') || '28';
    const tableSize = localStorage.getItem('sms_table_size') || '14';
    const fontKhmer = localStorage.getItem('sms_font_khmer') || "'Khmer OS Siemreap'";
    const fontEng = localStorage.getItem('sms_font_eng') || "'Inter'";
    
    container.innerHTML = `
        <div class="page-header">
            <div class="header-title">
                <h1>System Settings</h1>
                <p>Configure global parameters and personalize your display</p>
            </div>
        </div>

        <div class="settings-grid" style="display: grid; grid-template-columns: 1fr; gap: 32px; max-width: 900px; padding-bottom: 50px;">
            
            <!-- 1. Score Entry Window -->
            <div class="card" style="background: var(--bg-card); padding: 24px; border-radius: var(--radius-lg); box-shadow: var(--shadow-sm); border: 1px solid var(--border);">
                <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 20px;">
                    <div style="width: 42px; height: 42px; background: #e3f2fd; border-radius: 10px; display: flex; align-items: center; justify-content: center; color: var(--primary);">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                            <line x1="3" y1="10" x2="21" y2="10"></line>
                        </svg>
                    </div>
                    <div>
                        <h3 style="margin: 0; font-size: 18px; color: var(--text-main);">Score Entry Window</h3>
                        <p style="margin: 0; font-size: 13px; color: var(--text-secondary);">Restrict when teachers can input academic scores each month</p>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; padding: 20px; background: #f8f9fa; border-radius: var(--radius-md); border: 1px solid var(--border);">
                    <div class="form-group">
                        <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">Start Day of Month</label>
                        <input type="number" id="setting-start-day" min="1" max="31" value="${settings.scoreEntryStartDay}" 
                               style="width: 100%; padding: 10px; border: 1px solid var(--border); border-radius: var(--radius-sm); font-size: 15px;">
                    </div>
                    <div class="form-group">
                        <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">End Day of Month</label>
                        <input type="number" id="setting-end-day" min="1" max="31" value="${settings.scoreEntryEndDay}" 
                               style="width: 100%; padding: 10px; border: 1px solid var(--border); border-radius: var(--radius-sm); font-size: 15px;">
                    </div>
                </div>

                <div style="margin-top: 20px; display: flex; justify-content: flex-end;">
                    <button class="btn btn-primary" onclick="saveSystemSettings()" style="padding: 10px 24px;">
                        Save Window Settings
                    </button>
                </div>
            </div>

            <!-- 2. Display Preferences -->
            <div class="card" style="background: var(--bg-card); padding: 24px; border-radius: var(--radius-lg); box-shadow: var(--shadow-sm); border: 1px solid var(--border);">
                <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 20px;">
                    <div style="width: 42px; height: 42px; background: #f3e5f5; border-radius: 10px; display: flex; align-items: center; justify-content: center; color: #9c27b0;">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M4 7V4h16v3M9 20h6M12 4v16"></path>
                        </svg>
                    </div>
                    <div>
                        <h3 style="margin: 0; font-size: 18px; color: var(--text-main);">Display Preferences</h3>
                        <p style="margin: 0; font-size: 13px; color: var(--text-secondary);">Customize font sizes for better readability</p>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-bottom: 24px;">
                    <div>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                            <label style="font-weight: 600; font-size: 14px;">Header Font Size</label>
                            <span id="header-size-value" style="color: var(--primary); font-weight: 700; font-size: 13px; background: #e3f2fd; padding: 2px 8px; border-radius: 10px;">${headerSize}px</span>
                        </div>
                        <input type="range" id="header-font-size-input" min="20" max="40" value="${headerSize}" 
                               style="width: 100%; cursor: pointer;" oninput="updateFontSizePreview('header', this.value)">
                    </div>

                    <div>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                            <label style="font-weight: 600; font-size: 14px;">Table Data Font Size</label>
                            <span id="table-size-value" style="color: #9c27b0; font-weight: 700; font-size: 13px; background: #f3e5f5; padding: 2px 8px; border-radius: 10px;">${tableSize}px</span>
                        </div>
                        <input type="range" id="table-font-size-input" min="10" max="20" value="${tableSize}" 
                               style="width: 100%; cursor: pointer;" oninput="updateFontSizePreview('table', this.value)">
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 24px;">
                    <div>
                        <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">Khmer Font (ភាសាខ្មែរ)</label>
                        <select id="font-khmer-input" style="width: 100%; padding: 10px; border: 1px solid var(--border); border-radius: var(--radius-sm); font-size: 14px; background: var(--bg-card); color: var(--text-primary); cursor: pointer;" onchange="updateFontPreview()">
                            <option value="'Khmer OS System'" ${fontKhmer.includes('Khmer OS System') ? 'selected' : ''}>Khmer OS System</option>
                            <option value="'Khmer OS Siemreap'" ${fontKhmer.includes('Khmer OS Siemreap') ? 'selected' : ''}>Khmer OS Siemreap</option>
                        </select>
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">English Font (Latin)</label>
                        <select id="font-eng-input" style="width: 100%; padding: 10px; border: 1px solid var(--border); border-radius: var(--radius-sm); font-size: 14px; background: var(--bg-card); color: var(--text-primary); cursor: pointer;" onchange="updateFontPreview()">
                            <option value="'Arial'" ${fontEng.includes('Arial') ? 'selected' : ''}>Arial</option>
                            <option value="'Times New Roman'" ${fontEng.includes('Times New Roman') ? 'selected' : ''}>Times New Roman</option>
                            <option value="'Inter'" ${fontEng.includes('Inter') ? 'selected' : ''}>Inter (Default)</option>
                        </select>
                    </div>
                </div>

                <div style="background: #f8f9fa; padding: 20px; border-radius: var(--radius-md); border: 1px dashed var(--border); margin-bottom: 20px;">
                    <h4 style="margin: 0 0 12px; font-size: 14px; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.5px;">Live Preview</h4>
                    <div id="preview-area" style="padding: 15px; border: 1px solid var(--border); border-radius: 8px; background: white; font-family: ${fontEng}, ${fontKhmer}, sans-serif;">
                        <h1 id="preview-header" style="font-size: ${headerSize}px; margin: 0 0 10px; color: var(--text-main); font-weight: 700;">សួស្តី Sample Text 123</h1>
                        <p id="preview-table" style="font-size: ${tableSize}px; margin: 0; color: var(--text-secondary);">នេះគឺជាអត្ថបទគំរូ Sample of Khmer and English text.</p>
                    </div>
                </div>

                <div style="display: flex; justify-content: flex-end; gap: 12px;">
                    <button class="btn btn-secondary" onclick="resetDisplaySettings()">Reset Defaults</button>
                    <button class="btn btn-primary" onclick="saveDisplaySettings()">Save Display Settings</button>
                </div>
            </div>
            <!-- 3. Database Management (Admin Only) -->
            ${(getCurrentUser().role === 'Admin' || getCurrentUser().role === 'Super Admin') ? `
            <div class="card" style="background: #fff5f5; padding: 24px; border-radius: var(--radius-lg); box-shadow: var(--shadow-sm); border: 1px solid #feb2b2;">
                <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 20px;">
                    <div style="width: 42px; height: 42px; background: #fee2e2; border-radius: 10px; display: flex; align-items: center; justify-content: center; color: #dc2626;">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                        </svg>
                    </div>
                    <div>
                        <h3 style="margin: 0; font-size: 18px; color: #991b1b;">Database Management</h3>
                        <p style="margin: 0; font-size: 13px; color: #b91c1c;">Surgically clear records by teacher and data type</p>
                    </div>
                </div>

                <div style="background: white; padding: 20px; border-radius: var(--radius-md); border: 1px solid #feb2b2; margin-bottom: 20px;">
                    <p style="margin: 0 0 15px; font-size: 14px; color: #7f1d1d; line-height: 1.5;">
                        <strong>Warning:</strong> This action is irreversible. You can choose a teacher and clear their specific student records or scoring data.
                    </p>
                    <button class="btn btn-delete" onclick="showDatabaseCleanupModal()" style="background: #dc2626; color: white; border: none; padding: 12px 24px; border-radius: 8px; font-weight: 600; cursor: pointer;">
                        Open Cleanup Tool
                    </button>
                </div>
            </div>
            ` : ''}
        </div>
    `;
}

function showDatabaseCleanupModal() {
    const teachers = getTeachers();
    const periods = [
        "January", "February", "March", "April", "May", "June", 
        "July", "August", "September", "October", "November", "December"
    ];
    
    const html = `
        <div style="padding: 24px; min-width: 500px;">
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 24px; color: #dc2626;">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                    <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                </svg>
                <h2 style="margin: 0; font-size: 20px;">Surgical Data Cleanup</h2>
            </div>

            <div style="display: flex; flex-direction: column; gap: 20px;">
                <div>
                    <label style="display: block; font-weight: 700; font-size: 14px; margin-bottom: 8px;">1. Select Teacher</label>
                    <select id="cleanup-teacher-id" style="width: 100%; padding: 12px; border: 2px solid var(--border); border-radius: 8px; font-size: 15px;">
                        <option value="">-- Choose Teacher --</option>
                        ${teachers.map(t => `<option value="${t.id}">${t.tkhFirstName} ${t.tkhLastName} (${t.classroom})</option>`).join('')}
                    </select>
                </div>

                <div>
                    <label style="display: block; font-weight: 700; font-size: 14px; margin-bottom: 12px;">2. Select Data to Clear</label>
                    <div style="display: flex; flex-direction: column; gap: 12px; background: #fef2f2; padding: 16px; border-radius: 8px; border: 1px solid #fee2e2;">
                        <label style="display: flex; align-items: center; gap: 10px; cursor: pointer; font-weight: 500;">
                            <input type="checkbox" id="clear-students" style="width: 18px; height: 18px;">
                            Student Records (Profiles, Photos, etc.)
                        </label>
                        <div style="display: flex; flex-direction: column; gap: 10px;">
                            <label style="display: flex; align-items: center; gap: 10px; cursor: pointer; font-weight: 500;">
                                <input type="checkbox" id="clear-scores" style="width: 18px; height: 18px;" onchange="toggleMonthSelection(this.checked)">
                                Academic Scores
                            </label>
                            
                            <div id="month-selection-area" style="display: none; margin-left: 28px; padding: 12px; background: white; border: 1px solid #fee2e2; border-radius: 8px;">
                                <p style="margin: 0 0 10px; font-size: 12px; font-weight: 700; color: #991b1b;">Choose Months to Clear:</p>
                                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px;">
                                    ${periods.map(p => `
                                        <label style="font-size: 11px; display: flex; align-items: center; gap: 5px; cursor: pointer;">
                                            <input type="checkbox" class="cleanup-month-cb" value="${p}"> ${p}
                                        </label>
                                    `).join('')}
                                </div>
                                <div style="margin-top: 10px; display: flex; gap: 10px;">
                                    <button class="btn btn-secondary" style="font-size: 10px; padding: 4px 8px;" onclick="selectAllCleanupMonths(true)">Select All</button>
                                    <button class="btn btn-secondary" style="font-size: 10px; padding: 4px 8px;" onclick="selectAllCleanupMonths(false)">Clear All</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div>
                    <label style="display: block; font-weight: 700; font-size: 14px; margin-bottom: 8px; color: #dc2626;">3. Verify Admin Password</label>
                    <input type="password" id="cleanup-admin-password" placeholder="Enter your password to confirm" 
                           style="width: 100%; padding: 12px; border: 2px solid #fee2e2; border-radius: 8px; font-size: 15px;">
                </div>

                <div style="margin-top: 24px; display: flex; justify-content: flex-end; gap: 12px; border-top: 1px solid var(--border); padding-top: 20px;">
                    <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                    <button class="btn btn-primary" onclick="handleDatabaseCleanup()" style="background: #dc2626; border-color: #dc2626; padding-left: 24px; padding-right: 24px;">
                        Confirm & Execute
                    </button>
                </div>
            </div>
        </div>
    `;
    openModal(html);
}

function toggleMonthSelection(show) {
    const area = document.getElementById('month-selection-area');
    if (area) area.style.display = show ? 'block' : 'none';
}

function selectAllCleanupMonths(check) {
    document.querySelectorAll('.cleanup-month-cb').forEach(cb => cb.checked = check);
}

function handleDatabaseCleanup() {
    const teacherId = document.getElementById('cleanup-teacher-id').value;
    const clearStudents = document.getElementById('clear-students').checked;
    const clearScores = document.getElementById('clear-scores').checked;
    const adminPassword = document.getElementById('cleanup-admin-password').value;
    
    const selectedMonths = Array.from(document.querySelectorAll('.cleanup-month-cb:checked')).map(cb => cb.value);

    if (!teacherId) {
        showAlert('Please select a teacher first.', 'error');
        return;
    }

    if (!clearStudents && !clearScores) {
        showAlert('Please select at least one option to clear.', 'info');
        return;
    }

    if (clearScores && selectedMonths.length === 0) {
        showAlert('Please select at least one month to clear scores.', 'info');
        return;
    }

    if (!adminPassword) {
        showAlert('Password verification required.', 'error');
        return;
    }

    // Verify Password
    const currentUser = getCurrentUser();
    const users = getUsers();
    const dbUser = users.find(u => u.username === currentUser.username);

    if (!dbUser || dbUser.password !== adminPassword) {
        showAlert('Incorrect password. Access denied.', 'error');
        return;
    }

    const teacher = getTeacherById(teacherId);
    const teacherName = `${teacher.tkhFirstName} ${teacher.tkhLastName}`;
    
    let warningMsg = `FINAL CONFIRMATION:\n\nYou are about to permanently delete data for ${teacherName}.\n\n`;
    if (clearStudents) warningMsg += `- ALL STUDENTS will be deleted.\n`;
    if (clearScores) warningMsg += `- SCORES for ${selectedMonths.length} months will be deleted.\n`;
    warningMsg += `\nType 'DELETE' in the next box to confirm. (Just kidding, just click OK if you are sure)`;

    if (!confirm(warningMsg)) {
        return;
    }

    const allStudents = getStudents();
    const studentsOfTeacher = allStudents.filter(s => s.teacher === teacherId);
    const studentIds = studentsOfTeacher.map(s => s.id);

    if (clearScores) {
        const allScores = getScores();
        // Keep scores that are NOT for these students OR NOT for these months
        const remainingScores = allScores.filter(sc => {
            const isStudentScore = studentIds.includes(sc.studentId);
            const isSelectedMonth = selectedMonths.includes(sc.period);
            return !(isStudentScore && isSelectedMonth);
        });
        saveScores(remainingScores);
    }

    if (clearStudents) {
        const remainingStudents = allStudents.filter(s => s.teacher !== teacherId);
        saveStudents(remainingStudents);
    }

    showAlert(`Surgical cleanup successful for ${teacherName}.`, 'success');
    closeModal();
    if (typeof refreshStudentTable === 'function') refreshStudentTable();
}

function saveSystemSettings() {
    const start = parseInt(document.getElementById('setting-start-day').value);
    const end = parseInt(document.getElementById('setting-end-day').value);
    
    if (start < 1 || start > 31 || end < 1 || end > 31 || start > end) {
        showAlert('Please enter valid days (1-31) and ensure Start Day is not greater than End Day.', 'error');
        return;
    }
    
    saveSettings({
        scoreEntryStartDay: start,
        scoreEntryEndDay: end
    });
    
    showAlert('System settings updated successfully!', 'success');
}

function updateFontSizePreview(type, value) {
    document.getElementById(`${type}-size-value`).textContent = value + 'px';
    if (type === 'header') {
        document.getElementById('preview-header').style.fontSize = value + 'px';
    } else {
        document.getElementById('preview-table').style.fontSize = value + 'px';
    }
}

function updateFontPreview() {
    const khmer = document.getElementById('font-khmer-input').value;
    const eng = document.getElementById('font-eng-input').value;
    document.getElementById('preview-area').style.fontFamily = `${eng}, ${khmer}, sans-serif`;
}

function saveDisplaySettings() {
    const headerSize = document.getElementById('header-font-size-input').value;
    const tableSize = document.getElementById('table-font-size-input').value;
    const fontKhmer = document.getElementById('font-khmer-input').value;
    const fontEng = document.getElementById('font-eng-input').value;

    localStorage.setItem('sms_header_size', headerSize);
    localStorage.setItem('sms_table_size', tableSize);
    localStorage.setItem('sms_font_khmer', fontKhmer);
    localStorage.setItem('sms_font_eng', fontEng);

    if (typeof applySettings === 'function') applySettings();
    showAlert('Display preferences saved successfully!', 'success');
}

function resetDisplaySettings() {
    if (confirm('Reset display settings to default?')) {
        localStorage.removeItem('sms_header_size');
        localStorage.removeItem('sms_table_size');
        localStorage.removeItem('sms_font_khmer');
        localStorage.removeItem('sms_font_eng');
        if (typeof applySettings === 'function') applySettings();
        renderSettings();
        showAlert('Settings reset to default');
    }
}
