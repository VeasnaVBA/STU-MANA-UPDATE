// js/utils.js
function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

function formatDate(date) {
    return new Date(date).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

function calculateStars(gpa) {
    if (gpa >= 3.9) return 5;
    if (gpa >= 3.7) return 4;
    if (gpa >= 3.3) return 3;
    if (gpa >= 3.0) return 2;
    return 1;
}

function getGradeColor(grade) {
    const colors = {
        'A': '#4CAF50', 'A-': '#66BB6A',
        'B+': '#8BC34A', 'B': '#CDDC39', 'B-': '#FFC107',
        'C+': '#FF9800', 'C': '#FF5722', 'C-': '#F44336',
        'D': '#E91E63', 'F': '#9C27B0'
    };
    return colors[grade] || '#9E9E9E';
}

function searchStudents(students, query) {
    if (!query) return students;
    const lower = query.toLowerCase();
    return students.filter(s =>
        s.name.toLowerCase().includes(lower) ||
        s.grade.toLowerCase().includes(lower) ||
        s.email?.toLowerCase().includes(lower) ||
        s.subjects?.some(sub => sub.toLowerCase().includes(lower))
    );
}

function sortStudents(students, field, direction = 'desc') {
    return [...students].sort((a, b) => {
        let valA = a[field];
        let valB = b[field];

        if (typeof valA === 'string') {
            valA = valA.toLowerCase();
            valB = valB.toLowerCase();
        }

        if (direction === 'asc') {
            return valA > valB ? 1 : -1;
        }
        return valA < valB ? 1 : -1;
    });
}

function getUrlParams() {
    const hash = window.location.hash;
    const queryIndex = hash.indexOf('?');
    if (queryIndex === -1) return {};

    const params = new URLSearchParams(hash.substring(queryIndex + 1));
    const result = {};
    for (const [key, value] of params) {
        result[key] = value;
    }
    return result;
}

function calculateGrade(score, maxScore) {
    if (score === '' || score === null) return '';
    const s = parseFloat(score);
    const m = parseFloat(maxScore);
    if (isNaN(s) || isNaN(m) || m === 0) return '';
    const percentage = (s / m) * 100;
    if (percentage >= 90) return 'A';
    if (percentage >= 80) return 'B';
    if (percentage >= 70) return 'C';
    if (percentage >= 60) return 'D';
    if (percentage >= 50) return 'E';
    return 'F';
}

function renderGradeBadge(grade) {
    if (!grade) return '-';
    const colors = {
        'A': { bg: '#E8F5E9', text: '#2E7D32' },
        'B': { bg: '#F1F8E9', text: '#558B2F' },
        'C': { bg: '#FFFDE7', text: '#F9A825' },
        'D': { bg: '#FFF3E0', text: '#EF6C00' },
        'E': { bg: '#F3E5F5', text: '#7B1FA2' },
        'F': { bg: '#FFEBEE', text: '#C62828' }
    };
    const color = colors[grade] || { bg: '#f1f1f1', text: '#666' };
    return `<span class="grade-badge" style="background: ${color.bg}; color: ${color.text}; font-weight: 700; padding: 4px 12px; border-radius: 4px; font-size: 14px;">${grade}</span>`;
}

function getPeriodName(period) {
    const khmerNames = {
        "First Test": "តេស្តលើកទី១",
        "January": "ខែមករា",
        "February": "ខែកុម្ភៈ",
        "March": "ខែមីនា",
        "April": "ខែមេសា",
        "May": "ខែឧសភា",
        "June": "ខែមិថុនា",
        "July": "ខែកក្កដា",
        "August": "ខែសីហា",
        "September": "ខែកញ្ញា",
        "October": "ខែតុលា",
        "November": "ខែវិច្ឆិកា",
        "December": "ខែធ្នូ",
        "Semester 1 Exam": "ឆមាសទី១",
        "Semester 2 Exam": "ឆមាសទី២",
        "Semester 1": "ប្រចាំឆមាសទី១",
        "Semester 2": "ប្រចាំឆមាសទី២",
        "Annual": "ប្រចាំឆ្នាំ"
    };
    return khmerNames[period] || period;
}
