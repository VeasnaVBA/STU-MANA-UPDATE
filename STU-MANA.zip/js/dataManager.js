// js/dataManager.js
const DB_KEY = 'sms_students';
const DB_TEACHERS_KEY = 'sms_teachers';
const DB_SCHOOLS_KEY = 'sms_schools';
const DB_USERS_KEY = 'sms_users';
const DB_SCORES_KEY = 'sms_scores';
const DB_SUBJECTS_KEY = 'sms_subjects';
const DB_SETTINGS_KEY = 'sms_settings';

const seedData = [
    { 
        id: '1', stuId: 'S001', stuKhmerLastName: 'សុខ', stuKhmerFirstName: 'សាន្ត', stuEngLastName: 'Sok', stuEngFirstName: 'San', 
        gender: 'Male', dateOfBirth: '2010-01-01', birthVillage: 'Village 1', birthCommune: 'Commune 1', birthDistrict: 'District 1', birthProvince: 'Province 1', 
        currentVillage: 'Village 1', currentCommmune: 'Commune 1', currentDistrict: 'District 1', currentProvince: 'Province 1', 
        stuPhoneNumber: '012345678', fatherName: 'Sok Father', fatherJob: 'Farmer', fatherPhone: '012111111', motherName: 'Sok Mother', motherJob: 'Housewife', motherPhone: '012222222', 
        classroom: '10A', school: 'High School A', teacher: 'T001', status: 'Active', gpa: 3.85, description: 'Good student', photo: '👨‍🎓' 
    }
];
const seedTeachersData = [
    { id: 'T001', teacherId: 'T001', tkhLastName: 'ស៊ឹម', tkhFirstName: 'សុខា', tengLastName: 'Sim', tengFirstName: 'Sokha', gender: 'Female', dateOfBirth: '1990-05-15', age: 33, phoneNumber: '012345678', classroom: '10A', photo: '👩‍🏫' },
    { id: 'T002', teacherId: 'T002', tkhLastName: 'មាស', tkhFirstName: 'វណ្ណា', tengLastName: 'Meas', tengFirstName: 'Vanna', gender: 'Male', dateOfBirth: '1985-11-20', age: 38, phoneNumber: '098765432', classroom: '11B', photo: '👨‍🏫' }
];
const seedSchoolsData = [
    { 
        id: 'SCH001', schoolId: 'SCH001', schoolName: 'Hun Sen High School', village: 'Village 1', commune: 'Commune 1', district: 'District 1', province: 'Phnom Penh', 
        directorName: 'Director A', phoneNumber: '012123456', description: 'Main branch high school' 
    }
];
const seedUsersData = [
    { id: 'U001', userId: 'U001', username: 'super', password: '123', name: 'Super Admin', role: 'Super Admin', status: 'Active', description: 'System Owner', permissions: ['dashboard', 'students', 'scores', 'subjects', 'schools', 'teachers', 'messages', 'users', 'reports', 'settings'] },
    { id: 'U002', userId: 'U002', username: 'admin', password: '123', name: 'Admin User', role: 'Admin', status: 'Active', description: 'Administrator', permissions: ['dashboard', 'students', 'scores', 'subjects', 'schools', 'teachers', 'messages', 'users', 'reports', 'settings'] },
    { id: 'U003', userId: 'U003', username: 'teacher', password: '123', name: 'Sim Sokha', role: 'Teacher', status: 'Active', description: 'Class Teacher', permissions: ['dashboard', 'students', 'scores', 'subjects', 'reports'] }
];

function initDatabase() {
    if (!localStorage.getItem(DB_KEY)) {
        localStorage.setItem(DB_KEY, JSON.stringify(seedData));
    }
    if (!localStorage.getItem(DB_TEACHERS_KEY)) {
        localStorage.setItem(DB_TEACHERS_KEY, JSON.stringify(seedTeachersData));
    }
    if (!localStorage.getItem(DB_SCHOOLS_KEY)) {
        localStorage.setItem(DB_SCHOOLS_KEY, JSON.stringify(seedSchoolsData));
    }
    if (!localStorage.getItem(DB_USERS_KEY)) {
        localStorage.setItem(DB_USERS_KEY, JSON.stringify(seedUsersData));
    }
    if (!localStorage.getItem(DB_SCORES_KEY)) {
        localStorage.setItem(DB_SCORES_KEY, JSON.stringify([]));
    }
    if (!localStorage.getItem(DB_SUBJECTS_KEY)) {
        const seedSubjects = [
            { id: 'SUB001', subjectId: 'SUB001', subjectName: 'Mathematics', description: 'Core math subject' },
            { id: 'SUB002', subjectId: 'SUB002', subjectName: 'Khmer Literature', description: 'Core language subject' }
        ];
        localStorage.setItem(DB_SUBJECTS_KEY, JSON.stringify(seedSubjects));
    }
    let usersData = localStorage.getItem(DB_USERS_KEY);
    if (!usersData || JSON.parse(usersData).length === 0) {
        localStorage.setItem(DB_USERS_KEY, JSON.stringify(seedUsersData));
    } else {
        // Self-healing: Ensure 'super' and 'admin' users exist and have Super Admin/Admin roles
        let users = JSON.parse(usersData);
        let changed = false;

        // Ensure 'super' exists
        if (!users.find(u => u.username === 'super')) {
            users.push({ 
                id: 'U001', 
                userId: 'U001', 
                username: 'super', 
                password: '123', 
                name: 'Super Admin', 
                role: 'Super Admin', 
                status: 'Active', 
                description: 'System Owner', 
                permissions: ['dashboard', 'students', 'schools', 'teachers', 'messages', 'users', 'reports', 'settings'] 
            });
            changed = true;
        }

        users.forEach(u => {
            // Guarantee all users have a permissions array
            if (!u.permissions || !Array.isArray(u.permissions)) {
                if (u.role === 'Super Admin' || u.role === 'Admin') {
                    u.permissions = ['dashboard', 'students', 'schools', 'teachers', 'messages', 'users', 'reports', 'settings'];
                } else if (u.role === 'Teacher') {
                    u.permissions = ['dashboard', 'students', 'reports'];
                } else {
                    u.permissions = ['dashboard'];
                }
                changed = true;
            }

            if (u.username === 'super') {
                if (u.role !== 'Super Admin' || u.permissions.length < 8) {
                    u.role = 'Super Admin';
                    u.permissions = ['dashboard', 'students', 'schools', 'teachers', 'messages', 'users', 'reports', 'settings'];
                    changed = true;
                }
            } else if (u.role === 'Super Admin') {
                // If any other user accidentally became Super Admin, demote them to Admin
                u.role = 'Admin';
                changed = true;
            }

            if (u.role === 'Admin' && u.permissions.length < 8) {
                u.permissions = ['dashboard', 'students', 'schools', 'teachers', 'messages', 'users', 'reports', 'settings'];
                changed = true;
            }
        });
        
        if (changed) {
            localStorage.setItem(DB_USERS_KEY, JSON.stringify(users));
        }
    }

    // Self-healing for Students: Ensure unique internal IDs
    let studentData = localStorage.getItem(DB_KEY);
    if (studentData) {
        let students = JSON.parse(studentData);
        let idSet = new Set();
        let studentChanged = false;
        students.forEach(s => {
            if (!s.id || idSet.has(s.id)) {
                s.id = Date.now().toString() + '-' + Math.random().toString(36).substr(2, 9);
                studentChanged = true;
            }
            idSet.add(s.id);
        });
        if (studentChanged) {
            localStorage.setItem(DB_KEY, JSON.stringify(students));
        }
    }

    // Self-healing for Dates: Convert numeric Excel dates to dd/mm/yyyy
    const repairDates = (dataKey) => {
        let data = localStorage.getItem(dataKey);
        if (data) {
            let items = JSON.parse(data);
            let changed = false;
            items.forEach(item => {
                const rawDob = item.dateOfBirth;
                if (rawDob) {
                    const numDob = Number(rawDob);
                    // Check if it's a numeric Excel date (usually > 10000)
                    if (!isNaN(numDob) && typeof rawDob !== 'object' && numDob > 10000 && numDob < 100000) {
                        const date = new Date((numDob - 25569) * 86400 * 1000);
                        if (!isNaN(date.getTime())) {
                            const d = String(date.getDate()).padStart(2, '0');
                            const m = String(date.getMonth() + 1).padStart(2, '0');
                            const y = date.getFullYear();
                            item.dateOfBirth = `${d}/${m}/${y}`;
                            changed = true;
                        }
                    }
                }
            });
            if (changed) {
                localStorage.setItem(dataKey, JSON.stringify(items));
            }
        }
    };
    repairDates(DB_KEY);
    repairDates(DB_TEACHERS_KEY);
}

function getStudents() {
    initDatabase();
    const data = localStorage.getItem(DB_KEY);
    return data ? JSON.parse(data) : [];
}

function saveStudents(students) {
    localStorage.setItem(DB_KEY, JSON.stringify(students));
}

function getStudentById(id) {
    return getStudents().find(s => s.id === id);
}

function addStudent(student) {
    const students = getStudents();
    student.id = Date.now().toString() + '-' + Math.random().toString(36).substr(2, 9);
    students.push(student);
    saveStudents(students);
    return student;
}

function updateStudent(id, updatedData) {
    const students = getStudents();
    const index = students.findIndex(s => s.id === id);
    if (index !== -1) {
        students[index] = { ...students[index], ...updatedData };
        saveStudents(students);
        return students[index];
    }
    return null;
}

function deleteStudent(id) {
    const students = getStudents();
    const filtered = students.filter(s => s.id !== id);
    saveStudents(filtered);
    return filtered.length < students.length;
}

// Teacher Operations
function getTeachers() {
    initDatabase();
    const data = localStorage.getItem(DB_TEACHERS_KEY);
    return data ? JSON.parse(data) : [];
}

function saveTeachers(teachers) {
    localStorage.setItem(DB_TEACHERS_KEY, JSON.stringify(teachers));
}

function getTeacherById(id) {
    return getTeachers().find(t => t.id === id);
}

function addTeacher(teacher) {
    const teachers = getTeachers();
    teacher.id = Date.now().toString() + '-' + Math.random().toString(36).substr(2, 9);
    teachers.push(teacher);
    saveTeachers(teachers);
    return teacher;
}

function updateTeacher(id, updatedData) {
    const teachers = getTeachers();
    const index = teachers.findIndex(t => t.id === id);
    if (index !== -1) {
        teachers[index] = { ...teachers[index], ...updatedData };
        saveTeachers(teachers);
        return teachers[index];
    }
    return null;
}

function deleteTeacher(id) {
    const teachers = getTeachers();
    const filtered = teachers.filter(t => t.id !== id);
    saveTeachers(filtered);
    return filtered.length < teachers.length;
}

// School Operations
function getSchools() {
    initDatabase();
    const data = localStorage.getItem(DB_SCHOOLS_KEY);
    return data ? JSON.parse(data) : [];
}

function saveSchools(schools) {
    localStorage.setItem(DB_SCHOOLS_KEY, JSON.stringify(schools));
}

function getSchoolById(id) {
    return getSchools().find(s => s.id === id);
}

function addSchool(school) {
    const schools = getSchools();
    school.id = Date.now().toString() + '-' + Math.random().toString(36).substr(2, 9);
    schools.push(school);
    saveSchools(schools);
    return school;
}

function updateSchool(id, updatedData) {
    const schools = getSchools();
    const index = schools.findIndex(s => s.id === id);
    if (index !== -1) {
        schools[index] = { ...schools[index], ...updatedData };
        saveSchools(schools);
        return schools[index];
    }
    return null;
}

function deleteSchool(id) {
    const schools = getSchools();
    const filtered = schools.filter(s => s.id !== id);
    saveSchools(filtered);
    return filtered.length < schools.length;
}

// User Operations
function getUsers() {
    initDatabase();
    const data = localStorage.getItem(DB_USERS_KEY);
    return data ? JSON.parse(data) : [];
}

function saveUsers(users) {
    localStorage.setItem(DB_USERS_KEY, JSON.stringify(users));
}

function getUserById(id) {
    return getUsers().find(u => u.id === id);
}

function addUser(user) {
    const users = getUsers();
    user.id = Date.now().toString() + '-' + Math.random().toString(36).substr(2, 9);
    users.push(user);
    saveUsers(users);
    return user;
}

function updateUser(id, updatedData) {
    const users = getUsers();
    const index = users.findIndex(u => u.id === id);
    if (index !== -1) {
        users[index] = { ...users[index], ...updatedData };
        saveUsers(users);
        return users[index];
    }
    return null;
}

function deleteUser(id) {
    const users = getUsers();
    const filtered = users.filter(u => u.id !== id);
    saveUsers(filtered);
    return filtered.length < users.length;
}

// Global Filtering
function getFilteredStudents() {
    let students = getStudents();
    const currentUser = typeof getCurrentUser === 'function' ? getCurrentUser() : null;
    if (currentUser && currentUser.role === 'Teacher') {
        const teachers = getTeachers();
        const myTeacherRecord = teachers.find(t => (t.tengFirstName + ' ' + t.tengLastName) === currentUser.name);
        if (myTeacherRecord) {
            // Teacher only sees students that match BOTH their ID and their School
            students = students.filter(s => s.teacher === myTeacherRecord.id && s.school === myTeacherRecord.school);
        } else {
            students = [];
        }
    }
    return students;
}

function getSubjects() {
    return JSON.parse(localStorage.getItem(DB_SUBJECTS_KEY) || '[]');
}

function saveSubjects(subjects) {
    localStorage.setItem(DB_SUBJECTS_KEY, JSON.stringify(subjects));
}

function addSubject(subject) {
    const subjects = getSubjects();
    subject.id = Date.now().toString() + '-' + Math.random().toString(36).substr(2, 9);
    subjects.push(subject);
    saveSubjects(subjects);
    return subject;
}

function updateSubject(id, updatedData) {
    const subjects = getSubjects();
    const index = subjects.findIndex(s => s.id === id);
    if (index !== -1) {
        subjects[index] = { ...subjects[index], ...updatedData };
        saveSubjects(subjects);
        return subjects[index];
    }
    return null;
}

function deleteSubject(id) {
    const subjects = getSubjects();
    const filtered = subjects.filter(s => s.id !== id);
    saveSubjects(filtered);
    return filtered.length < subjects.length;
}

// Scores management
function getScores() {
    return JSON.parse(localStorage.getItem(DB_SCORES_KEY) || '[]');
}

function saveScores(scores) {
    localStorage.setItem(DB_SCORES_KEY, JSON.stringify(scores));
}

function getScore(studentId, period, subjectId) {
    const scores = getScores();
    return scores.find(s => s.studentId === studentId && s.period === period && s.subjectId === subjectId);
}

function saveScore(studentId, period, subjectId, scoreValue) {
    const scores = getScores();
    const index = scores.findIndex(s => s.studentId === studentId && s.period === period && s.subjectId === subjectId);
    
    const scoreData = {
        studentId,
        period,
        subjectId,
        score: scoreValue,
        updatedAt: new Date().toISOString()
    };

    if (index !== -1) {
        scores[index] = scoreData;
    } else {
        scores.push(scoreData);
    }
    saveScores(scores);
}

function getScoresByPeriodAndSubject(period, subjectId) {
    const scores = getScores();
    return scores.filter(s => s.period === period && s.subjectId === subjectId);
}

// System Settings
function getSettings() {
    const defaults = {
        scoreEntryStartDay: 1,
        scoreEntryEndDay: 31,
        periodCoefficients: {
            "First Test": 10,
            "January": 10, "February": 10, "March": 10, "April": 10, "May": 10, "June": 10,
            "July": 10, "August": 10, "September": 10, "October": 10, "November": 10, "December": 10,
            "Semester 1 Exam": 10, "Semester 2 Exam": 10,
            "Semester 1": 10, "Semester 2": 10, "Annual": 10
        },
        schoolInfo: {
            ministry: "មន្ទីរអប់រំ យុវជន និងកីឡា",
            location: "ក្រុង បាត់ដំបង",
            schoolName: "អនុវិទ្យាល័យ ជ្រៃកោត",
            kingdomSlogan: "ព្រះរាជាណាចក្រកម្ពុជា",
            nationSlogan: "ជាតិ សាសនា ព្រះមហាក្សត្រ"
        },
        reportMargins: {
            headerTop: 0,
            tableTop: 20,
            footerTop: 30,
            titleSpacing: 10,
            ministrySpacing: 0,
            locationSpacing: 0,
            schoolNameSpacing: 0,
            kingdomSpacing: 0,
            nationSpacing: 0
        },
        rankingMargins: {
            headerTop: 0,
            tableTop: 20,
            footerTop: 30,
            titleSpacing: 10,
            ministrySpacing: 0,
            locationSpacing: 0,
            schoolNameSpacing: 0,
            kingdomSpacing: 0,
            nationSpacing: 0
        }
    };
    const saved = localStorage.getItem(DB_SETTINGS_KEY);
    if (!saved) return defaults;
    
    try {
        const settings = JSON.parse(saved);
        // Self-healing: Merge defaults with saved settings so new keys exist
        return { 
            ...defaults, 
            ...settings,
            periodCoefficients: { ...defaults.periodCoefficients, ...(settings.periodCoefficients || {}) },
            reportMargins: { ...defaults.reportMargins, ...(settings.reportMargins || {}) },
            rankingMargins: { ...defaults.rankingMargins, ...(settings.rankingMargins || {}) }
        };
    } catch (e) {
        return defaults;
    }
}

function saveSettings(settings) {
    localStorage.setItem(DB_SETTINGS_KEY, JSON.stringify(settings));
}

function getPeriodCoefficient(period) {
    const settings = getSettings();
    return settings.periodCoefficients[period] || 10;
}
