// js/auth.js
const AUTH_KEY = 'sms_auth_user';

function login(username, password) {
    const users = getUsers();
    const user = users.find(u => u.username === username && u.password === password);
    
    if (user) {
        if (user.status !== 'Active') {
            return { success: false, message: 'Account is inactive.' };
        }
        localStorage.setItem(AUTH_KEY, JSON.stringify(user));
        return { success: true, user: user };
    }
    return { success: false, message: 'Invalid username or password.' };
}

function logout() {
    localStorage.removeItem(AUTH_KEY);
    window.location.hash = '#/login';
    renderLogin();
}

function getCurrentUser() {
    const authData = localStorage.getItem(AUTH_KEY);
    if (!authData) return null;
    
    const sessionUser = JSON.parse(authData);
    // Refresh from DB to sync role/permission changes
    const users = getUsers();
    const dbUser = users.find(u => u.id === sessionUser.id);
    return dbUser || sessionUser;
}

function isAuthenticated() {
    return !!getCurrentUser();
}

function checkAuth() {
    if (!isAuthenticated() && window.location.hash !== '#/login') {
        window.location.hash = '#/login';
        return false;
    }
    return true;
}
