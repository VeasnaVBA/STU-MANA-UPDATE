// js/students.js
// Student-specific operations will go here
// This file is ready for CRUD operations on the students list page

function renderStudentTable(students = null) {
    const tbody = document.getElementById('students-table-body');
    if (!tbody) return;

    const data = students || getStudents();

    if (data.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" class="empty-state">
                    <p>No students found. <a href="add-student.html">Add your first student</a></p>
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = data.map(student => `
        <tr>
            <td>
                <div style="display:flex; align-items:center; gap:12px;">
                    <span style="font-size:24px;">${student.avatar || '🎓'}</span>
                    <div>
                        <div style="font-weight:600;">${student.name}</div>
                        <div style="font-size:12px; color:var(--text-secondary);">${student.subjects?.join(', ') || ''}</div>
                    </div>
                </div>
            </td>
            <td><span style="color:${getGradeColor(student.grade)}; font-weight:600;">${student.grade}</span></td>
            <td>${student.gpa.toFixed(2)}</td>
            <td>${renderStars(student.stars || calculateStars(student.gpa))}</td>
            <td>${student.id}</td>
            <td>
                <div style="display:flex; gap:8px;">
                    <a href="edit-student.html?id=${student.id}" class="btn btn-secondary" style="padding:6px 12px; font-size:12px;">Edit</a>
                    <button onclick="handleDelete('${student.id}')" class="btn" style="padding:6px 12px; font-size:12px; background:#FFEBEE; color:#C62828;">Delete</button>
                </div>
            </td>
        </tr>
    `).join('');
}

function handleDelete(id) {
    if (confirm('Are you sure you want to delete this student?')) {
        if (deleteStudent(id)) {
            showAlert('Student deleted successfully');
            renderStudentTable();
            updateStats();
        }
    }
}
